-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Mar 12, 2025 at 03:29 AM
-- Server version: 10.11.10-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `u728535006_tGP3z`
--

-- --------------------------------------------------------

--
-- Table structure for table `cars`
--

CREATE TABLE `cars` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `customer_id` bigint(20) UNSIGNED NOT NULL,
  `registration_number` varchar(255) NOT NULL,
  `make` varchar(255) NOT NULL,
  `year_of_manufacture` year(4) NOT NULL,
  `data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`data`)),
  `mot_expiry_date` date DEFAULT NULL,
  `mileage` varchar(255) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `cars`
--

INSERT INTO `cars` (`id`, `customer_id`, `registration_number`, `make`, `year_of_manufacture`, `data`, `mot_expiry_date`, `mileage`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 1, 'PF02WZB', 'VOLKSWAGEN', '2002', '{\"registrationNumber\":\"PF02WZB\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-03-01\",\"motStatus\":\"Valid\",\"make\":\"VOLKSWAGEN\",\"yearOfManufacture\":2002,\"engineCapacity\":1896,\"co2Emissions\":140,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"BLACK\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2022-02-16\",\"motExpiryDate\":\"2023-06-23\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2002-07\"}', '2023-06-23', NULL, NULL, '2023-03-27 01:27:10', '2023-03-27 01:27:10'),
(3, 3, 'MK12YNF', 'NISSAN', '2012', '{\"registrationNumber\":\"MK12YNF\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-01-01\",\"motStatus\":\"Valid\",\"make\":\"NISSAN\",\"yearOfManufacture\":2012,\"engineCapacity\":1598,\"co2Emissions\":144,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"RED\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2020-10-23\",\"motExpiryDate\":\"2024-02-21\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2012-06\"}', '2024-02-21', NULL, NULL, '2023-04-06 13:31:30', '2023-08-09 11:26:25'),
-- (4, 4, 'CK16AXU', 'VAUXHALL', '2016', '{\"registrationNumber\":\"CK16AXU\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2023-12-01\",\"motStatus\":\"Valid\",\"make\":\"VAUXHALL\",\"yearOfManufacture\":2016,\"engineCapacity\":1598,\"co2Emissions\":155,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"RED\",\"typeApproval\":\"N1\",\"revenueWeight\":3010,\"dateOfLastV5CIssued\":\"2018-12-19\",\"motExpiryDate\":\"2023-11-28\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2016-03\"}', '2023-11-28', NULL, NULL, '2023-04-07 08:34:39', '2023-04-07 08:34:39'),
-- (5, 5, 'FN12YTA', 'CITROEN', '2012', '{\"registrationNumber\":\"FN12YTA\",\"taxStatus\":\"Untaxed\",\"taxDueDate\":\"2021-03-01\",\"motStatus\":\"Not valid\",\"make\":\"CITROEN\",\"yearOfManufacture\":2012,\"engineCapacity\":998,\"co2Emissions\":103,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"RED\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2016-03-21\",\"motExpiryDate\":\"2022-03-06\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2012-03\"}', '2022-03-06', NULL, NULL, '2023-04-07 15:43:24', '2023-04-07 15:43:24'),
-- (6, 6, 'FN14UWA', 'TOYOTA', '2014', '{\"registrationNumber\":\"FN14UWA\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2023-07-01\",\"motStatus\":\"Valid\",\"make\":\"TOYOTA\",\"yearOfManufacture\":2014,\"engineCapacity\":1364,\"co2Emissions\":109,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"WHITE\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2022-01-14\",\"motExpiryDate\":\"2024-04-05\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2014-04\"}', '2024-04-05', NULL, NULL, '2023-04-07 15:44:08', '2023-04-07 15:44:08'),
-- (7, 7, 'EF60UAV', 'HYUNDAI', '2010', '{\"registrationNumber\":\"EF60UAV\",\"taxStatus\":\"Untaxed\",\"taxDueDate\":\"2022-01-15\",\"motStatus\":\"Valid\",\"make\":\"HYUNDAI\",\"yearOfManufacture\":2010,\"engineCapacity\":2497,\"co2Emissions\":225,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"SILVER\",\"typeApproval\":\"M1\",\"revenueWeight\":2282,\"dateOfLastV5CIssued\":\"2019-12-10\",\"motExpiryDate\":\"2024-04-03\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2010-12\"}', '2024-04-03', NULL, NULL, '2023-04-07 15:45:06', '2023-04-07 15:45:06'),
-- (8, 8, 'DV59GMF', 'VAUXHALL', '2009', '{\"registrationNumber\":\"DV59GMF\",\"taxStatus\":\"Untaxed\",\"taxDueDate\":\"2023-04-01\",\"motStatus\":\"Not valid\",\"make\":\"VAUXHALL\",\"yearOfManufacture\":2009,\"engineCapacity\":1364,\"co2Emissions\":146,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"SILVER\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2019-04-12\",\"motExpiryDate\":\"2023-03-23\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2009-09\"}', '2023-03-23', NULL, NULL, '2023-04-07 15:47:27', '2023-04-07 15:47:27'),
-- (9, 9, 'KV14MYY', 'MERCEDES-BENZ', '2014', '{\"registrationNumber\":\"KV14MYY\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2023-09-01\",\"motStatus\":\"Valid\",\"make\":\"MERCEDES-BENZ\",\"yearOfManufacture\":2014,\"engineCapacity\":1595,\"co2Emissions\":128,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"BLACK\",\"typeApproval\":\"M1\",\"revenueWeight\":1935,\"dateOfLastV5CIssued\":\"2019-09-26\",\"motExpiryDate\":\"2024-04-03\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2014-03\"}', '2024-04-03', NULL, NULL, '2023-04-07 15:48:24', '2023-04-07 15:48:24'),
-- (10, 10, 'M3SVU', 'LAND ROVER', '2005', '{\"registrationNumber\":\"M3SVU\",\"taxStatus\":\"SORN\",\"motStatus\":\"Not valid\",\"make\":\"LAND ROVER\",\"yearOfManufacture\":2005,\"engineCapacity\":2720,\"co2Emissions\":271,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"BLACK\",\"typeApproval\":\"M1\",\"revenueWeight\":3070,\"dateOfLastV5CIssued\":\"2021-11-10\",\"motExpiryDate\":\"2022-10-03\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2005-12\"}', '2022-10-03', NULL, NULL, '2023-04-07 15:49:02', '2023-04-07 15:49:02'),
-- (11, 11, 'NL15NPA', 'FORD', '2015', '{\"registrationNumber\":\"NL15NPA\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-04-01\",\"motStatus\":\"Valid\",\"make\":\"FORD\",\"yearOfManufacture\":2015,\"engineCapacity\":1560,\"co2Emissions\":130,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"SILVER\",\"typeApproval\":\"M1\",\"revenueWeight\":2045,\"dateOfLastV5CIssued\":\"2018-04-11\",\"motExpiryDate\":\"2023-04-09\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2015-04\"}', '2023-04-09', NULL, NULL, '2023-04-07 15:50:06', '2023-04-07 15:50:06'),
-- (12, 12, 'ET06BOV', 'FORD', '2006', '{\"registrationNumber\":\"ET06BOV\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2023-05-01\",\"motStatus\":\"Valid\",\"make\":\"FORD\",\"yearOfManufacture\":2006,\"engineCapacity\":1753,\"co2Emissions\":164,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"ORANGE\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2022-05-20\",\"motExpiryDate\":\"2023-05-09\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2006-08\"}', '2023-05-09', NULL, NULL, '2023-04-10 12:24:26', '2023-04-10 12:24:26'),
-- (13, 13, 'FH14CFX', 'VAUXHALL', '2014', '{\"registrationNumber\":\"FH14CFX\",\"taxStatus\":\"Untaxed\",\"taxDueDate\":\"2023-03-21\",\"motStatus\":\"Valid\",\"make\":\"VAUXHALL\",\"yearOfManufacture\":2014,\"engineCapacity\":1598,\"co2Emissions\":149,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"BLACK\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2023-03-13\",\"motExpiryDate\":\"2023-06-14\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2014-06\"}', '2023-06-14', NULL, NULL, '2023-04-10 16:20:25', '2023-04-10 16:20:25'),
-- (14, 13, 'FP11HFY', 'VAUXHALL', '2011', '{\"registrationNumber\":\"FP11HFY\",\"taxStatus\":\"Untaxed\",\"taxDueDate\":\"2023-02-07\",\"motStatus\":\"Valid\",\"make\":\"VAUXHALL\",\"yearOfManufacture\":2011,\"engineCapacity\":1956,\"co2Emissions\":159,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"SILVER\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2013-02-05\",\"motExpiryDate\":\"2023-06-04\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2011-06\"}', '2023-06-04', NULL, NULL, '2023-04-10 16:22:54', '2023-04-10 16:22:54'),
-- (16, 15, 'K1NWM', 'MERCEDES', '2006', '{\"registrationNumber\":\"K1NWM\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-02-01\",\"motStatus\":\"Valid\",\"make\":\"MERCEDES\",\"yearOfManufacture\":2006,\"engineCapacity\":5461,\"co2Emissions\":279,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"SILVER\",\"typeApproval\":\"M1\",\"revenueWeight\":2545,\"dateOfLastV5CIssued\":\"2018-02-13\",\"motExpiryDate\":\"2023-08-23\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2006-01\"}', '2023-08-23', NULL, NULL, '2023-04-11 13:00:43', '2023-04-11 13:00:43'),
-- (18, 18, 'PF02WZV', 'HONDA', '2002', '{\"registrationNumber\":\"PF02WZV\",\"taxStatus\":\"SORN\",\"motStatus\":\"No details held by DVLA\",\"make\":\"HONDA\",\"yearOfManufacture\":2002,\"engineCapacity\":499,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"RED\",\"dateOfLastV5CIssued\":\"2020-02-28\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2002-08\"}', NULL, NULL, NULL, '2023-04-18 12:18:50', '2023-04-18 12:18:50'),
-- (19, 19, 'WG57DJV', 'TOYOTA', '2008', '{\"registrationNumber\":\"WG57DJV\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-03-01\",\"motStatus\":\"Valid\",\"make\":\"TOYOTA\",\"yearOfManufacture\":2008,\"engineCapacity\":2982,\"co2Emissions\":0,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"BLACK\",\"typeApproval\":\"N1\",\"revenueWeight\":2940,\"dateOfLastV5CIssued\":\"2021-04-26\",\"motExpiryDate\":\"2024-01-01\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2008-01\"}', '2024-01-01', NULL, NULL, '2023-04-18 16:37:06', '2023-04-18 16:37:06'),
-- (20, 20, 'BF58FLP', 'TOYOTA', '2008', '{\"registrationNumber\":\"BF58FLP\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2023-11-01\",\"motStatus\":\"Valid\",\"make\":\"TOYOTA\",\"yearOfManufacture\":2008,\"engineCapacity\":1296,\"co2Emissions\":141,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"SILVER\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2014-08-29\",\"motExpiryDate\":\"2023-10-12\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2008-09\"}', '2023-10-12', NULL, NULL, '2023-04-18 16:39:07', '2023-04-18 16:39:07'),
-- (23, 24, 'YB62SRU', 'HYUNDAI', '2013', '{\"registrationNumber\":\"YB62SRU\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-01-01\",\"motStatus\":\"Valid\",\"make\":\"HYUNDAI\",\"yearOfManufacture\":2013,\"engineCapacity\":1248,\"co2Emissions\":114,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"WHITE\",\"typeApproval\":\"M1\",\"revenueWeight\":1102,\"dateOfLastV5CIssued\":\"2014-08-12\",\"motExpiryDate\":\"2024-01-23\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2013-01\"}', '2024-01-23', NULL, NULL, '2023-05-09 16:16:35', '2023-05-09 16:16:35'),
-- (24, 25, 'EK67XBG', 'NISSAN', '2017', '{\"registrationNumber\":\"EK67XBG\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-05-01\",\"motStatus\":\"Valid\",\"make\":\"NISSAN\",\"yearOfManufacture\":2017,\"engineCapacity\":1197,\"co2Emissions\":129,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"BLACK\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2021-05-17\",\"motExpiryDate\":\"2023-05-12\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2017-09\"}', '2023-05-12', NULL, NULL, '2023-05-10 09:21:01', '2023-05-10 09:21:01'),
-- (25, 15, 'YY16HTA', 'VOLVO', '2016', '{\"registrationNumber\":\"YY16HTA\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2023-11-01\",\"motStatus\":\"Valid\",\"make\":\"VOLVO\",\"yearOfManufacture\":2016,\"engineCapacity\":1969,\"co2Emissions\":49,\"fuelType\":\"HYBRID ELECTRIC\",\"markedForExport\":false,\"colour\":\"BLUE\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2019-11-22\",\"motExpiryDate\":\"2023-11-08\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2016-03\"}', '2023-11-08', NULL, NULL, '2023-05-10 11:24:49', '2023-05-10 11:24:49'),
-- (26, 26, 'KH05ALD', 'LAND ROVER', '2014', '{\"registrationNumber\":\"KH05ALD\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-03-01\",\"motStatus\":\"Valid\",\"make\":\"LAND ROVER\",\"yearOfManufacture\":2014,\"engineCapacity\":2993,\"co2Emissions\":199,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"BLUE\",\"typeApproval\":\"M1\",\"revenueWeight\":3150,\"dateOfLastV5CIssued\":\"2019-03-31\",\"motExpiryDate\":\"2024-02-11\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2014-01\"}', '2024-02-11', NULL, NULL, '2023-05-12 13:02:43', '2023-05-12 13:02:43'),
-- (27, 27, 'MD06NYC', 'MERCEDES', '2006', '{\"registrationNumber\":\"MD06NYC\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-05-01\",\"motStatus\":\"Valid\",\"make\":\"MERCEDES\",\"yearOfManufacture\":2006,\"engineCapacity\":3498,\"co2Emissions\":242,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"SILVER\",\"typeApproval\":\"M1\",\"revenueWeight\":2475,\"dateOfLastV5CIssued\":\"2022-06-10\",\"motExpiryDate\":\"2024-02-09\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2006-07\"}', '2024-02-09', NULL, NULL, '2023-05-12 14:03:30', '2023-05-12 14:03:30'),
-- (28, 28, 'HJ63XHT', 'TOYOTA', '2013', '{\"registrationNumber\":\"HJ63XHT\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2023-08-01\",\"motStatus\":\"Valid\",\"make\":\"TOYOTA\",\"yearOfManufacture\":2013,\"engineCapacity\":1329,\"co2Emissions\":127,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"WHITE\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2016-06-07\",\"motExpiryDate\":\"2023-11-22\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2013-11\"}', '2023-11-22', NULL, NULL, '2023-05-12 15:04:11', '2023-05-12 15:04:11'),
-- (29, 29, 'FE12EPY', 'TOYOTA', '2012', '{\"registrationNumber\":\"FE12EPY\",\"taxStatus\":\"Untaxed\",\"taxDueDate\":\"2023-05-01\",\"motStatus\":\"Not valid\",\"make\":\"TOYOTA\",\"yearOfManufacture\":2012,\"engineCapacity\":1797,\"co2Emissions\":93,\"fuelType\":\"HYBRID ELECTRIC\",\"markedForExport\":false,\"colour\":\"WHITE\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2016-05-19\",\"motExpiryDate\":\"2023-05-11\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2012-03\"}', '2023-05-11', NULL, NULL, '2023-05-12 15:04:41', '2023-05-12 15:04:41'),
-- (30, 30, 'FL15PGU', 'TOYOTA', '2015', '{\"registrationNumber\":\"FL15PGU\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2023-12-01\",\"motStatus\":\"Valid\",\"make\":\"TOYOTA\",\"yearOfManufacture\":2015,\"engineCapacity\":1364,\"co2Emissions\":109,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"SILVER\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2021-12-08\",\"motExpiryDate\":\"2023-12-08\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2015-03\"}', '2023-12-08', NULL, NULL, '2023-05-27 09:11:29', '2023-05-27 09:11:29'),
-- (31, 4, 'CK17KUP', 'VAUXHALL', '2017', '{\"registrationNumber\":\"CK17KUP\",\"taxStatus\":\"SORN\",\"motStatus\":\"Valid\",\"make\":\"VAUXHALL\",\"yearOfManufacture\":2017,\"engineCapacity\":999,\"co2Emissions\":104,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"GREY\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2023-03-01\",\"motExpiryDate\":\"2023-07-06\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2017-04\"}', '2023-07-06', NULL, NULL, '2023-06-12 11:12:07', '2023-06-12 11:12:07'),
-- (33, 31, 'WV11NXF', 'VOLKSWAGEN', '2011', '{\"registrationNumber\":\"WV11NXF\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-02-01\",\"motStatus\":\"Valid\",\"make\":\"VOLKSWAGEN\",\"yearOfManufacture\":2011,\"engineCapacity\":1598,\"co2Emissions\":116,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"SILVER\",\"typeApproval\":\"M1\",\"revenueWeight\":2120,\"dateOfLastV5CIssued\":\"2015-03-02\",\"motExpiryDate\":\"2023-10-10\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2011-03\"}', '2023-10-10', NULL, NULL, '2023-06-20 20:58:22', '2023-06-20 20:58:22'),
-- (34, 32, 'MY13RHM', 'MERCEDES-BENZ', '2016', '{\"registrationNumber\":\"MY13RHM\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2023-11-01\",\"motStatus\":\"Valid\",\"make\":\"MERCEDES-BENZ\",\"yearOfManufacture\":2016,\"engineCapacity\":1950,\"co2Emissions\":102,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"WHITE\",\"typeApproval\":\"M1\",\"revenueWeight\":2320,\"dateOfLastV5CIssued\":\"2021-02-10\",\"motExpiryDate\":\"2023-10-06\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2016-06\"}', '2023-10-06', NULL, NULL, '2023-06-20 21:04:51', '2023-06-20 21:04:51'),
-- (35, 33, 'BN59VGP', 'CITROEN', '2009', '{\"registrationNumber\":\"BN59VGP\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2023-10-01\",\"motStatus\":\"Valid\",\"make\":\"CITROEN\",\"yearOfManufacture\":2009,\"engineCapacity\":1560,\"co2Emissions\":145,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"BLUE\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2022-10-09\",\"motExpiryDate\":\"2023-07-15\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2009-09\"}', '2023-07-15', NULL, NULL, '2023-06-22 09:01:08', '2023-06-22 09:01:08'),
-- (36, 34, 'EO58FDK', 'TOYOTA', '2008', '{\"registrationNumber\":\"EO58FDK\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-06-01\",\"motStatus\":\"Valid\",\"make\":\"TOYOTA\",\"yearOfManufacture\":2008,\"engineCapacity\":1497,\"co2Emissions\":104,\"fuelType\":\"HYBRID ELECTRIC\",\"markedForExport\":false,\"colour\":\"SILVER\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2023-05-12\",\"motExpiryDate\":\"2023-10-13\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2008-10\"}', '2023-10-13', NULL, NULL, '2023-07-07 15:12:52', '2023-07-07 15:12:52'),
-- (37, 35, 'YF09BYD', 'VOLKSWAGEN', '2009', '{\"registrationNumber\":\"YF09BYD\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-06-01\",\"motStatus\":\"Valid\",\"make\":\"VOLKSWAGEN\",\"yearOfManufacture\":2009,\"engineCapacity\":1968,\"co2Emissions\":129,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"SILVER\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2023-07-06\",\"motExpiryDate\":\"2023-12-02\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2009-07\"}', '2023-12-02', NULL, NULL, '2023-07-07 15:14:01', '2023-07-07 15:14:01'),
-- (38, 36, 'PK10XSZ', 'VOLKSWAGEN', '2010', '{\"registrationNumber\":\"PK10XSZ\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-01-01\",\"motStatus\":\"Valid\",\"make\":\"VOLKSWAGEN\",\"yearOfManufacture\":2010,\"engineCapacity\":1600,\"co2Emissions\":119,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"SILVER\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2022-02-02\",\"motExpiryDate\":\"2023-09-05\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2010-06\"}', '2023-09-05', NULL, NULL, '2023-07-07 15:27:53', '2023-07-07 15:27:53'),
-- (39, 32, 'AA19AAA', 'MERCEDES-BENZ', '2019', '{\"registrationNumber\":\"AA19AAA\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-07-01\",\"motStatus\":\"Valid\",\"make\":\"MERCEDES-BENZ\",\"yearOfManufacture\":2019,\"engineCapacity\":1332,\"co2Emissions\":126,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"WHITE\",\"typeApproval\":\"M1\",\"revenueWeight\":1945,\"euroStatus\":\"EURO 6 DG\",\"dateOfLastV5CIssued\":\"2020-07-17\",\"motExpiryDate\":\"2023-07-18\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2019-07\"}', '2023-07-18', NULL, NULL, '2023-07-11 10:19:30', '2023-07-11 10:19:30'),
-- (40, 29, 'FC03NVK', 'HONDA', '2003', '{\"registrationNumber\":\"FC03NVK\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-03-01\",\"motStatus\":\"Valid\",\"make\":\"HONDA\",\"yearOfManufacture\":2003,\"engineCapacity\":1490,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"WHITE\",\"dateOfLastV5CIssued\":\"2022-06-07\",\"motExpiryDate\":\"2024-02-13\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2003-05\",\"monthOfFirstDvlaRegistration\":\"2010-03\"}', '2024-02-13', NULL, NULL, '2023-07-11 16:51:27', '2023-07-11 16:51:27'),
-- (41, 15, 'HK56GZY', 'BMW', '2006', '{\"registrationNumber\":\"HK56GZY\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-05-01\",\"motStatus\":\"Valid\",\"make\":\"BMW\",\"yearOfManufacture\":2006,\"engineCapacity\":1995,\"co2Emissions\":188,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"BLACK\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2017-05-22\",\"motExpiryDate\":\"2024-04-24\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2006-12\"}', '2024-04-24', NULL, NULL, '2023-07-11 16:54:09', '2023-07-11 16:54:09'),
-- (42, 6, 'GW04BLN', 'LEXUS', '2004', '{\"registrationNumber\":\"GW04BLN\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-07-01\",\"motStatus\":\"Valid\",\"make\":\"LEXUS\",\"yearOfManufacture\":2004,\"engineCapacity\":1988,\"co2Emissions\":231,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"SILVER\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2020-08-05\",\"motExpiryDate\":\"2023-07-11\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2004-07\"}', '2023-07-11', NULL, NULL, '2023-07-11 16:58:09', '2023-07-11 16:58:09'),
-- (43, 6, 'MW12KNS', 'BMW', '2012', '{\"registrationNumber\":\"MW12KNS\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-04-01\",\"motStatus\":\"Valid\",\"make\":\"BMW\",\"yearOfManufacture\":2012,\"engineCapacity\":1995,\"co2Emissions\":139,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"RED\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2022-04-09\",\"motExpiryDate\":\"2023-07-26\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2012-06\"}', '2023-07-26', NULL, NULL, '2023-07-11 16:58:40', '2023-07-11 16:58:40'),
-- (44, 6, 'NK63VSG', 'BMW', '2013', '{\"registrationNumber\":\"NK63VSG\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-07-01\",\"motStatus\":\"Valid\",\"make\":\"BMW\",\"yearOfManufacture\":2013,\"engineCapacity\":1995,\"co2Emissions\":118,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"WHITE\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2023-06-30\",\"motExpiryDate\":\"2023-07-19\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2013-09\"}', '2023-07-19', NULL, NULL, '2023-07-11 16:58:57', '2023-07-11 16:58:57'),
-- (45, 6, 'RU11DLL', 'AUDI', '2013', '{\"registrationNumber\":\"RU11DLL\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-07-01\",\"motStatus\":\"Valid\",\"make\":\"AUDI\",\"yearOfManufacture\":2013,\"engineCapacity\":1968,\"co2Emissions\":127,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"BLACK\",\"typeApproval\":\"M1\",\"revenueWeight\":2090,\"dateOfLastV5CIssued\":\"2021-08-02\",\"motExpiryDate\":\"2023-07-31\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2013-07\"}', '2023-07-31', NULL, NULL, '2023-07-11 16:59:21', '2023-07-11 16:59:21'),
-- (46, 6, 'AU56VEO', 'AUDI', '2006', '{\"registrationNumber\":\"AU56VEO\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2023-08-01\",\"motStatus\":\"Valid\",\"make\":\"AUDI\",\"yearOfManufacture\":2006,\"engineCapacity\":1968,\"co2Emissions\":154,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"BLACK\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2017-08-31\",\"motExpiryDate\":\"2023-07-27\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2006-09\"}', '2023-07-27', NULL, NULL, '2023-07-11 16:59:44', '2023-07-11 16:59:44'),
-- (47, 37, 'NK13UZE', 'TOYOTA', '2013', '{\"registrationNumber\":\"NK13UZE\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2023-10-01\",\"motStatus\":\"Valid\",\"make\":\"TOYOTA\",\"yearOfManufacture\":2013,\"engineCapacity\":998,\"co2Emissions\":111,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"WHITE\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2022-10-31\",\"motExpiryDate\":\"2023-09-01\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2013-03\"}', '2023-09-01', NULL, NULL, '2023-07-11 17:02:23', '2023-07-11 17:02:23'),
-- (48, 38, 'EF66FSX', 'FORD', '2016', '{\"registrationNumber\":\"EF66FSX\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-03-01\",\"motStatus\":\"Valid\",\"make\":\"FORD\",\"yearOfManufacture\":2016,\"engineCapacity\":2198,\"co2Emissions\":201,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"WHITE\",\"typeApproval\":\"N1\",\"revenueWeight\":3500,\"dateOfLastV5CIssued\":\"2023-03-28\",\"motExpiryDate\":\"2023-12-29\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2016-12\"}', '2023-12-29', NULL, NULL, '2023-07-11 17:04:23', '2023-07-11 17:04:23'),
-- (49, 38, 'WN66WOY', 'FORD', '2016', '{\"registrationNumber\":\"WN66WOY\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-05-01\",\"motStatus\":\"Valid\",\"make\":\"FORD\",\"yearOfManufacture\":2016,\"engineCapacity\":2198,\"co2Emissions\":197,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"SILVER\",\"typeApproval\":\"N1\",\"revenueWeight\":3100,\"dateOfLastV5CIssued\":\"2020-11-09\",\"motExpiryDate\":\"2024-04-27\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2016-09\"}', '2024-04-27', NULL, NULL, '2023-07-11 17:04:49', '2023-07-11 17:04:49'),
-- (50, 39, 'GX14ZHE', 'CITROEN', '2014', '{\"registrationNumber\":\"GX14ZHE\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-03-01\",\"motStatus\":\"Valid\",\"make\":\"CITROEN\",\"yearOfManufacture\":2014,\"engineCapacity\":1560,\"co2Emissions\":105,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"WHITE\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2021-03-28\",\"motExpiryDate\":\"2023-07-28\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2014-03\"}', '2023-07-28', NULL, NULL, '2023-07-11 17:07:46', '2023-07-11 17:07:46'),
-- (51, 40, 'MA12AHX', 'FORD', '2012', '{\"registrationNumber\":\"MA12AHX\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-03-01\",\"motStatus\":\"Valid\",\"make\":\"FORD\",\"yearOfManufacture\":2012,\"engineCapacity\":1242,\"co2Emissions\":129,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"BLACK\",\"typeApproval\":\"M1\",\"revenueWeight\":1495,\"dateOfLastV5CIssued\":\"2022-03-14\",\"motExpiryDate\":\"2024-03-27\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2012-03\"}', '2024-03-27', NULL, NULL, '2023-07-11 17:09:20', '2023-07-11 17:09:20'),
-- (52, 41, 'WU05EGY', 'VOLKSWAGEN', '2005', '{\"registrationNumber\":\"WU05EGY\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2023-09-01\",\"motStatus\":\"Valid\",\"make\":\"VOLKSWAGEN\",\"yearOfManufacture\":2005,\"engineCapacity\":1390,\"co2Emissions\":156,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"BLACK\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2019-07-18\",\"motExpiryDate\":\"2023-08-22\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2005-08\"}', '2023-08-22', NULL, NULL, '2023-07-11 17:10:16', '2023-07-11 17:10:16'),
-- (53, 10, 'WP16FPT', 'BMW', '2016', '{\"registrationNumber\":\"WP16FPT\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-06-01\",\"motStatus\":\"Valid\",\"make\":\"BMW\",\"yearOfManufacture\":2016,\"engineCapacity\":2993,\"co2Emissions\":158,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"BLACK\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2023-07-11\",\"motExpiryDate\":\"2024-06-22\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2016-05\"}', '2024-06-22', NULL, NULL, '2023-07-11 17:11:58', '2023-07-11 17:11:58'),
-- (54, 42, 'AP09CNJ', 'SUZUKI', '2009', '{\"registrationNumber\":\"AP09CNJ\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-03-01\",\"motStatus\":\"Valid\",\"make\":\"SUZUKI\",\"yearOfManufacture\":2009,\"engineCapacity\":996,\"co2Emissions\":122,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"BLUE\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2023-05-21\",\"motExpiryDate\":\"2023-07-28\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2009-07\"}', '2023-07-28', '120Km', NULL, '2023-07-11 17:13:16', '2024-02-12 14:02:52'),
-- (55, 10, 'GB11CCE', 'MG', '2019', '{\"registrationNumber\":\"GB11CCE\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2023-08-01\",\"motStatus\":\"Valid\",\"make\":\"MG\",\"yearOfManufacture\":2019,\"engineCapacity\":999,\"co2Emissions\":145,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"RED\",\"typeApproval\":\"M1\",\"revenueWeight\":1730,\"euroStatus\":\"EURO 6D\",\"dateOfLastV5CIssued\":\"2020-12-23\",\"motExpiryDate\":\"2023-08-18\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2019-08\"}', '2023-08-18', NULL, NULL, '2023-07-11 17:14:06', '2023-07-11 17:14:06'),
-- (56, 10, 'S100UNL', 'BMW', '2019', '{\"registrationNumber\":\"S100UNL\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-02-01\",\"motStatus\":\"Valid\",\"make\":\"BMW\",\"yearOfManufacture\":2019,\"engineCapacity\":1998,\"co2Emissions\":123,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"GREY\",\"typeApproval\":\"M1\",\"euroStatus\":\"EURO 6 DG\",\"dateOfLastV5CIssued\":\"2023-03-01\",\"motExpiryDate\":\"2024-02-06\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2019-09\"}', '2024-02-06', NULL, NULL, '2023-07-11 17:14:31', '2023-07-11 17:14:31'),
-- (57, 43, 'YR60JXM', 'BMW', '2010', '{\"registrationNumber\":\"YR60JXM\",\"taxStatus\":\"Untaxed\",\"taxDueDate\":\"2023-05-20\",\"motStatus\":\"Valid\",\"make\":\"BMW\",\"yearOfManufacture\":2010,\"engineCapacity\":1995,\"co2Emissions\":109,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"SILVER\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2014-11-27\",\"motExpiryDate\":\"2023-07-27\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2010-10\"}', '2023-07-27', NULL, NULL, '2023-07-11 17:15:34', '2023-07-11 17:15:34'),
-- (58, 44, 'YR62UDL', 'MINI', '2012', '{\"registrationNumber\":\"YR62UDL\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2023-10-01\",\"motStatus\":\"Valid\",\"make\":\"MINI\",\"yearOfManufacture\":2012,\"engineCapacity\":1598,\"co2Emissions\":115,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"WHITE\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2014-12-16\",\"motExpiryDate\":\"2023-11-10\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2012-09\"}', '2023-11-10', NULL, NULL, '2023-07-11 17:16:42', '2023-07-11 17:16:42'),
-- (59, 45, 'BT12XWR', 'FORD', '2012', '{\"registrationNumber\":\"BT12XWR\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2023-11-01\",\"motStatus\":\"Valid\",\"make\":\"FORD\",\"yearOfManufacture\":2012,\"engineCapacity\":1560,\"co2Emissions\":114,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"SILVER\",\"typeApproval\":\"M1\",\"revenueWeight\":2155,\"dateOfLastV5CIssued\":\"2021-10-07\",\"motExpiryDate\":\"2023-08-27\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2012-06\"}', '2023-08-27', NULL, NULL, '2023-07-11 17:18:01', '2023-07-11 17:18:01'),
-- (60, 46, 'VA14HTC', 'NISSAN', '2014', '{\"registrationNumber\":\"VA14HTC\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2023-08-01\",\"motStatus\":\"Valid\",\"make\":\"NISSAN\",\"yearOfManufacture\":2014,\"engineCapacity\":1198,\"co2Emissions\":129,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"WHITE\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2020-08-14\",\"motExpiryDate\":\"2023-08-01\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2014-06\"}', '2023-08-01', NULL, NULL, '2023-07-11 17:19:32', '2023-07-11 17:19:32'),
-- (61, 47, 'RO57YSS', 'BMW', '2007', '{\"registrationNumber\":\"RO57YSS\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-01-01\",\"motStatus\":\"Valid\",\"make\":\"BMW\",\"yearOfManufacture\":2007,\"engineCapacity\":1995,\"co2Emissions\":185,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"BLUE\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2017-01-05\",\"motExpiryDate\":\"2023-08-11\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2007-09\"}', '2023-08-11', NULL, NULL, '2023-07-11 17:21:10', '2023-07-11 17:21:10'),
-- (62, 48, 'S8NTK', 'VOLKSWAGEN', '2011', '{\"registrationNumber\":\"S8NTK\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2023-08-01\",\"motStatus\":\"Valid\",\"make\":\"VOLKSWAGEN\",\"yearOfManufacture\":2011,\"engineCapacity\":1598,\"co2Emissions\":107,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"SILVER\",\"typeApproval\":\"M1\",\"revenueWeight\":1840,\"dateOfLastV5CIssued\":\"2021-09-25\",\"motExpiryDate\":\"2023-08-25\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2011-03\"}', '2023-08-25', NULL, NULL, '2023-07-11 17:31:44', '2023-07-11 17:31:44'),
-- (63, 6, 'KN67MWD', 'LAND ROVER', '2017', '{\"registrationNumber\":\"KN67MWD\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2023-11-01\",\"artEndDate\":\"2023-08-31\",\"motStatus\":\"Valid\",\"make\":\"LAND ROVER\",\"yearOfManufacture\":2017,\"engineCapacity\":1999,\"co2Emissions\":134,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"BLACK\",\"typeApproval\":\"M1\",\"revenueWeight\":2350,\"dateOfLastV5CIssued\":\"2022-11-05\",\"motExpiryDate\":\"2023-08-04\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2017-09\"}', '2023-08-04', NULL, NULL, '2023-07-11 17:33:00', '2023-07-11 17:33:00'),
-- (64, 49, 'BN59FWT', 'NISSAN', '2009', '{\"registrationNumber\":\"BN59FWT\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2023-08-01\",\"motStatus\":\"Valid\",\"make\":\"NISSAN\",\"yearOfManufacture\":2009,\"engineCapacity\":1598,\"co2Emissions\":159,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"BLACK\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2020-08-07\",\"motExpiryDate\":\"2023-08-07\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2009-09\"}', '2023-08-07', NULL, NULL, '2023-07-11 17:34:36', '2023-07-11 17:34:36'),
-- (65, 50, 'KT60ODE', 'VOLVO', '2010', '{\"registrationNumber\":\"KT60ODE\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2023-10-01\",\"motStatus\":\"Valid\",\"make\":\"VOLVO\",\"yearOfManufacture\":2010,\"engineCapacity\":2400,\"co2Emissions\":219,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"WHITE\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2017-03-08\",\"motExpiryDate\":\"2023-09-30\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2010-09\"}', '2023-09-30', NULL, NULL, '2023-07-12 08:09:13', '2023-07-12 08:09:13'),
-- (66, 50, 'YA52YVE', 'HONDA', '2003', '{\"registrationNumber\":\"YA52YVE\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2023-10-01\",\"motStatus\":\"Valid\",\"make\":\"HONDA\",\"yearOfManufacture\":2003,\"engineCapacity\":1997,\"co2Emissions\":209,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"SILVER\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2018-10-30\",\"motExpiryDate\":\"2024-02-19\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2003-01\"}', '2024-02-19', NULL, NULL, '2023-07-12 08:09:58', '2023-07-12 08:09:58'),
-- (67, 50, 'M30ODG', 'BMW', '2005', '{\"registrationNumber\":\"M30ODG\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2023-11-01\",\"motStatus\":\"Valid\",\"make\":\"BMW\",\"yearOfManufacture\":2005,\"engineCapacity\":2993,\"co2Emissions\":213,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"SILVER\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2018-03-17\",\"motExpiryDate\":\"2023-09-29\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2005-06\"}', '2023-09-29', NULL, NULL, '2023-07-12 08:10:17', '2023-07-12 08:10:17'),
-- (68, 50, 'H20LLG', 'BMW', '2008', '{\"registrationNumber\":\"H20LLG\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2023-11-01\",\"motStatus\":\"Valid\",\"make\":\"BMW\",\"yearOfManufacture\":2008,\"engineCapacity\":2993,\"co2Emissions\":216,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"BLACK\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2019-12-19\",\"motExpiryDate\":\"2023-08-12\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2008-12\"}', '2023-08-12', NULL, NULL, '2023-07-12 08:10:35', '2023-07-12 08:10:35'),
-- (69, 50, 'YS56UZO', 'HONDA', '2007', '{\"registrationNumber\":\"YS56UZO\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-02-01\",\"motStatus\":\"Valid\",\"make\":\"HONDA\",\"yearOfManufacture\":2007,\"engineCapacity\":1339,\"co2Emissions\":137,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"GREY\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2023-02-06\",\"motExpiryDate\":\"2024-01-31\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2007-01\"}', '2024-01-31', NULL, NULL, '2023-07-12 08:10:54', '2023-07-12 08:10:54'),
-- (70, 50, 'P454POT', 'MAZDA', '1997', '{\"registrationNumber\":\"P454POT\",\"taxStatus\":\"Untaxed\",\"taxDueDate\":\"2023-07-01\",\"motStatus\":\"Not valid\",\"make\":\"MAZDA\",\"yearOfManufacture\":1997,\"engineCapacity\":1839,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"GREEN\",\"dateOfLastV5CIssued\":\"2020-01-15\",\"motExpiryDate\":\"2023-06-28\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"1997-03\"}', '2023-06-28', NULL, NULL, '2023-07-12 08:11:12', '2023-07-12 08:11:12'),
-- (71, 26, 'GH16JHE', 'BMW', '2016', '{\"registrationNumber\":\"GH16JHE\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2023-08-01\",\"motStatus\":\"Valid\",\"make\":\"BMW\",\"yearOfManufacture\":2016,\"engineCapacity\":2979,\"co2Emissions\":203,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"ORANGE\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2022-09-13\",\"motExpiryDate\":\"2024-02-24\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2016-06\"}', '2024-02-24', NULL, NULL, '2023-07-12 08:13:57', '2023-07-12 08:13:57'),
-- (72, 26, 'D12KAC', 'FERRARI', '2011', '{\"registrationNumber\":\"D12KAC\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2023-09-01\",\"motStatus\":\"Valid\",\"make\":\"FERRARI\",\"yearOfManufacture\":2011,\"engineCapacity\":4497,\"co2Emissions\":307,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"RED\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2020-09-17\",\"motExpiryDate\":\"2023-09-08\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2011-09\"}', '2023-09-08', NULL, NULL, '2023-07-12 08:14:16', '2023-07-12 08:14:16'),
-- (73, 51, 'FG04GXN', 'TOYOTA', '2004', '{\"registrationNumber\":\"FG04GXN\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-05-01\",\"motStatus\":\"Valid\",\"make\":\"TOYOTA\",\"yearOfManufacture\":2004,\"engineCapacity\":1794,\"co2Emissions\":171,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"BLACK\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2022-11-18\",\"motExpiryDate\":\"2023-12-07\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2004-03\"}', '2023-12-07', NULL, NULL, '2023-07-12 08:15:21', '2023-07-12 08:15:21'),
-- (74, 52, 'Y77ESA', 'BMW', '2013', '{\"registrationNumber\":\"Y77ESA\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-03-01\",\"motStatus\":\"Valid\",\"make\":\"BMW\",\"yearOfManufacture\":2013,\"engineCapacity\":2993,\"co2Emissions\":145,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"WHITE\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2022-03-03\",\"motExpiryDate\":\"2024-01-02\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2013-03\"}', '2024-01-02', NULL, NULL, '2023-07-12 08:16:18', '2023-07-12 08:16:18'),
-- (75, 52, 'Y77SUM', 'NISSAN', '2012', '{\"registrationNumber\":\"Y77SUM\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-02-01\",\"motStatus\":\"Valid\",\"make\":\"NISSAN\",\"yearOfManufacture\":2012,\"engineCapacity\":1598,\"co2Emissions\":139,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"WHITE\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2019-02-26\",\"motExpiryDate\":\"2023-11-25\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2012-12\"}', '2023-11-25', NULL, NULL, '2023-07-12 08:16:40', '2023-07-12 08:16:40'),
-- (76, 52, 'RR56ART', 'SKODA', '2008', '{\"registrationNumber\":\"RR56ART\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2023-08-01\",\"motStatus\":\"Valid\",\"make\":\"SKODA\",\"yearOfManufacture\":2008,\"engineCapacity\":1968,\"co2Emissions\":159,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"GREY\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2021-10-09\",\"motExpiryDate\":\"2023-12-16\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2008-12\"}', '2023-12-16', NULL, NULL, '2023-07-12 08:16:58', '2023-07-12 08:16:58'),
-- (77, 52, 'NG61XSC', 'NISSAN', '2011', '{\"registrationNumber\":\"NG61XSC\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-02-01\",\"motStatus\":\"Valid\",\"make\":\"NISSAN\",\"yearOfManufacture\":2011,\"engineCapacity\":1461,\"co2Emissions\":137,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"BLACK\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2019-01-28\",\"motExpiryDate\":\"2023-11-24\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2011-11\"}', '2023-11-24', NULL, NULL, '2023-07-12 08:17:41', '2023-07-12 08:17:41'),
-- (78, 53, 'VE62SVF', 'SEAT', '2012', '{\"registrationNumber\":\"VE62SVF\",\"taxStatus\":\"Untaxed\",\"taxDueDate\":\"2023-07-01\",\"motStatus\":\"Valid\",\"make\":\"SEAT\",\"yearOfManufacture\":2012,\"engineCapacity\":1968,\"co2Emissions\":129,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"BLACK\",\"typeApproval\":\"M1\",\"revenueWeight\":1990,\"dateOfLastV5CIssued\":\"2016-12-08\",\"motExpiryDate\":\"2023-08-18\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2012-12\"}', '2023-08-18', NULL, NULL, '2023-07-12 08:18:50', '2023-07-12 08:18:50'),
-- (79, 53, 'ASR231T', 'LAND ROVER', '2014', '{\"registrationNumber\":\"ASR231T\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-02-01\",\"motStatus\":\"Valid\",\"make\":\"LAND ROVER\",\"yearOfManufacture\":2014,\"engineCapacity\":2993,\"co2Emissions\":199,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"GREY\",\"typeApproval\":\"M1\",\"revenueWeight\":3000,\"dateOfLastV5CIssued\":\"2019-10-21\",\"motExpiryDate\":\"2024-02-14\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2014-09\"}', '2024-02-14', NULL, NULL, '2023-07-12 08:19:10', '2023-07-12 08:19:10'),
-- (80, 54, 'BF16YFM', 'PEUGEOT', '2016', '{\"registrationNumber\":\"BF16YFM\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-05-01\",\"motStatus\":\"Valid\",\"make\":\"PEUGEOT\",\"yearOfManufacture\":2016,\"engineCapacity\":1997,\"co2Emissions\":168,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"WHITE\",\"typeApproval\":\"N1\",\"dateOfLastV5CIssued\":\"2020-05-20\",\"motExpiryDate\":\"2023-11-13\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2016-05\"}', '2023-11-13', NULL, NULL, '2023-07-13 10:00:39', '2023-07-13 10:00:39'),
-- (81, 54, 'N44RRU', 'AUDI', '2011', '{\"registrationNumber\":\"N44RRU\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-03-01\",\"motStatus\":\"Valid\",\"make\":\"AUDI\",\"yearOfManufacture\":2011,\"engineCapacity\":1968,\"co2Emissions\":120,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"GREY\",\"typeApproval\":\"M1\",\"revenueWeight\":2025,\"dateOfLastV5CIssued\":\"2017-05-10\",\"motExpiryDate\":\"2024-05-14\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2011-10\"}', '2024-05-14', NULL, NULL, '2023-07-13 10:01:00', '2023-07-13 10:01:00'),
-- (82, 55, 'SA13DXV', 'PEUGEOT', '2013', '{\"registrationNumber\":\"SA13DXV\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2023-08-01\",\"motStatus\":\"Valid\",\"make\":\"PEUGEOT\",\"yearOfManufacture\":2013,\"engineCapacity\":1398,\"co2Emissions\":98,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"BLUE\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2022-08-02\",\"motExpiryDate\":\"2023-07-24\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2013-06\"}', '2023-07-24', NULL, NULL, '2023-07-13 10:56:39', '2023-07-13 10:56:39'),
-- (83, 32, 'FT60HLW', 'BMW', '2011', '{\"registrationNumber\":\"FT60HLW\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-06-01\",\"motStatus\":\"Valid\",\"make\":\"BMW\",\"yearOfManufacture\":2011,\"engineCapacity\":1995,\"co2Emissions\":119,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"WHITE\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2014-07-03\",\"motExpiryDate\":\"2023-07-18\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2011-01\"}', '2023-07-18', NULL, NULL, '2023-07-14 07:21:56', '2023-07-14 07:21:56'),
-- (84, 56, 'SB08PWX', 'VAUXHALL', '2008', '{\"registrationNumber\":\"SB08PWX\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2023-12-01\",\"motStatus\":\"Valid\",\"make\":\"VAUXHALL\",\"yearOfManufacture\":2008,\"engineCapacity\":1598,\"co2Emissions\":185,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"BLUE\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2022-03-24\",\"motExpiryDate\":\"2024-06-04\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2008-05\"}', '2024-06-04', NULL, NULL, '2023-07-19 12:46:19', '2023-07-19 12:46:19'),
-- (85, 57, 'SC56XRJ', 'CITROEN', '2007', '{\"registrationNumber\":\"SC56XRJ\",\"taxStatus\":\"SORN\",\"motStatus\":\"Not valid\",\"make\":\"CITROEN\",\"yearOfManufacture\":2007,\"engineCapacity\":998,\"co2Emissions\":109,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"RED\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2021-11-14\",\"motExpiryDate\":\"2023-04-20\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2007-02\"}', '2023-04-20', NULL, NULL, '2023-07-19 16:03:00', '2023-07-19 16:03:00'),
-- (86, 57, 'BL04KAA', 'MERCEDES', '2004', '{\"registrationNumber\":\"BL04KAA\",\"taxStatus\":\"Untaxed\",\"taxDueDate\":\"2023-07-16\",\"motStatus\":\"Valid\",\"make\":\"MERCEDES\",\"yearOfManufacture\":2004,\"engineCapacity\":1998,\"co2Emissions\":221,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"SILVER\",\"typeApproval\":\"M1\",\"revenueWeight\":1625,\"dateOfLastV5CIssued\":\"2022-10-13\",\"motExpiryDate\":\"2023-09-28\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2004-05\"}', '2023-09-28', NULL, NULL, '2023-07-19 16:05:38', '2023-07-19 16:05:38'),
-- (87, 58, 'SP14HLW', 'PEUGEOT', '2014', '{\"registrationNumber\":\"SP14HLW\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2023-11-01\",\"motStatus\":\"Not valid\",\"make\":\"PEUGEOT\",\"yearOfManufacture\":2014,\"engineCapacity\":998,\"co2Emissions\":99,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"RED\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2022-11-17\",\"motExpiryDate\":\"2023-07-08\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2014-03\"}', '2023-07-08', NULL, NULL, '2023-07-31 17:23:42', '2023-07-31 17:23:42'),
-- (88, 59, 'FE14GAO', 'TOYOTA', '2014', '{\"registrationNumber\":\"FE14GAO\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-03-01\",\"motStatus\":\"Valid\",\"make\":\"TOYOTA\",\"yearOfManufacture\":2014,\"engineCapacity\":998,\"co2Emissions\":111,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"RED\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2017-03-17\",\"motExpiryDate\":\"2024-03-30\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2014-03\"}', '2024-03-30', NULL, NULL, '2023-08-03 10:38:13', '2023-08-03 10:38:13'),
-- (89, 60, 'FE68ZGT', 'KIA', '2018', '{\"registrationNumber\":\"FE68ZGT\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2023-09-01\",\"motStatus\":\"Valid\",\"make\":\"KIA\",\"yearOfManufacture\":2018,\"engineCapacity\":1685,\"co2Emissions\":127,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"BLACK\",\"typeApproval\":\"M1\",\"revenueWeight\":1600,\"dateOfLastV5CIssued\":\"2023-07-10\",\"motExpiryDate\":\"2023-08-08\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2018-09\"}', '2023-08-08', NULL, NULL, '2023-08-04 13:45:16', '2023-08-04 13:45:16'),
-- (90, 61, 'HT07CKU', 'MERCEDES', '2007', '{\"registrationNumber\":\"HT07CKU\",\"taxStatus\":\"SORN\",\"motStatus\":\"Not valid\",\"make\":\"MERCEDES\",\"yearOfManufacture\":2007,\"engineCapacity\":2987,\"co2Emissions\":254,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"BLACK\",\"typeApproval\":\"M1\",\"revenueWeight\":2830,\"dateOfLastV5CIssued\":\"2022-12-14\",\"motExpiryDate\":\"2023-05-03\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2007-07\"}', '2023-05-03', NULL, NULL, '2023-08-10 09:45:23', '2023-08-10 09:45:23'),
-- (91, 3, 'EO59UEZ', 'FORD', '2009', '{\"registrationNumber\":\"EO59UEZ\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-03-01\",\"motStatus\":\"Valid\",\"make\":\"FORD\",\"yearOfManufacture\":2009,\"engineCapacity\":1242,\"co2Emissions\":133,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"BLUE\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2020-03-12\",\"motExpiryDate\":\"2024-03-07\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2009-09\"}', '2024-03-07', NULL, NULL, '2023-08-16 15:15:02', '2023-08-16 15:15:02'),
-- (92, 62, 'H894RAX', 'ROVER', '1991', '{\"registrationNumber\":\"H894RAX\",\"taxStatus\":\"SORN\",\"motStatus\":\"Not valid\",\"make\":\"ROVER\",\"yearOfManufacture\":1991,\"engineCapacity\":1598,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"RED\",\"dateOfLastV5CIssued\":\"2019-09-27\",\"motExpiryDate\":\"2023-03-29\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"1991-06\"}', '2023-03-29', NULL, NULL, '2023-08-17 20:16:14', '2023-08-17 20:16:14'),
-- (93, 63, 'N124FLK', 'MERCEDES', '1995', '{\"registrationNumber\":\"N124FLK\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2023-12-01\",\"motStatus\":\"Valid\",\"make\":\"MERCEDES\",\"yearOfManufacture\":1995,\"engineCapacity\":2199,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"BLACK\",\"dateOfLastV5CIssued\":\"2012-02-15\",\"motExpiryDate\":\"2023-11-19\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"1995-09\"}', '2023-11-19', NULL, NULL, '2023-09-01 15:11:45', '2023-09-01 15:11:45');
-- INSERT INTO `cars` (`id`, `customer_id`, `registration_number`, `make`, `year_of_manufacture`, `data`, `mot_expiry_date`, `mileage`, `deleted_at`, `created_at`, `updated_at`) VALUES
-- (94, 64, 'WJ06DZC', 'VAUXHALL', '2006', '{\"registrationNumber\":\"WJ06DZC\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-08-01\",\"motStatus\":\"Valid\",\"make\":\"VAUXHALL\",\"yearOfManufacture\":2006,\"engineCapacity\":1229,\"co2Emissions\":139,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"BLUE\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2023-08-01\",\"motExpiryDate\":\"2023-12-06\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2006-03\"}', '2023-12-06', NULL, NULL, '2023-09-01 15:13:15', '2023-09-01 15:13:15'),
-- (95, 30, 'GA14MAD', 'MERCEDES-BENZ', '2018', '{\"registrationNumber\":\"GA14MAD\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-03-01\",\"motStatus\":\"Valid\",\"make\":\"MERCEDES-BENZ\",\"yearOfManufacture\":2018,\"engineCapacity\":1950,\"co2Emissions\":122,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"BLACK\",\"typeApproval\":\"M1\",\"revenueWeight\":2375,\"dateOfLastV5CIssued\":\"2022-08-17\",\"motExpiryDate\":\"2023-10-26\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2018-09\"}', '2023-10-26', NULL, NULL, '2023-09-06 10:20:27', '2023-09-06 10:20:27'),
-- (96, 65, 'FM56YSX', 'NISSAN', '2007', '{\"registrationNumber\":\"FM56YSX\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-02-01\",\"motStatus\":\"Not valid\",\"make\":\"NISSAN\",\"yearOfManufacture\":2007,\"engineCapacity\":1990,\"co2Emissions\":0,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"RED\",\"dateOfLastV5CIssued\":\"2019-09-13\",\"motExpiryDate\":\"2023-08-02\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2007-01\",\"monthOfFirstDvlaRegistration\":\"2019-08\"}', '2023-08-02', NULL, NULL, '2023-09-06 12:03:30', '2023-09-06 12:03:30'),
-- (97, 66, 'WL13AXM', 'VOLKSWAGEN', '2013', '{\"registrationNumber\":\"WL13AXM\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2023-12-01\",\"motStatus\":\"Valid\",\"make\":\"VOLKSWAGEN\",\"yearOfManufacture\":2013,\"engineCapacity\":1390,\"co2Emissions\":134,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"SILVER\",\"typeApproval\":\"M1\",\"revenueWeight\":1580,\"dateOfLastV5CIssued\":\"2023-01-16\",\"motExpiryDate\":\"2023-09-19\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2013-07\"}', '2023-09-19', NULL, NULL, '2023-09-16 12:55:21', '2023-09-16 12:55:21'),
-- (98, 67, 'FG06LVB', 'TOYOTA', '2006', '{\"registrationNumber\":\"FG06LVB\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2023-10-01\",\"motStatus\":\"Valid\",\"make\":\"TOYOTA\",\"yearOfManufacture\":2006,\"engineCapacity\":1296,\"co2Emissions\":141,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"BLACK\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2011-10-26\",\"motExpiryDate\":\"2024-09-28\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2006-03\"}', '2024-09-28', NULL, NULL, '2023-09-20 08:39:58', '2023-09-20 08:39:58'),
-- (99, 68, 'SH59WPA', 'VOLVO', '2009', '{\"registrationNumber\":\"SH59WPA\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2023-11-01\",\"motStatus\":\"Valid\",\"make\":\"VOLVO\",\"yearOfManufacture\":2009,\"engineCapacity\":1560,\"co2Emissions\":119,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"RED\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2022-11-16\",\"motExpiryDate\":\"2023-10-11\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2009-11\"}', '2023-10-11', NULL, NULL, '2023-09-21 08:48:16', '2023-09-21 08:48:16'),
-- (100, 69, 'WN11EPE', 'LEXUS', '2011', '{\"registrationNumber\":\"WN11EPE\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2023-11-01\",\"motStatus\":\"Valid\",\"make\":\"LEXUS\",\"yearOfManufacture\":2011,\"engineCapacity\":1791,\"co2Emissions\":94,\"fuelType\":\"HYBRID ELECTRIC\",\"markedForExport\":false,\"colour\":\"BLUE\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2022-11-23\",\"motExpiryDate\":\"2024-09-17\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2011-03\"}', '2024-09-17', NULL, NULL, '2023-09-21 15:20:39', '2023-09-21 15:20:39'),
-- (101, 69, 'PF56PWY', 'HONDA', '2007', '{\"registrationNumber\":\"PF56PWY\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2023-12-01\",\"motStatus\":\"Valid\",\"make\":\"HONDA\",\"yearOfManufacture\":2007,\"engineCapacity\":1339,\"co2Emissions\":139,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"SILVER\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2022-12-05\",\"motExpiryDate\":\"2024-03-11\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2007-02\"}', '2024-03-11', NULL, NULL, '2023-09-21 15:21:16', '2023-09-21 15:21:16'),
-- (102, 70, 'LX61HZS', 'HONDA', '2011', '{\"registrationNumber\":\"LX61HZS\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-01-01\",\"motStatus\":\"Valid\",\"make\":\"HONDA\",\"yearOfManufacture\":2011,\"engineCapacity\":1330,\"co2Emissions\":0,\"fuelType\":\"HYBRID ELECTRIC\",\"markedForExport\":false,\"colour\":\"WHITE\",\"dateOfLastV5CIssued\":\"2022-01-26\",\"motExpiryDate\":\"2023-11-07\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2011-11\",\"monthOfFirstDvlaRegistration\":\"2021-12\"}', '2023-11-07', NULL, NULL, '2023-10-06 16:15:38', '2023-10-06 16:15:38'),
-- (103, 71, 'FL60VUA', 'VOLKSWAGEN', '2010', '{\"registrationNumber\":\"FL60VUA\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-04-01\",\"motStatus\":\"Valid\",\"make\":\"VOLKSWAGEN\",\"yearOfManufacture\":2010,\"engineCapacity\":1198,\"co2Emissions\":139,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"GREY\",\"typeApproval\":\"M1\",\"revenueWeight\":1480,\"dateOfLastV5CIssued\":\"2010-09-30\",\"motExpiryDate\":\"2023-10-07\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2010-09\"}', '2023-10-07', NULL, NULL, '2023-10-06 16:17:26', '2023-10-06 16:17:26'),
-- (104, 6, 'M44NLX', 'LAND ROVER', '2012', '{\"registrationNumber\":\"M44NLX\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-11-01\",\"motStatus\":\"Valid\",\"make\":\"LAND ROVER\",\"yearOfManufacture\":2012,\"engineCapacity\":2179,\"co2Emissions\":174,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"WHITE\",\"typeApproval\":\"M1\",\"revenueWeight\":2350,\"dateOfLastV5CIssued\":\"2020-11-04\",\"motExpiryDate\":\"2023-12-16\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2012-03\"}', '2023-12-16', NULL, NULL, '2023-12-01 08:43:05', '2023-12-01 08:43:05'),
-- (105, 6, 'ET07PWE', 'HYUNDAI', '2007', '{\"registrationNumber\":\"ET07PWE\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-06-01\",\"motStatus\":\"Valid\",\"make\":\"HYUNDAI\",\"yearOfManufacture\":2007,\"engineCapacity\":1975,\"co2Emissions\":203,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"SILVER\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2022-07-02\",\"motExpiryDate\":\"2023-12-09\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2007-07\"}', '2023-12-09', NULL, NULL, '2023-12-01 08:52:38', '2023-12-01 08:52:38'),
-- (106, 58, 'FH03YFX', 'FIAT', '2003', '{\"registrationNumber\":\"FH03YFX\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-03-01\",\"motStatus\":\"Valid\",\"make\":\"FIAT\",\"yearOfManufacture\":2003,\"engineCapacity\":1242,\"co2Emissions\":136,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"BLACK\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2022-03-21\",\"motExpiryDate\":\"2023-12-12\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2003-06\"}', '2023-12-12', NULL, NULL, '2023-12-01 08:55:08', '2023-12-01 08:55:08'),
-- (107, 72, 'PK15OLM', 'MERCEDES-BENZ', '2015', '{\"registrationNumber\":\"PK15OLM\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-01-01\",\"motStatus\":\"Valid\",\"make\":\"MERCEDES-BENZ\",\"yearOfManufacture\":2015,\"engineCapacity\":2143,\"co2Emissions\":129,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"GREY\",\"typeApproval\":\"M1\",\"revenueWeight\":2275,\"dateOfLastV5CIssued\":\"2020-01-29\",\"motExpiryDate\":\"2023-12-18\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2015-04\"}', '2023-12-18', NULL, NULL, '2023-12-01 08:56:30', '2023-12-01 08:56:30'),
-- (108, 6, 'YC09LUD', 'BMW', '2009', '{\"registrationNumber\":\"YC09LUD\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-06-01\",\"motStatus\":\"Valid\",\"make\":\"BMW\",\"yearOfManufacture\":2009,\"engineCapacity\":2993,\"co2Emissions\":164,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"WHITE\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2017-06-13\",\"motExpiryDate\":\"2023-12-12\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2009-08\"}', '2023-12-12', NULL, NULL, '2023-12-01 08:57:00', '2023-12-01 08:57:00'),
-- (109, 73, 'K44DCR', 'VOLKSWAGEN', '1998', '{\"registrationNumber\":\"K44DCR\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-12-01\",\"motStatus\":\"Valid\",\"make\":\"VOLKSWAGEN\",\"yearOfManufacture\":1998,\"engineCapacity\":1896,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"BLUE\",\"dateOfLastV5CIssued\":\"2018-01-17\",\"motExpiryDate\":\"2023-12-18\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"1998-08\"}', '2023-12-18', NULL, NULL, '2023-12-01 08:57:57', '2023-12-01 08:57:57'),
-- (110, 50, 'GF55UNS', 'MAZDA', '2005', '{\"registrationNumber\":\"GF55UNS\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-11-01\",\"motStatus\":\"Valid\",\"make\":\"MAZDA\",\"yearOfManufacture\":2005,\"engineCapacity\":1999,\"co2Emissions\":198,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"RED\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2019-11-22\",\"motExpiryDate\":\"2023-12-09\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2005-12\"}', '2023-12-09', NULL, NULL, '2023-12-01 08:58:31', '2023-12-01 08:58:31'),
-- (111, 73, 'HU56EYN', 'MERCEDES-BENZ', '2009', '{\"registrationNumber\":\"HU56EYN\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-10-01\",\"motStatus\":\"Valid\",\"make\":\"MERCEDES-BENZ\",\"yearOfManufacture\":2009,\"engineCapacity\":2143,\"co2Emissions\":156,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"GREY\",\"typeApproval\":\"M1\",\"revenueWeight\":2280,\"dateOfLastV5CIssued\":\"2019-07-15\",\"motExpiryDate\":\"2023-12-16\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2009-11\"}', '2023-12-16', NULL, NULL, '2023-12-01 08:59:18', '2023-12-01 08:59:18'),
-- (112, 74, 'VE54BOU', 'TOYOTA', '2004', '{\"registrationNumber\":\"VE54BOU\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-03-01\",\"motStatus\":\"Valid\",\"make\":\"TOYOTA\",\"yearOfManufacture\":2004,\"engineCapacity\":1995,\"co2Emissions\":191,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"RED\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2023-05-22\",\"motExpiryDate\":\"2023-12-12\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2004-11\"}', '2023-12-12', NULL, NULL, '2023-12-01 10:19:26', '2023-12-01 10:19:26'),
-- (113, 75, 'YX60VLN', 'HYUNDAI', '2010', '{\"registrationNumber\":\"YX60VLN\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-03-01\",\"motStatus\":\"Valid\",\"make\":\"HYUNDAI\",\"yearOfManufacture\":2010,\"engineCapacity\":1396,\"co2Emissions\":142,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"BLACK\",\"typeApproval\":\"M1\",\"revenueWeight\":1268,\"dateOfLastV5CIssued\":\"2023-06-30\",\"motExpiryDate\":\"2024-01-23\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2010-09\"}', '2024-01-23', NULL, NULL, '2023-12-07 17:20:12', '2023-12-07 17:20:12'),
-- (114, 6, 'NV15TNF', 'VAUXHALL', '2015', '{\"registrationNumber\":\"NV15TNF\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-12-01\",\"motStatus\":\"Valid\",\"make\":\"VAUXHALL\",\"yearOfManufacture\":2015,\"engineCapacity\":1398,\"co2Emissions\":136,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"BLACK\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2018-06-18\",\"motExpiryDate\":\"2023-12-22\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2015-06\"}', '2023-12-22', NULL, NULL, '2023-12-07 17:25:26', '2023-12-07 17:25:26'),
-- (115, 6, 'FP60DWG', 'VOLKSWAGEN', '2010', '{\"registrationNumber\":\"FP60DWG\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-05-01\",\"motStatus\":\"Valid\",\"make\":\"VOLKSWAGEN\",\"yearOfManufacture\":2010,\"engineCapacity\":1198,\"co2Emissions\":128,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"BLACK\",\"typeApproval\":\"M1\",\"revenueWeight\":1550,\"dateOfLastV5CIssued\":\"2023-05-13\",\"motExpiryDate\":\"2024-04-21\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2010-12\"}', '2024-04-21', NULL, NULL, '2023-12-07 17:25:49', '2023-12-07 17:25:49'),
-- (116, 76, 'FD56SRY', 'MERCEDES', '2007', '{\"registrationNumber\":\"FD56SRY\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-12-01\",\"motStatus\":\"Valid\",\"make\":\"MERCEDES\",\"yearOfManufacture\":2007,\"engineCapacity\":2987,\"co2Emissions\":246,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"SILVER\",\"typeApproval\":\"M1\",\"revenueWeight\":2865,\"dateOfLastV5CIssued\":\"2023-01-18\",\"motExpiryDate\":\"2023-12-16\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2007-02\"}', '2023-12-16', NULL, NULL, '2023-12-07 17:26:38', '2023-12-07 17:26:38'),
-- (117, 67, 'TA16LHA', 'MERCEDES-BENZ', '2016', '{\"registrationNumber\":\"TA16LHA\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-07-01\",\"motStatus\":\"Valid\",\"make\":\"MERCEDES-BENZ\",\"yearOfManufacture\":2016,\"engineCapacity\":2143,\"co2Emissions\":127,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"BLUE\",\"typeApproval\":\"M1\",\"revenueWeight\":2075,\"dateOfLastV5CIssued\":\"2019-07-23\",\"motExpiryDate\":\"2024-08-31\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2016-09\"}', '2024-08-31', NULL, NULL, '2023-12-09 09:45:25', '2023-12-09 09:45:25'),
-- (118, 77, 'YS63VSO', 'KIA', '2014', '{\"registrationNumber\":\"YS63VSO\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-04-01\",\"motStatus\":\"Valid\",\"make\":\"KIA\",\"yearOfManufacture\":2014,\"engineCapacity\":1582,\"co2Emissions\":100,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"WHITE\",\"typeApproval\":\"M1\",\"revenueWeight\":1415,\"dateOfLastV5CIssued\":\"2023-04-03\",\"motExpiryDate\":\"2024-01-11\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2014-01\"}', '2024-01-11', NULL, NULL, '2023-12-09 09:59:43', '2023-12-09 09:59:43'),
-- (119, 78, 'BG59ZLU', 'MERCEDES', '2009', '{\"registrationNumber\":\"BG59ZLU\",\"taxStatus\":\"Untaxed\",\"taxDueDate\":\"2023-07-01\",\"motStatus\":\"Valid\",\"make\":\"MERCEDES\",\"yearOfManufacture\":2009,\"engineCapacity\":1991,\"co2Emissions\":147,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"BLACK\",\"typeApproval\":\"M1\",\"revenueWeight\":1830,\"dateOfLastV5CIssued\":\"2021-09-28\",\"motExpiryDate\":\"2023-12-19\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2009-12\"}', '2023-12-19', NULL, NULL, '2023-12-16 15:10:57', '2023-12-16 15:10:57'),
-- (120, 78, 'EJ17YXD', 'AUDI', '2017', '{\"registrationNumber\":\"EJ17YXD\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-08-01\",\"motStatus\":\"Valid\",\"make\":\"AUDI\",\"yearOfManufacture\":2017,\"engineCapacity\":1395,\"co2Emissions\":138,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"GREY\",\"typeApproval\":\"M1\",\"revenueWeight\":2005,\"dateOfLastV5CIssued\":\"2021-09-19\",\"motExpiryDate\":\"2024-07-11\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2017-05\"}', '2024-07-11', NULL, NULL, '2023-12-16 15:11:24', '2023-12-16 15:11:24'),
-- (121, 78, 'EY15KZH', 'BENTLEY', '2015', '{\"registrationNumber\":\"EY15KZH\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-02-01\",\"motStatus\":\"Not valid\",\"make\":\"BENTLEY\",\"yearOfManufacture\":2015,\"engineCapacity\":5998,\"co2Emissions\":343,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"BLACK\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2021-07-28\",\"motExpiryDate\":\"2023-07-14\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2015-05\"}', '2023-07-14', NULL, NULL, '2023-12-16 15:11:40', '2023-12-16 15:11:40'),
-- (122, 79, 'DU65WZC', 'NISSAN', '2015', '{\"registrationNumber\":\"DU65WZC\",\"taxStatus\":\"SORN\",\"motStatus\":\"Valid\",\"make\":\"NISSAN\",\"yearOfManufacture\":2015,\"engineCapacity\":1198,\"co2Emissions\":117,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"WHITE\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2023-12-08\",\"motExpiryDate\":\"2024-10-04\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2015-09\"}', '2024-10-04', NULL, NULL, '2024-01-29 17:10:08', '2024-01-29 17:10:08'),
-- (123, 80, 'SK63RVT', 'FORD', '2013', '{\"registrationNumber\":\"SK63RVT\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-11-01\",\"motStatus\":\"Valid\",\"make\":\"FORD\",\"yearOfManufacture\":2013,\"engineCapacity\":1560,\"co2Emissions\":124,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"BLACK\",\"typeApproval\":\"M1\",\"revenueWeight\":2200,\"dateOfLastV5CIssued\":\"2023-11-02\",\"motExpiryDate\":\"2024-05-13\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2013-10\"}', '2024-05-13', NULL, NULL, '2024-01-30 11:58:12', '2024-01-30 11:58:12'),
-- (124, 79, 'YB54LYC', 'VOLKSWAGEN', '2005', '{\"registrationNumber\":\"YB54LYC\",\"taxStatus\":\"Untaxed\",\"taxDueDate\":\"2024-01-01\",\"motStatus\":\"Valid\",\"make\":\"VOLKSWAGEN\",\"yearOfManufacture\":2005,\"engineCapacity\":1390,\"co2Emissions\":180,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"SILVER\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2023-06-14\",\"motExpiryDate\":\"2024-02-01\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2005-01\"}', '2024-02-01', NULL, NULL, '2024-01-30 17:15:17', '2024-01-30 17:15:17'),
-- (125, 81, 'K17JSB', 'MERCEDES-BENZ', '2015', '{\"registrationNumber\":\"K17JSB\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-12-01\",\"motStatus\":\"Not valid\",\"make\":\"MERCEDES-BENZ\",\"yearOfManufacture\":2015,\"engineCapacity\":2987,\"co2Emissions\":205,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"BLACK\",\"typeApproval\":\"M1\",\"revenueWeight\":3250,\"dateOfLastV5CIssued\":\"2022-02-10\",\"motExpiryDate\":\"2024-01-26\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2015-09\"}', '2024-01-26', NULL, NULL, '2024-01-30 17:58:42', '2024-01-30 17:58:42'),
-- (126, 81, 'X17GSB', 'TESLA', '2020', '{\"registrationNumber\":\"X17GSB\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-03-01\",\"motStatus\":\"Valid\",\"make\":\"TESLA\",\"yearOfManufacture\":2020,\"engineCapacity\":0,\"co2Emissions\":0,\"fuelType\":\"ELECTRICITY\",\"markedForExport\":false,\"colour\":\"GREY\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2022-03-31\",\"motExpiryDate\":\"2024-05-04\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2020-03\"}', '2024-05-04', NULL, NULL, '2024-01-30 17:59:11', '2024-01-30 17:59:11'),
-- (127, 8, 'EA17PKX', 'FORD', '2017', '{\"registrationNumber\":\"EA17PKX\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-03-01\",\"motStatus\":\"Valid\",\"make\":\"FORD\",\"yearOfManufacture\":2017,\"engineCapacity\":1596,\"co2Emissions\":149,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"GREY\",\"typeApproval\":\"M1\",\"revenueWeight\":1760,\"dateOfLastV5CIssued\":\"2023-03-21\",\"motExpiryDate\":\"2024-03-14\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2017-04\"}', '2024-03-14', '112491', NULL, '2024-02-13 11:43:38', '2024-02-13 11:43:38'),
-- (130, 97, 'AV10UUY', 'PEUGEOT', '2010', '{\"registrationNumber\":\"AV10UUY\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-10-01\",\"motStatus\":\"Valid\",\"make\":\"PEUGEOT\",\"yearOfManufacture\":2010,\"engineCapacity\":1560,\"co2Emissions\":139,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"BLACK\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2021-09-20\",\"motExpiryDate\":\"2024-04-14\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2010-07\"}', '2024-04-14', '0Km', NULL, '2024-02-14 12:13:08', '2024-02-14 12:13:08'),
-- (131, 98, 'NJ65NDO', 'TOYOTA', '2015', '{\"registrationNumber\":\"NJ65NDO\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-11-01\",\"motStatus\":\"Valid\",\"make\":\"TOYOTA\",\"yearOfManufacture\":2015,\"engineCapacity\":1364,\"co2Emissions\":107,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"SILVER\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2022-10-31\",\"motExpiryDate\":\"2024-08-15\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2015-09\"}', '2024-08-15', '172125', NULL, '2024-02-15 18:15:52', '2024-02-15 18:15:52'),
-- (132, 99, 'DC66GCX', 'SUZUKI', '2016', '{\"registrationNumber\":\"DC66GCX\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-06-01\",\"motStatus\":\"Valid\",\"make\":\"SUZUKI\",\"yearOfManufacture\":2016,\"engineCapacity\":998,\"co2Emissions\":103,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"WHITE\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2022-06-22\",\"motExpiryDate\":\"2024-02-21\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2016-12\"}', '2024-02-21', '38841', NULL, '2024-02-16 16:45:45', '2024-02-16 16:45:45'),
-- (133, 79, 'YE59ZNF', 'MINI', '2009', '{\"registrationNumber\":\"YE59ZNF\",\"taxStatus\":\"Untaxed\",\"taxDueDate\":\"2023-12-15\",\"motStatus\":\"Valid\",\"make\":\"MINI\",\"yearOfManufacture\":2009,\"engineCapacity\":1598,\"co2Emissions\":156,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"RED\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2023-06-03\",\"motExpiryDate\":\"2024-05-15\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2009-12\"}', '2024-05-15', '0', NULL, '2024-02-16 17:14:24', '2024-02-16 17:14:24'),
-- (134, 38, 'HJ66HDN', 'FORD', '2016', '{\"registrationNumber\":\"HJ66HDN\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-06-01\",\"motStatus\":\"Valid\",\"make\":\"FORD\",\"yearOfManufacture\":2016,\"engineCapacity\":2198,\"co2Emissions\":193,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"WHITE\",\"typeApproval\":\"N1\",\"revenueWeight\":3100,\"dateOfLastV5CIssued\":\"2019-12-20\",\"motExpiryDate\":\"2024-10-13\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2016-09\"}', '2024-10-13', '251173', NULL, '2024-02-28 14:01:25', '2024-02-28 14:01:25'),
-- (135, 100, 'RO15WPA', 'SEAT', '2015', '{\"registrationNumber\":\"RO15WPA\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-05-01\",\"motStatus\":\"Valid\",\"make\":\"SEAT\",\"yearOfManufacture\":2015,\"engineCapacity\":1390,\"co2Emissions\":139,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"RED\",\"typeApproval\":\"M1\",\"revenueWeight\":1560,\"dateOfLastV5CIssued\":\"2019-05-09\",\"motExpiryDate\":\"2024-03-06\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2015-05\"}', '2024-03-06', '86864', NULL, '2024-02-28 14:13:10', '2024-02-28 14:13:10'),
-- (136, 57, 'SD52KFG', 'FIAT', '2002', '{\"registrationNumber\":\"SD52KFG\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-07-01\",\"motStatus\":\"Valid\",\"make\":\"FIAT\",\"yearOfManufacture\":2002,\"engineCapacity\":1242,\"co2Emissions\":136,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"GREEN\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2012-08-06\",\"motExpiryDate\":\"2024-03-21\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2002-09\"}', '2024-03-21', '62033', NULL, '2024-03-01 09:47:28', '2024-03-01 09:47:28'),
-- (137, 38, 'HF66NUY', 'FORD', '2016', '{\"registrationNumber\":\"HF66NUY\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-05-01\",\"motStatus\":\"Valid\",\"make\":\"FORD\",\"yearOfManufacture\":2016,\"engineCapacity\":2198,\"co2Emissions\":201,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"WHITE\",\"typeApproval\":\"N1\",\"revenueWeight\":3500,\"dateOfLastV5CIssued\":\"2023-01-05\",\"motExpiryDate\":\"2024-08-15\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2016-09\"}', '2024-08-15', '125', NULL, '2024-03-01 17:17:04', '2024-03-01 17:17:04'),
-- (138, 101, 'YG08WSE', 'HONDA', '2008', '{\"registrationNumber\":\"YG08WSE\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-07-01\",\"motStatus\":\"Valid\",\"make\":\"HONDA\",\"yearOfManufacture\":2008,\"engineCapacity\":1799,\"co2Emissions\":152,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"SILVER\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2023-01-04\",\"motExpiryDate\":\"2024-05-09\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2008-03\"}', '2024-05-09', '87215', NULL, '2024-03-04 13:24:45', '2024-03-04 13:24:45'),
-- (139, 79, 'KS10JRZ', 'PEUGEOT', '2010', '{\"registrationNumber\":\"KS10JRZ\",\"taxStatus\":\"Untaxed\",\"taxDueDate\":\"2024-03-03\",\"motStatus\":\"Valid\",\"make\":\"PEUGEOT\",\"yearOfManufacture\":2010,\"engineCapacity\":1397,\"co2Emissions\":137,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"SILVER\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2019-07-16\",\"motExpiryDate\":\"2024-07-31\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2010-07\"}', '2024-07-31', '74783', NULL, '2024-03-08 11:54:34', '2024-03-08 11:54:34'),
-- (140, 79, 'EA08WCR', 'PEUGEOT', '2008', '{\"registrationNumber\":\"EA08WCR\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-07-01\",\"motStatus\":\"Valid\",\"make\":\"PEUGEOT\",\"yearOfManufacture\":2008,\"engineCapacity\":998,\"co2Emissions\":108,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"RED\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2024-02-23\",\"motExpiryDate\":\"2025-03-06\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2008-04\"}', '2025-03-06', '11', NULL, '2024-03-08 11:56:57', '2024-03-08 11:56:57'),
-- (141, 102, 'YR62KXL', 'AUDI', '2012', '{\"registrationNumber\":\"YR62KXL\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2025-01-01\",\"motStatus\":\"Valid\",\"make\":\"AUDI\",\"yearOfManufacture\":2012,\"engineCapacity\":1968,\"co2Emissions\":156,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"GREY\",\"typeApproval\":\"M1\",\"revenueWeight\":2185,\"dateOfLastV5CIssued\":\"2024-01-25\",\"motExpiryDate\":\"2025-03-06\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2012-10\"}', '2025-03-06', '65014', NULL, '2024-03-08 15:19:04', '2024-03-08 15:19:04'),
-- (142, 103, 'SC65ZLK', 'VOLKSWAGEN', '2015', '{\"registrationNumber\":\"SC65ZLK\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-06-01\",\"motStatus\":\"Valid\",\"make\":\"VOLKSWAGEN\",\"yearOfManufacture\":2015,\"engineCapacity\":999,\"co2Emissions\":106,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"RED\",\"typeApproval\":\"M1\",\"revenueWeight\":1540,\"dateOfLastV5CIssued\":\"2022-06-29\",\"motExpiryDate\":\"2025-03-01\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2015-12\"}', '2025-03-01', '84120', NULL, '2024-03-08 16:01:30', '2024-03-08 16:01:30'),
-- (143, 104, 'EF13UWM', 'FORD', '2013', '{\"registrationNumber\":\"EF13UWM\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-04-01\",\"motStatus\":\"Valid\",\"make\":\"FORD\",\"yearOfManufacture\":2013,\"engineCapacity\":1997,\"co2Emissions\":162,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"GREY\",\"typeApproval\":\"M1\",\"revenueWeight\":2230,\"dateOfLastV5CIssued\":\"2023-06-28\",\"motExpiryDate\":\"2025-03-03\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2013-08\"}', '2025-03-03', '95650', NULL, '2024-03-09 15:06:43', '2024-03-09 15:06:43'),
-- (144, 105, 'BD64HLK', 'NISSAN', '2014', '{\"registrationNumber\":\"BD64HLK\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-04-01\",\"motStatus\":\"Valid\",\"make\":\"NISSAN\",\"yearOfManufacture\":2014,\"engineCapacity\":1198,\"co2Emissions\":129,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"BLACK\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2022-04-22\",\"motExpiryDate\":\"2024-04-14\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2014-12\"}', '2024-04-14', '93125', NULL, '2024-03-11 12:41:27', '2024-03-11 12:41:27'),
-- (145, 106, 'PY15JOU', 'TOYOTA', '2015', '{\"registrationNumber\":\"PY15JOU\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-08-01\",\"motStatus\":\"Valid\",\"make\":\"TOYOTA\",\"yearOfManufacture\":2015,\"engineCapacity\":1797,\"co2Emissions\":91,\"fuelType\":\"HYBRID ELECTRIC\",\"markedForExport\":false,\"colour\":\"WHITE\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2022-08-22\",\"motExpiryDate\":\"2024-06-08\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2015-06\"}', '2024-06-08', '85124', NULL, '2024-03-11 15:33:50', '2024-03-11 15:33:50'),
-- (146, 107, 'VA17HAJ', 'NISSAN', '2020', '{\"registrationNumber\":\"VA17HAJ\",\"taxStatus\":\"Untaxed\",\"taxDueDate\":\"2024-04-01\",\"motStatus\":\"Not valid\",\"make\":\"NISSAN\",\"yearOfManufacture\":2020,\"engineCapacity\":1332,\"co2Emissions\":150,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"GREY\",\"typeApproval\":\"M1\",\"euroStatus\":\"EURO 6DG\",\"dateOfLastV5CIssued\":\"2020-03-27\",\"realDrivingEmissions\":\"1\",\"motExpiryDate\":\"2024-03-29\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2020-03\"}', '2024-03-29', NULL, NULL, '2024-04-08 12:00:00', '2024-04-08 12:00:00'),
-- (147, 38, 'WD18XLP', 'FORD', '2018', '{\"registrationNumber\":\"WD18XLP\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2024-09-01\",\"motStatus\":\"Valid\",\"make\":\"FORD\",\"yearOfManufacture\":2018,\"engineCapacity\":1995,\"co2Emissions\":191,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"WHITE\",\"typeApproval\":\"N1\",\"revenueWeight\":3500,\"dateOfLastV5CIssued\":\"2023-01-17\",\"motExpiryDate\":\"2024-08-24\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2018-07\"}', '2024-08-24', '106550', NULL, '2024-04-13 12:26:39', '2024-04-13 12:26:39'),
-- (148, 108, 'PF53UPX', 'TOYOTA', '2004', '{\"registrationNumber\":\"PF53UPX\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2025-04-01\",\"motStatus\":\"Valid\",\"make\":\"TOYOTA\",\"yearOfManufacture\":2004,\"engineCapacity\":1299,\"co2Emissions\":138,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"GREEN\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2023-08-26\",\"motExpiryDate\":\"2024-10-08\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2004-01\"}', '2024-10-08', '0.00', NULL, '2024-05-23 13:13:21', '2024-05-23 13:13:21'),
-- (149, 1, 'SY09DWJ', 'HONDA', '2009', '{\"registrationNumber\":\"SY09DWJ\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2025-11-01\",\"motStatus\":\"Valid\",\"make\":\"HONDA\",\"yearOfManufacture\":2009,\"engineCapacity\":2204,\"co2Emissions\":173,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"GREY\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2024-11-13\",\"motExpiryDate\":\"2025-10-21\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2009-03\"}', '2025-10-21', '1000', NULL, '2024-12-16 15:38:45', '2024-12-16 15:38:45'),
-- (150, 1, 'MT58UZP', 'MINI', '2009', '{\"registrationNumber\":\"MT58UZP\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2025-10-01\",\"motStatus\":\"Valid\",\"make\":\"MINI\",\"yearOfManufacture\":2009,\"engineCapacity\":1397,\"co2Emissions\":128,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"BLACK\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2024-10-18\",\"motExpiryDate\":\"2026-01-13\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2009-01\"}', '2026-01-13', '100', NULL, '2024-12-31 11:08:54', '2024-12-31 11:08:54'),
-- (151, 109, 'YN13RHO', 'TOYOTA', '2013', '{\"registrationNumber\":\"YN13RHO\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2025-12-01\",\"motStatus\":\"Valid\",\"make\":\"TOYOTA\",\"yearOfManufacture\":2013,\"engineCapacity\":1598,\"co2Emissions\":140,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"BLUE\",\"typeApproval\":\"M1\",\"dateOfLastV5CIssued\":\"2021-01-13\",\"motExpiryDate\":\"2026-01-01\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2013-03\"}', '2026-01-01', '89023', NULL, '2025-01-03 18:23:29', '2025-01-03 18:23:29'),
-- (152, 109, 'MM63WPE', 'VOLKSWAGEN', '2014', '{\"registrationNumber\":\"MM63WPE\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2025-02-01\",\"motStatus\":\"Valid\",\"make\":\"VOLKSWAGEN\",\"yearOfManufacture\":2014,\"engineCapacity\":1968,\"co2Emissions\":119,\"fuelType\":\"DIESEL\",\"markedForExport\":false,\"colour\":\"BLACK\",\"typeApproval\":\"M1\",\"revenueWeight\":1880,\"dateOfLastV5CIssued\":\"2018-02-21\",\"motExpiryDate\":\"2025-03-04\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2014-02\"}', '2025-03-04', '185120', NULL, '2025-01-03 18:24:57', '2025-01-03 18:24:57'),
-- (153, 110, 'WD13FNK', 'MERCEDES-BENZ', '2013', '{\"registrationNumber\":\"WD13FNK\",\"taxStatus\":\"Taxed\",\"taxDueDate\":\"2025-05-01\",\"motStatus\":\"Not valid\",\"make\":\"MERCEDES-BENZ\",\"yearOfManufacture\":2013,\"engineCapacity\":1595,\"co2Emissions\":130,\"fuelType\":\"PETROL\",\"markedForExport\":false,\"colour\":\"BLACK\",\"typeApproval\":\"M1\",\"revenueWeight\":1920,\"dateOfLastV5CIssued\":\"2018-05-23\",\"motExpiryDate\":\"2024-11-19\",\"wheelplan\":\"2 AXLE RIGID BODY\",\"monthOfFirstRegistration\":\"2013-08\"}', '2024-11-19', NULL, NULL, '2025-01-03 18:30:51', '2025-01-03 18:30:51');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(255) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `name`, `email`, `phone`, `address`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 'Hamza', 'hamza@gmail.com', '+44 7939 481021', NULL, NULL, '2023-03-27 01:27:10', '2023-03-27 01:27:10'),
(3, 'CUSTOMER', NULL, '07', NULL, NULL, '2023-04-06 13:31:30', '2023-08-09 11:26:25'),
(4, 'mike', NULL, '07599998852', 'cannal street', NULL, '2023-04-07 08:34:39', '2023-04-07 08:34:39'),
(5, 'N A MOTORS', NULL, '07711776999', NULL, NULL, '2023-04-07 15:43:24', '2023-04-07 15:43:24'),
(6, 'KIRON MOTORS', NULL, '07540279333', NULL, NULL, '2023-04-07 15:44:08', '2023-04-07 15:44:08'),
(7, 'NAEEM MALIK', NULL, '07380263996', NULL, NULL, '2023-04-07 15:45:06', '2023-04-07 15:45:06'),
(8, 'CITY MOTOR', NULL, '07711178638', '16-18 Trafford road, LE5 4BJ Leicester', NULL, '2023-04-07 15:47:27', '2023-04-07 15:47:27'),
(9, 'FURQAN', NULL, '07735363151', 'LEICESTER', NULL, '2023-04-07 15:48:24', '2023-04-07 15:48:24'),
(10, 'ATUL', NULL, '0773537137', NULL, NULL, '2023-04-07 15:49:02', '2023-04-07 15:49:02'),
-- (11, 'JHON', NULL, '07752579423', NULL, NULL, '2023-04-07 15:50:06', '2023-04-07 15:50:06'),
-- (12, 'DIMITRI', NULL, '01162620628', NULL, NULL, '2023-04-10 12:24:26', '2023-04-10 12:24:26'),
-- (13, 'mayfair motors', NULL, '07963502233', '50 Bradgate St, Leicester LE4 0BQ', NULL, '2023-04-10 16:20:25', '2023-04-10 16:20:25'),
-- (15, 'ZAHID', NULL, '07867798303', NULL, NULL, '2023-04-11 13:00:43', '2023-04-11 13:00:43'),
-- (18, 'John', 'dame@gmail.com', '03125235632', NULL, NULL, '2023-04-18 12:18:50', '2023-04-18 12:18:50'),
-- (19, 'waseem', NULL, '07719004119', NULL, NULL, '2023-04-18 16:37:06', '2023-04-18 16:37:06'),
-- (20, 'AFTAB', NULL, '07809668698', NULL, NULL, '2023-04-18 16:39:07', '2023-04-18 16:39:07'),
-- (24, 'imad', NULL, '07866173031', NULL, NULL, '2023-05-09 16:16:35', '2023-05-09 16:16:35'),
-- (25, 'saab', NULL, '07759500896', NULL, NULL, '2023-05-10 09:21:01', '2023-05-10 09:21:01'),
-- (26, 'A & G', 'khalidanwar.choudhry@gmail.com', '07765252255', NULL, NULL, '2023-05-12 13:02:43', '2023-05-12 13:02:43'),
-- (27, 'gulraiz', NULL, '07764369404', NULL, NULL, '2023-05-12 14:03:30', '2023-05-12 14:03:30'),
-- (28, 'abdul', NULL, '07598169973', NULL, NULL, '2023-05-12 15:04:11', '2023-05-12 15:04:11'),
-- (29, 'qureshi', NULL, '07753815244', NULL, NULL, '2023-05-12 15:04:41', '2023-05-12 15:04:41'),
-- (30, 'ahmed', NULL, '07472000960', NULL, NULL, '2023-05-27 09:11:29', '2023-05-27 09:11:29'),
-- (31, 'PERDESI', NULL, '07908005770', 'LEICESTER', NULL, '2023-06-20 20:58:22', '2023-06-20 20:58:22'),
-- (32, 'sunny', 'harisleic@yahoo.co.uk', '07494456328', 'leicester', NULL, '2023-06-20 21:04:51', '2023-07-13 11:23:10'),
-- (33, 'anis', NULL, '07988984105', NULL, NULL, '2023-06-22 09:01:08', '2023-06-22 09:01:08'),
-- (34, 'ILYAS', NULL, '07380849393', NULL, NULL, '2023-07-07 15:12:52', '2023-07-07 15:12:52'),
-- (35, 'CHRIS', NULL, '07388547638', NULL, NULL, '2023-07-07 15:14:01', '2023-07-07 15:14:01'),
-- (36, 'MOLANA AYANLE', NULL, '07572693060', NULL, NULL, '2023-07-07 15:27:53', '2023-07-07 15:27:53'),
-- (37, 'sajid khan', NULL, '07786658764', NULL, NULL, '2023-07-11 17:02:23', '2023-07-11 17:02:23'),
-- (38, 'PRONTO BITE', NULL, '07366340982', NULL, NULL, '2023-07-11 17:04:23', '2023-07-11 17:04:23'),
-- (39, 'SADIK', NULL, '07972147252', NULL, NULL, '2023-07-11 17:07:46', '2023-07-11 17:07:46'),
-- (40, 'MAX', NULL, '07772001010', NULL, NULL, '2023-07-11 17:09:20', '2023-07-11 17:09:20'),
-- (41, 'RAWINDER', NULL, '07399990286', NULL, NULL, '2023-07-11 17:10:16', '2023-07-11 17:10:16'),
-- (42, 'FAISAL MALIK', NULL, '07540005571', NULL, NULL, '2023-07-11 17:13:16', '2023-07-11 17:13:16'),
-- (43, 'ARIF RAFIKI PARTS', NULL, '07904410000', NULL, NULL, '2023-07-11 17:15:34', '2023-07-11 17:15:34'),
-- (44, 'IRFAN SHEIKH', NULL, '07868925235', NULL, NULL, '2023-07-11 17:16:42', '2023-07-11 17:16:42'),
-- (45, 'JUNAID GUJAR', NULL, '07963788303', NULL, NULL, '2023-07-11 17:18:01', '2023-07-11 17:18:01'),
-- (46, 'GARDEEP', NULL, '07462008846', NULL, NULL, '2023-07-11 17:19:32', '2023-07-11 17:19:32'),
-- (47, 'MUSSA', NULL, '07850073388', NULL, NULL, '2023-07-11 17:21:10', '2023-07-11 17:21:10'),
-- (48, 'RAX', NULL, '07967560312', NULL, NULL, '2023-07-11 17:31:44', '2023-07-11 17:31:44'),
-- (49, 'KHALID', NULL, '07737681399', NULL, NULL, '2023-07-11 17:34:36', '2023-07-11 17:34:36'),
-- (50, 'GEORGE', NULL, '07542645757', NULL, NULL, '2023-07-12 08:09:13', '2023-07-12 08:09:13'),
-- (51, 'RAHEEM', NULL, '07974269425', NULL, NULL, '2023-07-12 08:15:21', '2023-07-12 08:15:21'),
-- (52, 'FAREED', NULL, '07779155000', NULL, NULL, '2023-07-12 08:16:18', '2023-07-12 08:16:18'),
-- (53, 'FAISAL SHAKOOR', NULL, '07916677021', NULL, NULL, '2023-07-12 08:18:50', '2023-07-12 08:18:50'),
-- (54, 'naveed', NULL, '07753842302', NULL, NULL, '2023-07-13 10:00:39', '2023-07-13 10:00:39'),
-- (55, 'NOUMAN', NULL, '07935466318', NULL, NULL, '2023-07-13 10:56:39', '2023-07-13 10:56:39'),
-- (56, 'TALHA', NULL, '07762896129', NULL, NULL, '2023-07-19 12:46:19', '2023-07-19 12:46:19'),
-- (57, 'Car Select Leicester Ltd', 'carpalaceuk@gmail.com', '07821729162', '297 Melton Road Le4 7an Leicester', NULL, '2023-07-19 16:03:00', '2023-07-20 09:53:16'),
-- (58, 'TOUSEEF', NULL, '07403289289', NULL, NULL, '2023-07-31 17:23:42', '2023-07-31 17:23:42'),
-- (59, 'Amerjeet', NULL, '07404577669', NULL, NULL, '2023-08-03 10:38:13', '2023-08-03 10:38:13'),
-- (60, 'HOLLY', NULL, '07714798030', NULL, NULL, '2023-08-04 13:45:16', '2023-08-04 13:45:16'),
-- (61, 'khurrum shakoor', NULL, '07999240718', NULL, NULL, '2023-08-10 09:45:23', '2023-08-10 09:45:23'),
-- (62, 'test', 'test@hotmail.com', '03125256322', 'Test User to check car reg', NULL, '2023-08-17 20:16:14', '2023-08-17 20:16:14'),
-- (63, 'isti', NULL, '07795002885', NULL, NULL, '2023-09-01 15:11:45', '2023-09-01 15:11:45'),
-- (64, 'FAIZAN', NULL, '07424983109', NULL, NULL, '2023-09-01 15:13:15', '2023-09-01 15:13:15'),
-- (65, 'OLUKAYODE', NULL, '07861237944', NULL, NULL, '2023-09-06 12:03:30', '2023-09-06 12:03:30'),
-- (66, 'samer ahmed', 'sameerahmed.sa7@gmail.com', '07424313930', NULL, NULL, '2023-09-16 12:55:21', '2023-09-16 12:55:21'),
-- (67, 'HAMZA', NULL, '07450458231', NULL, NULL, '2023-09-20 08:39:58', '2023-09-20 08:39:58'),
-- (68, 'LEAH', NULL, '07940958592', NULL, NULL, '2023-09-21 08:48:16', '2023-09-21 08:48:16'),
-- (69, 'NISAR LATIF', NULL, '07539393615', NULL, NULL, '2023-09-21 15:20:39', '2023-09-21 15:20:39'),
-- (70, 'munir', NULL, '07702075124', NULL, NULL, '2023-10-06 16:15:38', '2023-10-06 16:15:38'),
-- (71, 'zain', NULL, '07818431557', NULL, NULL, '2023-10-06 16:17:26', '2023-10-06 16:17:26'),
-- (72, 'NOORUL', NULL, '07711003786', NULL, NULL, '2023-12-01 08:56:30', '2023-12-01 08:56:30'),
-- (73, 'KADIR', NULL, '07835609200', NULL, NULL, '2023-12-01 08:57:57', '2023-12-01 08:57:57'),
-- (74, 'Gunsham', NULL, '07711738741', NULL, NULL, '2023-12-01 10:19:26', '2023-12-01 10:19:26'),
-- (75, 'sharin', NULL, '07596038020', NULL, NULL, '2023-12-07 17:20:12', '2023-12-07 17:20:12'),
-- (76, 'shahzad', NULL, '07952753266', NULL, NULL, '2023-12-07 17:26:38', '2023-12-07 17:26:38'),
-- (77, 'JASWANT', NULL, '07440089187', NULL, NULL, '2023-12-09 09:59:43', '2023-12-09 09:59:43'),
-- (78, 'ramzan', NULL, '07484625152', NULL, NULL, '2023-12-16 15:10:57', '2023-12-16 15:10:57'),
-- (79, 'DECENT MOTORS', 'decentmotors88@gmail.com', '07709797553', NULL, NULL, '2024-01-29 17:10:08', '2024-01-29 17:10:08'),
-- (80, 'GANZA', NULL, '07453883113', NULL, NULL, '2024-01-30 11:58:12', '2024-01-30 11:58:12'),
-- (81, 'sukhi', NULL, '07791806555', NULL, NULL, '2024-01-30 17:58:42', '2024-01-30 17:58:42'),
-- (97, 'Car Palace Leicester Itd', NULL, '0777821729162', 'Leicester', NULL, '2024-02-14 12:13:08', '2024-02-14 12:13:08'),
-- (98, 'baber khalid', NULL, '07710148913', NULL, NULL, '2024-02-15 18:15:52', '2024-02-15 18:15:52'),
-- (99, 'SEMMA', NULL, '07828234794', NULL, NULL, '2024-02-16 16:45:45', '2024-02-16 16:45:45'),
-- (100, 'Saima', NULL, '07771533186', NULL, NULL, '2024-02-28 14:13:10', '2024-02-28 14:13:10'),
-- (101, 'Riasat', NULL, '07807618082', NULL, NULL, '2024-03-04 13:24:45', '2024-03-04 13:24:45'),
-- (102, 'Sirwan Ahmed', NULL, '07400060300', NULL, NULL, '2024-03-08 15:19:04', '2024-03-08 15:19:04'),
-- (103, 'Y.M', NULL, '07513884323', NULL, NULL, '2024-03-08 16:01:30', '2024-03-08 16:01:30'),
-- (104, 'ANETE', NULL, '07760839775', NULL, NULL, '2024-03-09 15:06:43', '2024-03-09 15:06:43'),
-- (105, 'IMAD', NULL, '07866173031', NULL, NULL, '2024-03-11 12:41:27', '2024-03-11 12:41:27'),
-- (106, 'Ashraf', NULL, '07803165769', NULL, NULL, '2024-03-11 15:33:50', '2024-03-11 15:33:50'),
-- (107, 'bipin', NULL, '07711197710', NULL, NULL, '2024-04-08 12:00:00', '2024-04-08 12:00:00'),
-- (108, 'SHOUKAT', NULL, '03001234567', NULL, NULL, '2024-05-23 13:13:21', '2024-05-23 13:13:21'),
-- (109, 'arif', NULL, '07727150348', NULL, NULL, '2025-01-03 18:23:29', '2025-01-03 18:23:29'),
-- (110, 'deepak', NULL, '07976096183', NULL, NULL, '2025-01-03 18:30:51', '2025-01-03 18:30:51');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2022_12_21_124114_create_customers_table', 1),
(6, '2022_12_21_124154_create_suppliers_table', 1),
(7, '2022_12_21_124332_create_purchase_invoices_table', 1),
(8, '2022_12_21_124350_create_sale_invoices_table', 1),
(9, '2022_12_23_060721_create_cars_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `purchase_invoices`
--

CREATE TABLE `purchase_invoices` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `supplier_id` bigint(20) UNSIGNED NOT NULL,
  `part_invoice_number` varchar(255) NOT NULL,
  `amount` float(20,2) NOT NULL,
  `quantity` float(20,2) NOT NULL,
  `details` longtext DEFAULT NULL,
  `car_registration_number` varchar(255) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `purchase_invoices`
--

-- INSERT INTO `purchase_invoices` (`id`, `supplier_id`, `part_invoice_number`, `amount`, `quantity`, `details`, `car_registration_number`, `deleted_at`, `created_at`, `updated_at`) VALUES
-- (1, 1, 'Iv206936', 120.50, 30.00, 'Some part', 'MM2H343', NULL, '2023-03-27 01:30:08', '2023-04-04 11:10:18'),
-- (2, 2, '04483078', 53.09, 123331.00, 'FRONT DISC PADS EICHER', 'MT55AXZ', NULL, '2023-04-10 12:09:28', '2023-04-10 12:09:28'),
-- (3, 2, '04482985', 126.50, 120.00, 'REAR BRAKE PADS FRONT DISC AND PADS', 'ET06BOV', NULL, '2023-04-11 09:18:10', '2023-04-11 09:18:10'),
-- (4, 2, '04483254', 11.74, 125.00, 'OIL FILTER', 'MF54VAH', NULL, '2023-04-11 09:21:43', '2023-04-11 09:21:43'),
-- (5, 8, '7101049515', 1.00, 75125.00, 'EXCEDY CLUTCH', 'BF58FLP', NULL, '2023-04-18 16:40:36', '2023-04-18 16:40:36'),
-- (6, 3, 'LEA2115373', 132.73, 0.00, '2 FRONT LOWER ARM', 'FB51BOS', NULL, '2023-04-18 16:47:31', '2023-04-19 09:43:59'),
-- (7, 1, 'IV211432', 48.00, 88779.00, 'OFF SIDE REAR WHEEL BEARING', 'FY59OVS', NULL, '2023-04-19 17:16:50', '2023-04-19 17:16:50'),
-- (8, 2, '402591071', 84.00, 236711.00, 'LUCAS STARTER MOTOR', 'SC03OHX', NULL, '2023-04-19 00:00:00', '2023-05-09 10:41:51'),
-- (9, 2, '04487780', 86.26, 110417.00, 'TRANMACH CLUTCH + VALEO CYLINDER', 'PK57WHG', NULL, '2023-04-19 17:36:03', '2023-04-19 17:36:03'),
-- (10, 1, 'IV211251', 135.00, 0.00, 'NAPA ALTENATOR', 'R970SKW', NULL, '2023-04-19 17:37:09', '2023-04-19 17:37:09'),
-- (11, 2, '04497179', 18.73, 120.00, 'FAN BELT', 'DV10LRA', NULL, '2023-05-03 00:00:00', '2023-05-09 10:16:09'),
-- (12, 6, 'in769329', 74.74, 196125.00, 'rear disc pads n.s.r caliper', 'yd60xrl', NULL, '2023-05-15 00:00:00', '2023-05-16 16:46:34'),
-- (13, 8, '7101051222', 72.60, 90750.00, 'clutch exedy', 'nu08yzg', NULL, '2023-05-15 00:00:00', '2023-05-16 16:48:34'),
-- (14, 2, '04500494', 147.43, 124125.00, 'timng belt water pump oi fitler', 'bj10twl', NULL, '2023-05-13 00:00:00', '2023-05-16 16:50:19'),
-- (15, 2, '04501592', 113.41, 124156.00, 'altenator 140amp starline', 'bj10twl', NULL, '2023-05-16 00:00:00', '2023-05-16 17:07:43'),
-- (16, 1, 'iv214839', 105.00, 151210.00, 'front disc pads', 'ft60hlw', NULL, '2023-05-16 00:00:00', '2023-05-16 17:09:25'),
-- (17, 2, '04508216', 253.02, 142842.00, '3 PC CLUTCH', 'FL15PGU', NULL, '2023-05-27 00:00:00', '2023-05-27 09:15:18'),
-- (18, 6, 'in773752', 14.40, 0.00, 'coper pipe', NULL, NULL, '2023-06-20 00:00:00', '2023-06-20 17:41:04'),
-- (19, 6, 'in773753', 50.51, 110.00, 'o.s.r caliper', 'dv54tbu', NULL, '2023-06-20 00:00:00', '2023-06-20 17:42:04'),
-- (20, 1, 'iv219785', 52.00, 0.00, 'REAR NAPA DISC PADS', 'FD09YTR', NULL, '2023-06-20 00:00:00', '2023-06-20 17:44:08'),
-- (21, 6, 'IN773546', 35.72, 0.00, 'FRONT DON BRAKE PADS', 'M90YUB', NULL, '2023-06-19 00:00:00', '2023-06-20 17:45:11'),
-- (22, 5, '10075', 155.52, 145.00, 'AUX BATTERY', 'MY13RHM', NULL, '2023-06-19 00:00:00', '2023-06-20 17:47:53'),
-- (23, 1, '219611', 20.00, 0.00, 'OIL AIR CABIN', 'ML60YOH', NULL, '2023-06-17 00:00:00', '2023-06-20 17:49:59'),
-- (24, 1, '219594', 30.00, 0.00, 'OIL AIR POLLEN', 'SM60HPJ', NULL, '2023-06-17 00:00:00', '2023-06-20 17:51:11'),
-- (25, 1, 'IV219595', 22.00, 0.00, 'WIPER 2', 'LD15SNV', NULL, '2023-06-17 00:00:00', '2023-06-20 17:52:48'),
-- (26, 1, 'IV218855', 39.00, 0.00, 'BRAKE PADS, BOTH T.R.E', 'GK55OWU', NULL, '2023-06-13 00:00:00', '2023-06-20 17:53:51'),
-- (27, 5, '64452', 22.32, 0.00, 'EXT CLAMPS 2 REAR', 'PN11FLX', NULL, '2023-06-15 00:00:00', '2023-06-20 17:55:09'),
-- (28, 2, '04516686', 4.36, 0.00, 'OIL FILTER', 'WO64JUT', NULL, '2023-06-13 00:00:00', '2023-06-20 17:56:21'),
-- (29, 2, '04516806', 72.68, 0.00, 'BATTERY STARLINE', 'S325KJF', NULL, '2023-06-13 00:00:00', '2023-06-20 17:57:11'),
-- (30, 2, '04516925', 9.91, 0.00, 'FUEL FITLER', 'SUNNY', NULL, '2023-06-13 00:00:00', '2023-06-20 17:58:15'),
-- (31, 1, 'IV218993', 7.50, 0.00, 'TIE ROD END', 'NU11UGP', NULL, '2023-06-13 00:00:00', '2023-06-20 17:58:58'),
-- (32, 10, '234273511', 21.88, 0.00, 'PULLEY POWER STERING', 'FN05XUS', NULL, '2023-06-14 00:00:00', '2023-06-20 18:00:26'),
-- (33, 1, 'IV219037', 47.00, 0.00, 'FRONT BRAKE PADS, LINK 2', 'FM55MSV', NULL, '2023-06-14 00:00:00', '2023-06-20 18:01:33'),
-- (34, 2, '04517837', 6.36, 0.00, 'REAR BRAKE PAD,', 'FM55MSV', NULL, '2023-06-14 00:00:00', '2023-06-20 18:02:54'),
-- (35, 1, 'IV219122', 53.50, 0.00, 'OIL FILTER,2 SPEEDSENSOR', 'FM10VTE', NULL, '2023-06-14 00:00:00', '2023-06-20 18:07:48'),
-- (36, 6, 'IN773128', 19.00, 0.00, 'BRAKE SHOES', 'DE59XNC', NULL, '2023-06-15 00:00:00', '2023-06-20 18:09:43'),
-- (37, 1, 'IV219239', 27.00, 0.00, 'WIPER AND OIL FILTER', 'YT62BFX', NULL, '2023-06-15 00:00:00', '2023-06-20 18:10:42'),
-- (38, 1, 'IV219305', 17.00, 0.00, 'H15 BULB', 'DR GULRAIZ', NULL, '2023-06-15 00:00:00', '2023-06-20 18:11:55'),
-- (39, 6, 'IN773194', 248.16, 0.00, 'TIMING CHAIN KIT', 'FM67KWP', NULL, '2023-06-15 00:00:00', '2023-06-20 18:12:57'),
-- (40, 1, 'IV219421', 30.06, 0.00, 'REAR ABS SENSOR , SADEEQ CAR', 'GX14ZHE', NULL, '2023-06-16 00:00:00', '2023-06-20 18:14:16'),
-- (41, 2, '04519327', 4.85, 0.00, 'OIL FILER', 'SUNNY', NULL, '2023-06-16 00:00:00', '2023-06-20 18:25:44'),
-- (42, 2, '04516455', 4.63, 0.00, 'OIL FTILER', 'DL17GDU', NULL, '2023-06-12 00:00:00', '2023-06-20 18:27:53'),
-- (43, 2, 'IV218797', 61.00, 0.00, 'FR BRAKE DSIC', 'WM57GKY', NULL, '2023-06-12 00:00:00', '2023-06-20 18:30:44'),
-- (44, 6, 'IN772874', 17.21, 0.00, '17.21', 'HW57ENJ', NULL, '2023-06-13 00:00:00', '2023-06-20 18:31:28'),
-- (45, 6, 'IN773149', 15.24, 0.00, 'WHEEL CYLINDER REAR 1', 'DE59XNC', NULL, '2023-06-15 00:00:00', '2023-06-20 18:32:50'),
-- (46, 6, 'IN773141', 139.20, 0.00, '139.20', 'YT62BFX', NULL, '2023-06-15 00:00:00', '2023-06-20 18:33:37'),
-- (47, 2, '04517246', 16.24, 0.00, 'IGNISTION LEEDS', 'HAJI GH RASOOL', NULL, '2023-06-13 00:00:00', '2023-06-20 18:35:33'),
-- (48, 1, 'IV218718', 28.00, 0.00, 'TR.E AND FR BRAKE PADS', 'KX60BPZ', NULL, '2023-06-12 00:00:00', '2023-06-20 18:36:32'),
-- (49, 1, 'IV218607', 24.00, 0.00, 'REAR SHOCKER 1\r\nCORSA', 'KP58VKG', NULL, '2023-06-24 00:00:00', '2023-06-20 20:23:52'),
-- (50, 3, 'LEA2126870', 81.24, 0.00, 'STARTER MOTOR PEUGEOT 207', 'SA11NDF', NULL, '2023-06-08 00:00:00', '2023-06-20 20:24:56'),
-- (51, 3, 'LEA2126863', 34.66, 0.00, 'RH SUSPENSION ARM \r\nSWIFT', 'BF07NRU', NULL, '2023-06-08 00:00:00', '2023-06-20 20:25:55'),
-- (52, 2, '04513909', 12.73, 0.00, 'RH LINK', 'MW61YNX', NULL, '2023-06-07 00:00:00', '2023-06-20 20:26:47'),
-- (53, 1, 'IV218495', 42.00, 0.00, 'REAR 1 SHOCKER', 'LM54EYP', NULL, '2023-06-09 00:00:00', '2023-06-20 20:27:33'),
-- (54, 2, '04515264', 5.94, 0.00, 'OIL FILTER', 'DV10LRA', NULL, '2023-06-09 00:00:00', '2023-06-20 20:28:32'),
-- (55, 1, 'IV218318', 10.00, 0.00, 'FAN BELT ASTRA', 'YB09PBX', NULL, '2023-06-08 00:00:00', '2023-06-20 20:29:06'),
-- (56, 1, 'IV218316', 38.00, 0.00, 'WATER PUMP', 'YB09PBX', NULL, '2023-06-08 00:00:00', '2023-06-20 20:29:55'),
-- (57, 1, 'IV218284', 52.00, 0.00, 'OIL FILTER, AIR FUEL \r\nMERCEDES ML', 'WJ57MUU', NULL, '2023-06-08 00:00:00', '2023-06-20 20:30:43'),
-- (58, 2, '04513130', 41.54, 0.00, 'REAR DISC PADS', 'LV10YRD', NULL, '2023-06-06 00:00:00', '2023-06-20 20:31:40'),
-- (59, 1, 'IV217965', 76.00, 0.00, 'REAR BOTH SIDE CALIPER \r\nAUDI A3', 'LV10YRD', NULL, '2023-06-06 00:00:00', '2023-06-20 20:32:42'),
-- (60, 2, '04513179', 6.68, 0.00, 'AIR FILTER', 'NG61XSC', NULL, '2023-06-06 00:00:00', '2023-06-20 20:33:35'),
-- (61, 6, 'IN7720003', 37.73, 0.00, 'BALL JOINT, SPIRNG FRONT 2 \r\nMER A CLASS', 'FA04TXS', NULL, '2023-06-06 00:00:00', '2023-06-20 20:34:38'),
-- (62, 1, 'IV217871', 82.00, 0.00, 'FRONT SHOCKER B/S A CLASS', 'FA04TXS', NULL, '2023-06-06 00:00:00', '2023-06-20 20:35:27'),
-- (63, 1, 'IV217840', 17.50, 0.00, 'OIL AIR FILTER', 'DX67PUV', NULL, '2023-06-06 00:00:00', '2023-06-20 20:36:06'),
-- (64, 1, 'IV217839', 9.50, 0.00, 'LINK PRIUS', 'LW14MVJ', NULL, '2023-06-06 00:00:00', '2023-06-20 20:36:55'),
-- (65, 2, '04513708', 78.37, 0.00, 'WATER PUMP MERCEDES', 'DR ALAM ZAIB', NULL, '2023-06-07 00:00:00', '2023-06-20 20:37:56'),
-- (66, 1, 'IV217391', 22.00, 0.00, 'WHEEL BEARING', 'EY02TZS', NULL, '2023-06-02 00:00:00', '2023-06-20 20:38:38'),
-- (67, 2, '04511681', 37.86, 0.00, 'BATTERY STARLINE 063', 'OW04GBU', NULL, '2023-06-03 00:00:00', '2023-06-20 20:39:35'),
-- (68, 1, 'IV217322', 27.00, 0.00, 'FR SPRING MERCEDES', 'WFZ9126', NULL, '2023-06-01 00:00:00', '2023-06-20 20:40:20'),
-- (69, 1, 'IV217167', 31.50, 0.00, 'OIL AIR CABIN 2 LINK FRONT GOLF', 'PK10XSZ', NULL, '2023-06-01 00:00:00', '2023-06-20 20:42:20'),
-- (70, 6, 'IN771832', 9.61, 0.00, 'OIL AND AIR FITLER SCIRROCO SAMINA', 'M55MNA', NULL, '2023-06-05 00:00:00', '2023-06-20 20:48:19'),
-- (71, 6, 'IN771825', 20.06, 0.00, 'FRONT BRAKE PADS CHEVROLET', 'KV07DRE', NULL, '2023-06-05 00:00:00', '2023-06-20 20:49:30'),
-- (72, 6, 'IN771802', 11.57, 0.00, 'OIL AIR FILTER', 'FY06VTK', NULL, '2023-06-05 00:00:00', '2023-06-20 20:50:17'),
-- (73, 2, '04512580', 11.32, 0.00, 'OIL AIR FILTER', 'WV11NXF', NULL, '2023-06-05 00:00:00', '2023-06-20 20:51:14'),
-- (74, 1, 'IV217787', 23.50, 0.00, 'FUEL AND CABIN', 'WV11NXF', NULL, '2023-06-05 00:00:00', '2023-06-20 20:51:56'),
-- (75, 1, 'IV217677', 80.00, 0.00, 'F.DISC PADS NAPA JUKE', 'AO12OHS', NULL, '2023-06-05 00:00:00', '2023-06-20 20:53:40'),
-- (76, 2, '04512214', 19.34, 0.00, 'FRONT PADS', 'SA61DVV', NULL, '2023-06-05 00:00:00', '2023-06-20 20:54:25'),
-- (77, 1, 'IV217077', 15.00, 0.00, 'FRONT BRAKE PADS', 'OY06VXD', NULL, '2023-05-31 00:00:00', '2023-06-20 20:55:03'),
-- (78, 6, 'IN773659', 51.86, 0.00, 'O/S/F WHEEL BEARING, FUEL FILER TOURAN', 'FY56XKH', NULL, '2023-06-20 00:00:00', '2023-06-21 08:14:50'),
-- (79, 3, 'LEA2129481', 12.91, 0.00, 'MAT BLACK 2 CAN', 'SUNNY', NULL, '2023-06-20 00:00:00', '2023-06-21 08:15:22'),
-- (80, 6, 'in773687', 52.15, 0.00, 'REAR BOTH SIDE SHOCKER YARIS', 'DX03ZKA', NULL, '2023-06-20 00:00:00', '2023-06-21 08:20:01'),
-- (81, 1, 'iv220380', 55.00, 0.00, 'LH CALIPER C4 PICASOO', 'BN59VGP', NULL, '2023-06-22 00:00:00', '2023-06-22 16:25:55'),
-- (82, 1, 'M88SHN', 42.00, 0.00, 'F BRAKE PADS MOHSIN', 'M88SHN', NULL, '2023-06-22 00:00:00', '2023-06-22 16:26:28'),
-- (83, 2, '04522112', 125.98, 0.00, 'REAR DISC PADS EICHER C4 PICASSO', 'BN59VGP', NULL, '2023-06-22 00:00:00', '2023-06-22 16:27:33'),
-- (84, 1, 'IV220290', 4.00, 0.00, 'OIL PRESSURE SWITCH', 'BJ13SYP', NULL, '2023-06-22 00:00:00', '2023-06-22 16:28:16'),
-- (85, 2, '04522001', 228.43, 300000.00, '3 PC CLUTCH LUK', 'YS10CFJ', NULL, '2023-06-22 00:00:00', '2023-06-22 16:30:13'),
-- (86, 2, '04521857', 193.60, 0.00, 'FLYWHEEL LUK', 'YS10CFJ', NULL, '2023-06-22 00:00:00', '2023-06-22 16:30:59'),
-- (87, 2, '04521682', 10.98, 0.00, 'OIL AND AIR', 'LT53MBU', NULL, '2023-06-21 00:00:00', '2023-06-22 16:32:00'),
-- (88, 2, '04521297', 14.16, 0.00, 'OIL AND AIR FILTER BMW 3 SERIES', 'YE59VNL', NULL, '2023-06-21 00:00:00', '2023-06-22 16:33:08'),
-- (89, 3, 'LEA2129905', 53.95, 0.00, 'STARTER MOTOR', 'MF56UNG', NULL, '2023-06-21 00:00:00', '2023-06-22 16:34:08'),
-- (90, 2, '04522692', 5.27, 0.00, 'OIL FILTER GOLF', 'S8NTK', NULL, '2023-06-23 00:00:00', '2023-06-23 09:06:35'),
-- (91, 1, 'IV220543', 7.00, 0.00, 'OIL AIR FILTER NISSAN JUKE', 'LK18XUP', NULL, '2023-06-23 00:00:00', '2023-06-23 17:05:30'),
-- (92, 1, 'IV220560', 27.00, 0.00, 'OIL AIR AND 10/40 OIL MERIVA', 'CE55ODK', NULL, '2023-06-23 00:00:00', '2023-06-23 17:06:15'),
-- (93, 2, '04523122', 19.39, 0.00, 'OIL AIR FILTER JAZZ', 'EO04ZDE', NULL, '2023-06-23 00:00:00', '2023-06-23 17:07:35'),
-- (94, 2, '04522901', 68.57, 0.00, 'FRONT DISC PADS', 'NU08ZYG', NULL, '2023-06-23 00:00:00', '2023-06-23 17:08:43'),
-- (95, 1, 'iv220709', 14.50, 0.00, 'FAN BELT AUDI A4', 'VE58BTY', NULL, '2023-06-24 00:00:00', '2023-06-24 13:43:49'),
-- (96, 2, '04523211', 28.87, 0.00, 'CRANK SENSOR TRANSIT VAN', 'YS10CFJ', NULL, '2023-06-24 00:00:00', '2023-06-24 13:47:04'),
-- (97, 3, 'lea2130919', 61.01, 0.00, 'LH Aam and link haji ghulam rasol kia picanto', 'LD05ULH', NULL, '2023-06-26 00:00:00', '2023-06-26 12:12:17'),
-- (98, 1, 'iv220938', 52.00, 0.00, 'LH ARM KIA PICANTO H G RASOOL', 'LD05ULH', NULL, '2023-06-26 00:00:00', '2023-06-27 08:10:46'),
-- (99, 2, '04524578', 40.64, 0.00, 'WATER PUMP ASTRA', 'NA05WFF', NULL, '2023-06-27 00:00:00', '2023-06-27 11:43:48'),
-- (100, 1, 'iv221137', 10.50, 0.00, 'OIL AIR FIAT PUNTO', 'BG56YPX', NULL, '2023-06-28 00:00:00', '2023-06-28 10:30:13'),
-- (101, 6, 'in775276', 10.57, 0.00, 'fan belt islam', 'nissan micra', NULL, '2023-07-04 00:00:00', '2023-07-04 15:51:27'),
-- (102, 8, '7101054603', 48.00, 0.00, 'FAN BELT TENSIONER', 'fx03uwv', NULL, '2023-07-04 00:00:00', '2023-07-12 06:56:44'),
-- (103, 1, 'IV221997', 22.00, 0.00, 'TRACK ROD END OUTER BOTH SIDE HONDA INSIGHT', 'FH09XJT', NULL, '2023-07-04 00:00:00', '2023-07-04 15:52:48'),
-- (104, 2, '04529316', 93.73, 0.00, 'BRAKE PADS FRONT AND REAR', 'J15LHM', NULL, '2023-07-05 00:00:00', '2023-07-05 16:00:31'),
-- (105, 1, 'iv222465', 20.00, 0.00, 'FRONT BRAKE PADS', 'RV10PGO', NULL, '2023-07-06 00:00:00', '2023-07-06 16:07:16'),
-- (106, 4, '23667162', 39.53, 0.00, 'BATTERY', 'FX60HDD', NULL, '2023-07-06 00:00:00', '2023-07-06 16:09:10'),
-- (107, 1, 'IV222304', 8.50, 0.00, 'OIL AIR FILTER', 'DG07FYJ', NULL, '2023-07-06 00:00:00', '2023-07-06 16:17:24'),
-- (108, 1, 'IV222167', 12.00, 0.00, 'LINK BOTH SIDE ASTRA', 'VU05ULK', NULL, '2023-07-05 00:00:00', '2023-07-06 16:17:58'),
-- (109, 1, 'iv223078', 14.00, 0.00, 'LH R. SHOCKER TOP MOUNTING  AUDI Q3', 'FG62OYY', NULL, '2023-07-11 00:00:00', '2023-07-11 16:39:21'),
-- (110, 2, '04532748', 16.18, 0.00, 'OIL AIR FILTER', 'OU09XTP', NULL, '2023-07-11 00:00:00', '2023-07-11 16:40:20'),
-- (111, 2, '04532610', 136.48, 0.00, 'TIMING BELT INA GOLF', 'YF09BYD', NULL, '2023-07-11 00:00:00', '2023-07-11 16:41:28'),
-- (112, 2, '04532607', 18.02, 0.00, 'ABS RING REAR BOTH SIDE', 'CE09DXO', NULL, '2023-07-11 00:00:00', '2023-07-11 16:42:13'),
-- (113, 6, 'IN775981', 13.20, 0.00, 'BALL JOINT LH FORD GALAXY', 'NC04DZU', NULL, '2023-07-10 00:00:00', '2023-07-11 16:43:18'),
-- (118, 1, 'IV223267', 34.00, 0.00, 'TIMING BELT KIA PICANTO', 'LD05ULH', NULL, '2023-07-12 00:00:00', '2023-07-13 10:50:09'),
-- (119, 1, 'IV223255', 35.00, 0.00, 'TIMING BELT SHARAN', 'RY56SZR', NULL, '2023-07-12 00:00:00', '2023-07-13 10:50:44'),
-- (120, 1, 'IV223256', 20.00, 0.00, 'FAN BELT SHARAN', 'RY56SZR', NULL, '2023-07-12 00:00:00', '2023-07-13 10:51:09'),
-- (121, 1, 'IV223185', 20.00, 0.00, 'OIL AIR CABIN AUDI A4', 'N44RRU', NULL, '2023-07-12 00:00:00', '2023-07-13 10:52:21'),
-- (122, 1, 'IV223186', 9.00, 0.00, 'BALL JOINT RH GOLF', 'YF09BYD', NULL, '2023-07-12 00:00:00', '2023-07-13 10:52:54'),
-- (123, 1, 'IV223388', 13.00, 0.00, 'OIL AIR PEU EXPERT', 'BF16YFM', NULL, '2023-07-13 00:00:00', '2023-07-13 10:54:52'),
-- (124, 2, '04533979', 42.83, 0.00, 'FRONT DISC PADS EICHER', 'SA13DXV', NULL, '2023-07-13 00:00:00', '2023-07-13 10:55:40'),
-- (125, 6, 'IN776455', 122.26, 0.00, 'OIL AIR O/S/F WHEEL BEARING, SPARK PLUGS, FRONT BRAKE PADS', 'BN59FWT', NULL, '2023-07-13 00:00:00', '2023-07-13 11:00:17'),
-- (126, 1, 'IV223442', 13.00, 0.00, 'O/S/F T.R.E QASHQAI', 'BN59FWT', NULL, '2023-07-13 00:00:00', '2023-07-13 14:52:02'),
-- (127, 6, 'in776591', 16.80, 0.00, '2 LINK FRONT CIT C4', 'vk07vnb', NULL, '2023-07-14 00:00:00', '2023-07-14 08:22:49'),
-- (128, 1, 'IV223576', 13.00, 0.00, 'ROCKER COVER GASKET CORSA ZAK', 'X24KCX', NULL, '2023-07-14 00:00:00', '2023-07-14 15:31:57'),
-- (129, 11, '0', 400.00, 0.00, 'MOTOR ROLLER REPAIR', '00', NULL, '2023-07-14 00:00:00', '2023-07-14 15:35:47'),
-- (130, 1, 'IV223742', 21.00, 0.00, 'BELT DIAT DOBLO', 'RV10PGO', NULL, '2023-07-15 00:00:00', '2023-07-17 09:05:30'),
-- (131, 6, 'in776904', 33.79, 0.00, 'BALAL JOINT RH AND BRAKE PADS FRONT CARINA', 'M870PCX', NULL, '2023-07-17 00:00:00', '2023-07-17 16:23:42'),
-- (132, 2, '04535853', 108.28, 0.00, 'STARTER MOTOR STARLINE CARINA', 'M870PCX', NULL, '2023-07-17 00:00:00', '2023-07-17 16:24:43'),
-- (133, 2, '04535882', 24.12, 0.00, 'IGNITION COIL BMW', 'SL07AWR', NULL, '2023-07-17 00:00:00', '2023-07-17 16:25:15'),
-- (134, 1, 'IV223885', 8.50, 0.00, 'OIL FILTER AUDI A3', 'BL59EKB', NULL, '2023-07-17 00:00:00', '2023-07-17 16:25:51'),
-- (135, 1, 'IV223874', 49.00, 0.00, 'OIL AIR S PLUGS AUDI A3', 'BL59EKB', NULL, '2023-07-17 00:00:00', '2023-07-17 16:26:48'),
-- (136, 6, 'in776835', 35.18, 0.00, 'GLOW PLUGS VW SCIROCCO', 'M555MNA', NULL, '2023-07-17 00:00:00', '2023-07-17 17:01:40'),
-- (137, 12, '36522', 60.00, 1.00, 'oil collection', 'a', NULL, '2023-07-18 00:00:00', '2023-07-18 17:10:22'),
-- (138, 1, 'IV224053', 38.00, 0.00, 'LH RR CALPER', 'WG09KUU', NULL, '2023-07-18 00:00:00', '2023-07-18 17:11:19'),
-- (139, 1, 'IV224052', 47.50, 0.00, 'REAR BRAKE PADS, RR RH CALIPER A3', 'WG09KUU', NULL, '2023-07-18 00:00:00', '2023-07-18 17:12:24'),
-- (140, 2, '04536494', 496.16, 136.00, 'CLUTCH FLYWHEEL ASTRA', 'SB08PWX', NULL, '2023-07-18 00:00:00', '2023-07-18 17:16:34'),
-- (141, 2, '04536139', 72.40, 120.00, 'TIMING BELT KIT GOLF', 'AD02FUY', NULL, '2023-07-18 00:00:00', '2023-07-18 17:18:37'),
-- (142, 1, 'IV224149', 68.00, 0.00, 'FRONT DISC CARINA', 'M870PCX', NULL, '2023-07-19 00:00:00', '2023-07-19 17:03:19'),
-- (143, 6, 'IN777167', 86.11, 0.00, 'ATF D 2', 'ATF', NULL, '2023-07-19 00:00:00', '2023-07-19 17:06:23'),
-- (144, 1, 'IV224313', 17.50, 0.00, 'OIL AIR FILTER FOCUS', 'EO11GGK', NULL, '2023-07-20 00:00:00', '2023-07-20 09:55:25'),
-- (145, 2, '04537282', 119.38, 0.00, 'CLUTCH SACHE AUDI A4 WASEEM', 'KS04TXK', NULL, '2023-07-20 00:00:00', '2023-07-20 09:56:10'),
-- (146, 1, 'iv224415', 60.00, 50125.00, 'CHAIN TIMING CORSA', 'FH66ZDM', NULL, '2023-07-20 00:00:00', '2023-07-20 13:46:01'),
-- (147, 2, '04537814', 33.06, 0.00, 'FR BRAKE PADS AUDI WALEED', 'VU14NMK', NULL, '2023-07-20 00:00:00', '2023-07-20 15:45:59'),
-- (148, 1, 'iv224519', 43.50, 0.00, 'OIL AIR SPARK PLUG JAZZ', 'DS03ZNU', NULL, '2023-07-21 00:00:00', '2023-07-21 13:51:19'),
-- (149, 6, 'in777692', 24.00, 0.00, 'link both side bmw', 'yg55cky', NULL, '2023-07-24 00:00:00', '2023-07-24 15:27:34'),
-- (150, 1, 'iv224998', 64.50, 0.00, 'lh arm f b pads', 'balgaria', NULL, '2023-07-25 00:00:00', '2023-07-26 08:14:11'),
-- (151, 2, '04539954', 50.30, 0.00, 'fan belt tensioner', 'GX14ZHE', NULL, '2023-07-25 00:00:00', '2023-07-26 08:16:30'),
-- (152, 1, 'IV224931', 9.50, 0.00, 'FAN BELT', 'GX14ZHE', NULL, '2023-07-25 00:00:00', '2023-07-26 08:17:20'),
-- (153, 2, '04539819', 19.21, 0.00, 'OIL AIR FILTER BABER', 'NJ65NDO', NULL, '2023-07-25 00:00:00', '2023-07-26 08:18:35'),
-- (154, 2, '04540697', 67.63, 0.00, 'timing belt only and water pump', 'VN06WFF', NULL, '2023-07-26 00:00:00', '2023-07-27 14:52:28'),
-- (155, 8, '7101056298', 156.00, 0.00, 'CLUTCH', 'VN06WFF', NULL, '2023-07-27 00:00:00', '2023-07-27 14:59:49'),
-- (156, 2, '04542132', 81.66, 137879.00, '3 PC CLUTCH KIA', 'AJ06SYO', NULL, '2023-07-28 00:00:00', '2023-07-29 16:08:56'),
-- (157, 2, '04542345', 18.41, 0.00, 'REAR BRAKE PADS EICHER', 'VK13LHR', NULL, '2023-07-29 00:00:00', '2023-07-29 16:14:44'),
-- (158, 3, 'LEA2138893', 101.86, 0.00, 'RH REAR CALIPER VW GOLF', 'VK13LHR', NULL, '2023-07-29 00:00:00', '2023-07-29 16:16:01'),
-- (159, 1, 'IV225670', 23.00, 167589.00, 'F BRAKE PADS ESTIMA', 'FB06PHA', NULL, '2023-07-31 00:00:00', '2023-07-31 17:19:59'),
-- (160, 6, 'IN778567', 6.66, 120.00, 'RH LINK PASSAT', 'CE55OZT', NULL, '2023-07-31 00:00:00', '2023-07-31 17:21:04'),
-- (161, 2, '04543183', 3.20, 49250.00, 'OIL FILTER', 'SP14HLW', NULL, '2023-07-31 00:00:00', '2023-07-31 17:22:49'),
-- (162, 2, '04542920', 41.54, 0.00, 'REAR DISC PADS GOLF CHRIS', 'YF09BYD', NULL, '2023-07-31 00:00:00', '2023-07-31 17:26:50'),
-- (163, 4, '23939715', 81.31, 0.00, 'D BUSH', 'HJ66HDN', NULL, '2023-08-02 00:00:00', '2023-08-03 14:27:40'),
-- (164, 1, 'IV226086', 110.00, 153125.00, 'TIMING CHIN YARIS', 'FE14GAO', NULL, '2023-08-02 00:00:00', '2023-08-03 14:28:25'),
-- (165, 1, 'IV226056', 8.00, 153124.00, 'ROCKER COVER GASKET YARIS', 'FE14GAO', NULL, '2023-08-02 00:00:00', '2023-08-03 14:29:01'),
-- (166, 1, 'IV226037', 30.50, 197125.00, 'FULL SERVICE KIT PASSAT', 'RV09XBD', NULL, '2023-08-02 00:00:00', '2023-08-03 14:29:38'),
-- (167, 1, 'IV225824', 16.00, 111.00, 'FORD GALAXY PULLEY', 'YP06BPZ', NULL, '2023-08-02 00:00:00', '2023-08-03 14:30:34'),
-- (168, 6, 'IN778632', 171.70, 0.00, 'AURIS  CLUTCH KIT BLUE PRINT', 'SH59GKY', NULL, '2023-08-02 00:00:00', '2023-08-03 14:31:31'),
-- (169, 2, '04545169', 6.11, 175.00, 'OIL FILTER INSIGNIA', 'DN65GGZ', NULL, '2023-08-03 00:00:00', '2023-08-04 12:55:24'),
-- (170, 1, 'IV226130', 14.00, 0.00, 'OIL AND AIR INSIGNIA', 'EY66XWN', NULL, '2023-08-03 00:00:00', '2023-08-04 12:55:54'),
-- (171, 1, 'IV226227', 36.50, 0.00, 'FULL SERVICE ASTRA', 'YB09PBX', NULL, '2023-08-03 00:00:00', '2023-08-04 12:56:24'),
-- (172, 1, 'IV226365', 60.00, 123456.00, 'SHOCKER TOP MOUNTING B/S', 'CITREON BULGARIA', NULL, '2023-08-04 00:00:00', '2023-08-04 12:57:47'),
-- (173, 3, 'lea2140512', 120.00, 120.00, 'WHEEL BEARING 2 FRONT ZAFIRA', 'ND08XTB', NULL, '2023-08-04 00:00:00', '2023-08-05 07:50:31'),
-- (174, 1, 'IV226373', 12.50, 0.00, 'OIL AIR FILTER', 'FG68ZGT', NULL, '2023-08-04 00:00:00', '2023-08-05 07:51:47'),
-- (175, 1, 'iv226455', 13.00, 125.00, 'FORD GALAXY TOP MOUNITNG', 'NC04DZU', NULL, '2023-08-05 00:00:00', '2023-08-05 13:21:25'),
-- (176, 1, 'iv226670', 54.00, 125.00, 'OIL FILTER W/P R COVER PEUGET 208', 'KV14WML', NULL, '2023-08-07 00:00:00', '2023-08-07 15:47:46'),
-- (177, 13, '618452', 30.55, 76055.00, 'HOSE PIPE NEXT TO WATER PUMP PEUGEOT 208', 'KV14WML', NULL, '2023-08-08 00:00:00', '2023-08-08 16:27:51'),
-- (178, 2, '04548263', 19.45, 120.00, 'REAR B PADS BRAMBO', 'MK12YNF', NULL, '2023-08-09 00:00:00', '2023-08-09 11:23:34'),
-- (179, 14, '0973214', 192.00, 0.00, 'PROPSHAFT FRONT', 'PATH FINDER', NULL, '2023-08-09 00:00:00', '2023-08-09 12:49:37'),
-- (180, 1, 'iv226922', 145.00, 97547.00, 'TIMING BELT WATER PUMP PASSAT', 'FV63NND', NULL, '2023-08-09 00:00:00', '2023-08-09 13:01:30'),
-- (181, 1, 'IV227079', 52.00, 0.00, 'REAR EXHAT', 'ND59NJX', NULL, '2023-08-10 00:00:00', '2023-08-11 16:13:59'),
-- (182, 1, 'IV227201', 16.00, 0.00, 'OIL AND AIR FITTER TRANSIT', 'YS10CFJ', NULL, '2023-08-10 00:00:00', '2023-08-11 16:15:05'),
-- (183, 1, 'IV227195', 13.50, 0.00, 'OIL AIR FILTER S CLASS MERCEDES', 'K1NWM', NULL, '2023-08-10 00:00:00', '2023-08-11 16:15:54'),
-- (184, 6, 'IN779900', 58.38, 0.00, 'FORD TANSIT WATER PUMP', 'YS10CFJ', NULL, '2023-08-10 00:00:00', '2023-08-11 16:16:41'),
-- (185, 3, 'LEA2141638', 96.53, 0.00, 'F D PADS PEU 207', 'AFZ7334', NULL, '2023-08-09 00:00:00', '2023-08-11 16:18:48'),
-- (186, 1, 'IV227552', 85.00, 120.00, 'STARTER MOTOR VIVARO', 'DY60KGO', NULL, '2023-08-12 00:00:00', '2023-08-12 15:06:21'),
-- (187, 1, 'IV227527', 17.00, 120.00, 'RH WHEEL BEARING P 207', 'AFZ7334', NULL, '2023-08-12 00:00:00', '2023-08-12 15:06:57'),
-- (188, 1, 'IV227441', 38.00, 175.00, 'O/F A/F', 'MF61UEX', NULL, '2023-08-12 00:00:00', '2023-08-12 15:07:38'),
-- (189, 8, '71010157919', 119.96, 0.00, 'CLUTCH FORD FIESTA SACH', 'EO59UEZ', NULL, '2023-08-16 00:00:00', '2023-08-16 17:47:48'),
-- (190, 3, 'LEA2142775', 54.98, 0.00, 'REAR BS SHOCKER CIT C4 PICASSO', 'GX14ZHE', NULL, '2023-08-16 00:00:00', '2023-08-16 17:48:38'),
-- (191, 6, 'IN780752', 49.69, 0.00, 'MASTER CYLINDER FORD TRANSIT', 'AD10BTY', NULL, '2023-08-18 00:00:00', '2023-08-19 13:53:23'),
-- (192, 2, '04553995', 60.25, 60125.00, 'AUDI Q5 FRONT BRAKE PADS PAGID', 'WK17YTH', NULL, '2023-08-19 00:00:00', '2023-08-19 13:58:21'),
-- (193, 1, 'iv228545', 179.00, 125.00, 'APEC ALL ROUND DISC PADS GOLF SCOBBY', 'S4YBP', NULL, '2023-08-19 00:00:00', '2023-08-19 14:36:52'),
-- (194, 1, 'iv228709', 9.50, 123.00, 'R B PADS SEAT EXEO SHAKOOR', 'VE62SVF', NULL, '2023-08-21 00:00:00', '2023-08-21 17:14:38'),
-- (195, 1, 'IV228647', 91.00, 1123.00, 'SERVICE KIT AND R BRAKE PADS R.ROVER', 'EY64DGU', NULL, '2023-08-21 00:00:00', '2023-08-21 17:15:25'),
-- (196, 2, '04554476', 78.53, 0.00, 'MIDDLE AND BACK EXT MICRA', 'X273RCX', NULL, '2023-08-21 00:00:00', '2023-08-21 17:16:11'),
-- (197, 1, 'IV229557', 70.00, 0.00, 'TIMING CHAIN KIT CORSA', 'YA12NKK', NULL, '2023-08-29 00:00:00', '2023-08-29 17:26:35'),
-- (198, 3, 'LEA2145960', 16.62, 0.00, 'CAM SHAFT SENSOR CORSA', 'YA12NKK', NULL, '2023-08-29 00:00:00', '2023-08-29 17:27:16'),
-- (199, 2, '04558901', 59.02, 83398.00, '3PC CLUTCH TRANSMECH ZAFIRA', 'CA08URD', NULL, '2023-08-29 00:00:00', '2023-08-29 17:29:05'),
-- (200, 2, '04558897', 26.34, 101702456.00, 'F B PADS', 'ELGRAND', NULL, '2023-08-29 00:00:00', '2023-08-29 17:29:50'),
-- (201, 1, 'IV229682', 12.00, 0.00, '2 LINK FRONT GOLF', 'LS9607', NULL, '2023-08-29 00:00:00', '2023-08-29 17:31:25'),
-- (202, 2, '04560752', 164.50, 1111.00, 'ALTERNATOR MERCEDES', 'KS55ZZD', NULL, '2023-09-01 00:00:00', '2023-09-01 16:42:36'),
-- (203, 1, 'iv230434', 121.00, 96125.00, 'R DISCPADS F B PAD APEC SHARAN', 'FR13LBN', NULL, '2023-09-02 00:00:00', '2023-09-04 15:49:27'),
-- (204, 1, 'IV230593', 3.00, 22.00, 'OIL FILTER', 'LL62VXG', NULL, '2023-09-04 00:00:00', '2023-09-04 15:51:09'),
-- (205, 6, 'in782862', 108.00, 0.00, 'ZAFIRA TIMING BELT W/P', 'LJ55EBL', NULL, '2023-09-05 00:00:00', '2023-09-05 14:56:29'),
-- (206, 2, '04562798', 29.77, 12.00, 'SPRINTER LH MOUNTING SHOCKER', 'HY12HFZ', NULL, '2023-09-05 00:00:00', '2023-09-05 14:58:53'),
-- (207, 1, 'IV230745', 43.00, 0.00, 'RH SHOC CORSA', 'KP57WHN', NULL, '2023-09-05 00:00:00', '2023-09-05 15:00:10'),
-- (208, 3, 'lea2148003', 28.46, 0.00, 'NO 2 IGNITION COIL KIA CARENS', 'NU08YZG', NULL, '2023-09-06 00:00:00', '2023-09-06 17:06:37'),
-- (209, 1, 'IV230641', 110.00, 0.00, 'REAR EXHAUST  KIA  CEED', 'NU08YZG', NULL, '2023-09-05 00:00:00', '2023-09-06 17:11:14'),
-- (210, 2, '04564985', 95.70, 0.00, 'SATCH CLUTCH', 'SL56UBW', NULL, '2023-09-08 00:00:00', '2023-09-08 15:22:52'),
-- (211, 1, 'IV231208', 33.00, 0.00, 'FUEL FILTER', 'WD18XLP', NULL, '2023-09-08 00:00:00', '2023-09-08 15:27:11'),
-- (212, 2, '04565382', 72.58, 0.00, 'battery star lion mer cedes 017', 'wn58kdj', NULL, '2023-09-09 00:00:00', '2023-09-09 13:49:11'),
-- (213, 1, 'IV232509', 34.50, 0.00, 'OIL AIR FUEL', 'MA56AZN', NULL, '2023-09-16 00:00:00', '2023-09-16 13:01:06'),
-- (214, 6, 'IN784377', 3.68, 47192.00, 'OIL FILTER', 'PJ65EUF', NULL, '2023-09-16 00:00:00', '2023-09-16 13:01:55'),
-- (215, 3, 'lea2150837', 64.58, 123.00, 'RH REAR CALIPER HYUNDAI COUPE', 'AAM17G', NULL, '2023-09-18 00:00:00', '2023-09-18 17:17:59'),
-- (216, 4, '24407505', 50.65, 54.00, 'BATTERY YARIS', 'FG06LVB', NULL, '2023-09-19 00:00:00', '2023-09-20 08:36:08'),
-- (217, 2, '04612894', 89.96, 2.00, 'vacuum pump dimitri', 'mf04xzz', NULL, '2023-12-01 00:00:00', '2023-12-01 18:33:54'),
-- (218, 2, '04616397', 73.79, 79086.00, 'CLUTCH hyundai i30 excedy', 'YX60VLN', NULL, '2023-12-07 00:00:00', '2023-12-07 17:23:21'),
-- (219, 2, '04630247', 29.05, 0.00, 'REAR BREAK PADS\r\nFRONT SENSOR', 'LO65MYR', NULL, '2024-01-09 00:00:00', '2024-01-12 16:04:27'),
-- (220, 2, '670013', 23.18, 0.00, 'ENGINE OIL', 'P36318', NULL, '2023-12-22 00:00:00', '2024-01-12 16:09:14'),
-- (221, 1, 'IV248000', 33.50, 0.00, 'BRAKE DISC\r\nBRAKE PADS', 'X273RCX', NULL, '2024-01-09 00:00:00', '2024-01-12 16:11:22'),
-- (222, 3, 'LEA2175072', 150.00, 0.00, 'DRIVESHAFTS\r\nOLD UNIT CHARGE', 'GK550WU', NULL, '2024-01-09 00:00:00', '2024-01-12 16:14:11'),
-- (223, 2, '04630218', 25.73, 0.00, 'BOSH AIR FILTER\r\nMANN OIL FILTER', 'LO65MYR', NULL, '2024-01-09 00:00:00', '2024-01-12 16:26:59'),
-- (224, 2, '04630219', 10.61, 0.00, 'AIR FILTER\r\nBOSH OIL FILTER', 'NL59FDX', NULL, '2024-01-09 00:00:00', '2024-01-12 16:28:45'),
-- (225, 2, '04630393', 16.79, 0.00, 'CONCENTRATED SCREENWAS', NULL, NULL, '2024-01-09 00:00:00', '2024-01-12 16:31:46'),
-- (226, 2, '04623555', 10.56, 0.00, 'OIL FILTER', 'MF54VAH', NULL, '2023-12-21 00:00:00', '2024-01-12 16:33:39'),
-- (227, 1, 'IV245837', 314.00, 0.00, 'BREAK PAD\r\nBRAKE DISC\r\nAPEC BRAKE PAD\r\nAPEC BRAKE DISC', 'YY16HTA', NULL, '2023-12-21 00:00:00', '2024-01-12 16:36:46'),
-- (228, 2, '04623392', 14.77, 0.00, 'DRIVE BELT', 'YK55TVM', NULL, '2023-12-20 00:00:00', '2024-01-12 16:38:43'),
-- (229, 2, '04623357', 211.87, 0.00, 'STARTER MOTOR LUCAS', 'VK04DDJ', NULL, '2023-12-20 00:00:00', '2024-02-12 16:10:52'),
-- (230, 3, 'LEA2172270', 66.60, 0.00, 'WHEEL BEARING HUB FIT', 'BD63CFX', NULL, '2023-12-20 00:00:00', '2024-01-12 16:43:19'),
-- (231, 2, '04623142', 71.90, 0.00, 'ALT PEUGOT 80A', 'YK55TVM', NULL, '2023-12-20 00:00:00', '2024-01-12 16:45:26'),
-- (232, 2, '04622981', 6.07, 0.00, 'FLAT WIPER BLAD', 'FP69RYM', NULL, '2023-12-20 00:00:00', '2024-01-12 16:47:33'),
-- (233, 4, '25505776', 77.22, 0.00, 'PULLEY\r\nDRIVEALIGN IDLER', 'MF04XZZ', NULL, '2024-01-09 00:00:00', '2024-01-12 17:19:10'),
-- (234, 2, '04632480', 24.28, 0.00, 'AIR FILTER\r\nOIL FILTER', 'AO61CZB', NULL, '2024-01-12 00:00:00', '2024-01-12 17:22:39'),
-- (235, 6, 'IN798740', 61.85, 0.00, 'TIE ROD END\r\nOIL FILTER\r\nAIR FILTER\r\nBRAKE PADS X2', 'VO62ULL', NULL, '2024-01-12 00:00:00', '2024-01-12 17:24:51'),
-- (236, 2, '04632763', 132.00, 0.00, 'TVD BOLT\r\nCRANKSHAFT PULLEY', 'WBAUG52090PE73488', NULL, '2024-01-12 00:00:00', '2024-01-12 17:26:50'),
-- (237, 2, '04632698', 88.09, 0.00, 'V/BELT TENSIONER\r\nDRIVE BELT ELASTIC\r\nDRIVE BELT ALFA BMW', 'WBAUG52090PE73488', NULL, '2024-01-12 00:00:00', '2024-01-12 17:28:49'),
-- (238, 6, 'IN798779', 15.00, 0.00, 'COB LED MINI HAND TORCH', 'LED500SB', NULL, '2024-01-12 00:00:00', '2024-01-12 17:30:03'),
-- (239, 1, 'IV248816', 25.00, 0.00, 'TIE ROD END\r\nBALL JOINT', 'AD10MTY', NULL, '2024-01-15 00:00:00', '2024-01-15 18:09:59'),
-- (240, 2, '04633255', 38.63, 0.00, 'SHOCK ABSORBER FRONT', 'DE63YXW', NULL, '2024-01-13 00:00:00', '2024-01-15 18:16:52'),
-- (241, 2, '04634148', 38.65, 0.00, 'ENGINE MOUNTING', 'AD10MTY', NULL, '2024-01-15 00:00:00', '2024-01-15 18:18:20'),
-- (242, 6, 'IN799506', 42.59, 0.00, 'WATER PUMP\r\nOIL FILTER', 'YA55ZOO', NULL, '2024-01-18 00:00:00', '2024-01-18 15:20:20'),
-- (243, 2, '0436163', 3.42, 0.00, 'OIL FILTER', 'FJ14FWA', NULL, '2024-01-18 00:00:00', '2024-01-18 15:21:22'),
-- (244, 2, '04635923', 24.60, 0.00, 'AIR FILTER X2\r\nOIL FILTER', 'WJ57MUU', NULL, '2024-01-18 00:00:00', '2024-01-18 15:22:26'),
-- (245, 1, 'IV249024', 18.00, 0.00, 'UNDERBODY SCHUTZ 1', 'AJA01', NULL, '2024-01-17 00:00:00', '2024-01-18 15:23:44'),
-- (246, 2, '04635640', 7.94, 0.00, 'STABILISER LINK', 'INZ2716', NULL, '2024-01-17 00:00:00', '2024-01-18 15:24:52'),
-- (247, 1, 'IV249101', 500.00, 0.00, 'ENERGY PREMIUM 5W30 C3 208', 'AJA01', NULL, '2024-01-17 00:00:00', '2024-01-18 15:27:04'),
-- (248, 3, 'LEA2176783', 30.82, 0.00, 'DIESEL FILTER', 'AD10MTY', NULL, '2024-01-16 00:00:00', '2024-01-18 15:28:16'),
-- (249, 2, '04637965', 114.00, 0.00, 'clutch velo nissan qashqai alena', 'sa61dvv', NULL, '2024-01-22 00:00:00', '2024-01-22 17:05:10'),
-- (250, 15, '72in005345', 180.00, 0.00, 'ZAFIRA LUK CLUTCH', 'LL09FHV', NULL, '2024-01-22 00:00:00', '2024-01-22 17:06:43'),
-- (251, 1, 'IV249859', 15.00, 0.00, 'BRAKE FLUID', 'AJA01', NULL, '2024-01-22 00:00:00', '2024-01-23 18:13:42'),
-- (252, 2, '04643469', 49.98, 0.00, 'ford psa fiat jumper ducato tr', 'AD10MTY', NULL, '2024-01-31 00:00:00', '2024-02-01 08:56:21'),
-- (253, 2, '04643402', 8.06, 0.00, 'AIR FILTER\r\nOIL FILTER', 'YA07FSC', NULL, '2024-01-31 00:00:00', '2024-02-01 08:57:53'),
-- (254, 2, '04643408', 35.53, 0.00, 'FUEL FILTER', 'KV61RZG', NULL, '2024-01-31 00:00:00', '2024-02-01 09:03:55'),
-- (255, 2, '04643375', 18.26, 0.00, 'AIR FILTER\r\nFUEL FILTER', 'DS68MJO', NULL, '2024-01-31 00:00:00', '2024-02-01 09:05:04'),
-- (256, 1, 'IV251031', 22.00, 0.00, 'TOP STRUT MOUNT KIT', 'PX59VCG', NULL, '2024-01-30 00:00:00', '2024-02-01 09:08:33'),
-- (257, 2, '04642609', 10.61, 0.00, 'AIR FILTER\r\nOIL FILTER', 'SK63RVT', NULL, '2024-01-30 00:00:00', '2024-02-01 09:10:02'),
-- (258, 15, '72IN005889', 55.20, 0.00, 'SHOCK ABSORBER', 'PX59VCG', NULL, '2024-01-30 00:00:00', '2024-02-01 09:17:00'),
-- (259, 1, 'IV253302', 51.50, 123141.00, 'TOYOTA ALPHARD AIR OIL S.PLUG', 'FB57YLA', NULL, '2024-02-13 00:00:00', '2024-02-13 18:43:13'),
-- (260, 6, 'IN802853', 31.61, 0.00, '75W-90 FS (5L)', 'N3045L', NULL, '2024-02-13 00:00:00', '2024-02-14 09:12:59'),
-- (261, 1, 'IV253207', 34.00, 0.00, 'SPARK PLUG', 'AK18FTY', NULL, '2024-02-13 00:00:00', '2024-02-14 09:14:02'),
-- (262, 2, '04650516', 8.02, 0.00, 'AIR FILTER\r\nOIL FILTER', 'BJ64HCC', NULL, '2024-02-13 00:00:00', '2024-02-14 09:15:27'),
-- (263, 2, '04650470', 9.37, 0.00, 'AIR FILTER\r\nOIL FILTER', 'AK18FTY', NULL, '2024-02-13 00:00:00', '2024-02-14 09:16:35'),
-- (264, 2, '04650157', 164.40, 0.00, 'CLUTCH KIT', 'BN06JKO', NULL, '2024-02-12 00:00:00', '2024-02-14 09:18:03'),
-- (265, 2, '04650114', 6.74, 0.00, 'AIR FILTER\r\nOIL FILTER', 'YF09BYD', NULL, '2024-02-12 00:00:00', '2024-02-14 09:19:11'),
-- (266, 2, '04649875', 4.46, 0.00, 'RARE WIPER BLADE', 'FJ62YDU', NULL, '2024-02-12 00:00:00', '2024-02-14 09:20:19'),
-- (267, 1, 'IV252769', 51.00, 0.00, 'TRACK CONTROL ARM', 'J1UAH', NULL, '2024-02-10 00:00:00', '2024-02-14 09:22:02'),
-- (268, 2, '0469196', 15.53, 0.00, 'AIR FILTER \r\nOIL FILTER', 'LA05GOK', NULL, '2024-02-10 00:00:00', '2024-02-14 09:23:01'),
-- (269, 1, 'IV252837', 36.00, 0.00, 'WHEEL BEARING KIT', 'OY58GGZ', NULL, '2024-02-10 00:00:00', '2024-02-14 09:24:09'),
-- (270, 2, '04643479', 49.98, 0.00, 'FORD PSA FIAT JUMPER DUCATO TR', 'AD1OMTY', NULL, '2024-01-31 00:00:00', '2024-02-14 09:25:44'),
-- (271, 1, 'IV251378', 63.00, 0.00, 'ABDS TENSIONER\r\nFAN BELT', 'AD10MTY', NULL, '2024-02-01 00:00:00', '2024-02-14 09:34:27'),
-- (272, 2, '04637758', 43.06, 0.00, 'GAS SPRING BOOT', 'FE07GUW', NULL, '2024-01-22 00:00:00', '2024-02-14 09:37:34'),
-- (273, 2, '04637880', 16.40, 0.00, 'FRONT VAUXHALL CORSA MK111 06-', 'YR62LSY', NULL, '2024-01-22 00:00:00', '2024-02-14 09:40:09'),
-- (274, 2, '04637908', 23.16, 0.00, 'AIR FILTER \r\nOIL FILTER', 'E15JAY', NULL, '2024-01-22 00:00:00', '2024-02-14 09:41:25'),
-- (275, 1, 'IV249064', 75.50, 0.00, 'BRAKE DISC \r\nBRAKE PADS', 'GY59UZF', NULL, '2024-01-17 00:00:00', '2024-02-14 09:43:23'),
-- (276, 2, '04640989', 2.11, 0.00, 'OIL FILTER', 'SY08ZPV', NULL, '2024-01-26 00:00:00', '2024-02-14 09:46:03'),
-- (277, 2, '04640711', 2.86, 0.00, 'EXHAUST CLAM', NULL, NULL, '2024-01-26 00:00:00', '2024-02-14 09:47:44'),
-- (278, 2, '03078891', 10.28, 0.00, 'AIR FILTER', 'SD08WNG', NULL, '2024-01-26 00:00:00', '2024-02-14 09:49:12'),
-- (279, 2, '04640111', 22.24, 0.00, 'FRONT STABILISER\r\nAIR FILTER\r\nOIL FILTER', 'PK08WLA', NULL, '2024-01-25 00:00:00', '2024-02-14 09:51:23'),
-- (280, 2, '04639814', 11.54, 0.00, 'STABILISER LINK', 'F158RZS', NULL, '2024-01-24 00:00:00', '2024-02-14 09:52:59'),
-- (281, 2, '04640005', 21.07, 0.00, 'AIR FILTER\r\nOIL FILTER', 'KR60LFO', NULL, '2024-01-25 00:00:00', '2024-02-14 09:54:28'),
-- (282, 2, '04639697', 15.76, 0.00, 'AIR FILTER\r\nOIL FILTER', 'FG60OGS', NULL, '2024-01-24 00:00:00', '2024-02-14 09:56:00'),
-- (283, 10, '236728504', 72.59, 0.00, 'WATER PUMP\r\nCOOLANT\r\nOIL FILTER\r\nLL-03 5L CUBE', 'AV12NZT', NULL, '2024-01-24 00:00:00', '2024-02-14 09:58:47'),
-- (284, 2, '04668398', 3.34, 0.00, 'OIL FILTER', 'MJ52VJX', NULL, '2024-03-18 00:00:00', '2024-03-19 15:25:52'),
-- (285, 2, '04668714', 24.43, 0.00, 'DRIVE BELT X2\r\nOIL FILTER', 'BJ08VHA', NULL, '2024-03-18 00:00:00', '2024-03-19 15:27:16'),
-- (286, 1, 'IV258550', 8.00, 0.00, 'FAN BELT', NULL, NULL, '2024-03-18 00:00:00', '2024-03-19 15:29:27'),
-- (287, 1, 'IV258291', 101.50, 0.00, 'EXHAUST REAR BOX\r\nEXHAUST CENTRE PIPE\r\nEXHAUST GASKET\r\nU CLAMP\r\nOIL FILTER\r\nAIR FILTER', 'BJ12ZHN', NULL, '2024-03-16 00:00:00', '2024-03-19 15:32:02'),
-- (288, 2, '04667899', 4.33, 0.00, 'OIL FILTER', 'DE07UKY', NULL, '2024-03-16 00:00:00', '2024-03-19 15:33:01'),
-- (289, 2, '04667872', 23.57, 0.00, 'FRONT PADS', 'AJ08DTO', NULL, '2024-03-16 00:00:00', '2024-03-19 15:34:21'),
-- (290, 3, 'LEA2190698', 37.92, 0.00, 'ENGINE MOUNTING', 'MA56AZN', NULL, '2024-03-15 00:00:00', '2024-03-19 15:36:04'),
-- (291, 2, '04667493', 39.82, 0.00, 'ENGINE MOUNT', 'MA56AZN', NULL, '2024-03-15 00:00:00', '2024-03-19 15:37:36'),
-- (292, 2, '04667450', 46.60, 0.00, 'POLLEN FILTER\r\nFUEL FILTER\r\nAIR FILTER\r\nOIL FILTER', 'OU09XTP', NULL, '2024-03-15 00:00:00', '2024-03-19 15:39:31'),
-- (293, 1, '04667433', 21.54, 0.00, 'ISOPON FILLER', NULL, NULL, '2024-03-15 00:00:00', '2024-03-19 15:41:16'),
-- (294, 1, 'IV258099', 85.00, 0.00, 'WATER PUMP', 'GU12PPV', NULL, '2024-03-15 00:00:00', '2024-03-19 15:42:15'),
-- (295, 2, '04667330', 9.62, 0.00, 'BIO TOP WHITE GREASE SPRAY 400', NULL, NULL, '2024-03-15 00:00:00', '2024-03-19 15:44:05'),
-- (296, 2, '04667252', 11.08, 0.00, 'AIR FILTER\r\nOIL FILTER', 'CV57CWD', NULL, '2024-03-15 00:00:00', '2024-03-19 15:45:19'),
-- (297, 1, 'IV257949', 38.00, 0.00, 'GLOW PLUGS', 'YX11ZMY', NULL, '2024-03-14 00:00:00', '2024-03-19 15:46:49'),
-- (298, 2, '04666996', 82.61, 0.00, 'LOWER SUSPENSION ARM\r\nBALL JOINT\r\nOUTER TIE ROD END', 'MA56AZN', NULL, '2024-03-14 00:00:00', '2024-03-19 15:48:59'),
-- (299, 2, '04667088', 44.69, 0.00, 'LOWER SUSPENSION ARM', 'MA56AZN', NULL, '2024-03-14 00:00:00', '2024-03-19 15:50:25'),
-- (300, 2, '04667041', 21.53, 0.00, 'GEARBOX MOUNTING REAR', 'MA56AZN', NULL, '2024-03-14 00:00:00', '2024-03-19 15:51:47'),
-- (301, 2, '04666165', 16.99, 0.00, 'COOLANT TEMPERATURE SWITCH', 'YT55FUU', NULL, '2024-03-13 00:00:00', '2024-03-19 15:53:03'),
-- (302, 2, '04666170', 29.69, 0.00, 'SPARK PLUG\r\nAIR FILTER\r\nOIL FILTER', 'EJ12DXM', NULL, '2024-03-13 00:00:00', '2024-03-19 15:54:43'),
-- (303, 1, 'IV257700', 64.00, 0.00, 'COIL SPRING FRONT', 'W4LJJ', NULL, '2024-03-13 00:00:00', '2024-03-19 15:56:18'),
-- (304, 2, '04664815', 69.06, 0.00, 'COIL SPRING REAR', 'BD64HLK', NULL, '2024-03-11 00:00:00', '2024-03-19 15:57:33'),
-- (305, 2, '04664726', 14.89, 0.00, 'FRONT STABILISER\r\nOIL FILTER', 'BD64HLK', NULL, '2024-03-11 00:00:00', '2024-03-19 16:08:23'),
-- (306, 2, '04664742', 2.02, 0.00, 'SUMP PLUG', 'BD64HLK', NULL, '2024-03-11 00:00:00', '2024-03-19 16:14:43'),
-- (307, 2, '04664898', 28.32, 0.00, 'OSRAM COOL BLUE INTENSE H11 12', NULL, NULL, '2024-03-11 00:00:00', '2024-03-19 16:16:31'),
-- (308, 1, 'IV257299', 76.00, 0.00, 'BRAKE DISC\r\nBRAKE PADS', 'WR06EOX', NULL, '2024-03-09 00:00:00', '2024-03-19 16:18:04'),
-- (309, 2, '04664182', 56.60, 0.00, 'FUEL FILTER\r\nAIR FILTER\r\nOIL FILTER', 'KN60LJO', NULL, '2024-03-09 00:00:00', '2024-03-19 16:20:40'),
-- (310, 1, 'IV257195', 105.00, 0.00, 'T/BELT KIT + W/PUMP', 'EF13UWM', NULL, '2024-03-09 00:00:00', '2024-03-19 16:22:08'),
-- (311, 2, '04663601', 6.77, 0.00, 'AIR FILTER\r\nOIL FILTER', 'FE14GAO', NULL, '2024-03-08 00:00:00', '2024-03-19 16:24:05'),
-- (312, 2, '04663977', 210.00, 0.00, 'THROTTLE BODY', 'BF16YFM', NULL, '2024-03-08 00:00:00', '2024-03-19 16:25:18'),
-- (313, 2, '04644109', 25.62, 0.00, 'DRIVE BELT', 'AD10MTY', NULL, '2024-03-08 00:00:00', '2024-03-19 16:26:14'),
-- (314, 2, '04644047', 12.17, 0.00, 'BOTTOM GUARD BLACK UNDERBODY', NULL, NULL, '2024-02-01 00:00:00', '2024-03-19 16:36:28'),
-- (315, 2, '04643978', 17.65, 0.00, 'CLUTCH MASTER CYLINDER FIESTA', 'YD07JFF', NULL, '2024-02-01 00:00:00', '2024-03-19 16:38:13'),
-- (316, 1, 'IV251347', 135.00, 0.00, 'NAPA ALTERNATOR', 'R970SKW', NULL, '2024-02-01 00:00:00', '2024-03-19 16:40:45'),
-- (317, 1, 'IV251200', 12.50, 0.00, 'DRIVE BELT', NULL, NULL, '2024-01-31 00:00:00', '2024-03-19 16:42:05'),
-- (318, 2, '04659552', 117.64, 0.00, 'SUSPENSION X2 R--L\r\nBALL JOINT X2 R-L', 'PX60WEW', NULL, '2024-02-29 00:00:00', '2024-03-19 16:43:57'),
-- (319, 2, '04659246', 10.19, 0.00, 'BOTTOMGUARD BLACK UNDERBODY', 'SUNNY', NULL, '2024-02-29 00:00:00', '2024-03-19 16:45:36'),
-- (320, 2, '04669710', 6.25, 0.00, 'OIL FILTER', 'FD56SRY', NULL, '2024-03-20 00:00:00', '2024-03-20 13:02:30'),
-- (321, 2, '04669024', 17.60, 0.00, 'DRIVE BELT', 'SUNNY', NULL, '2024-03-19 00:00:00', '2024-03-20 13:03:33'),
-- (322, 2, '04668956', 32.76, 0.00, 'WIPER BLADE-5 UNIVERSAL X4', 'SUNNY', NULL, '2024-03-18 00:00:00', '2024-03-20 13:04:57'),
-- (323, 6, '21926158', 59.50, 0.00, 'BATTERY', 'MM14FTF', NULL, '2023-01-19 00:00:00', '2024-03-20 13:07:39'),
-- (324, 6, '26306042', 22.54, 0.00, 'VALVE ASSY', 'AU04', NULL, '2024-03-19 00:00:00', '2024-03-20 13:08:58'),
-- (325, 1, 'IV258667', 48.00, 0.00, 'BRAKE PADS X2', 'OU07KXZ', NULL, '2024-03-19 00:00:00', '2024-03-20 13:10:13'),
-- (326, 2, '04669585', 32.06, 0.00, 'FRONT BRAKE PADS', 'FD56SRY', NULL, '2024-03-19 00:00:00', '2024-03-20 13:11:04'),
-- (327, 2, '04658749', 27.25, 0.00, 'SPARK PLUG\r\nAIR FILTER\r\nOIL FILTER', 'RO15WPA', NULL, '2024-02-28 00:00:00', '2024-03-20 13:12:49'),
-- (328, 3, 'LEA2186745', 21.00, 0.00, 'TENSION ROLLER, RIBBED BELT', 'HJ66HDN', NULL, '2024-02-28 00:00:00', '2024-03-20 13:14:47'),
-- (329, 2, '04658652', 44.33, 0.00, 'ENGINE MOUNT', 'HJ66HDN', NULL, '2024-02-28 00:00:00', '2024-03-20 13:16:02'),
-- (330, 2, '04658602', 48.68, 0.00, 'IGNITION COIL', 'YB09PBX', NULL, '2024-02-28 00:00:00', '2024-03-20 13:17:10'),
-- (331, 2, '04658433', 10.12, 0.00, 'AIR FILTER\r\nOIL FILTER', 'GV61NXU', NULL, '2024-02-28 00:00:00', '2024-03-20 13:20:18'),
-- (332, 2, '04659139', 13.26, 0.00, 'AIR FILTER\r\nSUMP PLUG\r\nOIL FILTER', 'FY66SXB', NULL, '2024-02-29 00:00:00', '2024-03-20 13:22:02'),
-- (333, 1, 'IV254935', 45.00, 0.00, 'OIL FILTER\r\nAIR FILTER\r\nCABIN FILTER', 'KV61LKO', NULL, '2024-02-23 00:00:00', '2024-03-20 13:31:17'),
-- (334, 1, 'IV254956', 60.00, 0.00, 'SUSPENSION ARM\r\nANTI ROLL BAR\r\nWEEL CYLINDER\r\nBRAKE SHOES', 'SC65ZLK', NULL, '2024-02-23 00:00:00', '2024-03-20 13:33:00'),
-- (335, 2, '04653015', 83.11, 0.00, 'TOP STRUT MOUNT FRONT\r\nFRONT B/PADS\r\nFRONT B/DISC', 'BT56VKK', NULL, '2024-02-17 00:00:00', '2024-03-20 13:34:38'),
-- (336, 1, 'IV254229', 445.00, 0.00, 'OIL ENERGY PREMIUM', NULL, NULL, '2024-02-20 00:00:00', '2024-03-20 13:36:02'),
-- (337, 2, '04655321', 120.26, 0.00, 'REAR BRAKE PADS\r\nWISHBONE FRONT LOWER', 'WP57AMU', NULL, '2024-02-22 00:00:00', '2024-03-20 13:37:21'),
-- (338, 3, 'LEA2186104', 97.63, 0.00, 'OIL SHOCK ABSORBER', 'NEOX3665', NULL, '2024-02-26 00:00:00', '2024-03-20 13:38:34'),
-- (339, 1, 'IV255142', 24.00, 0.00, 'COIL SPRING FRONT', 'LM60EWL', NULL, '2024-02-26 00:00:00', '2024-03-20 13:39:41'),
-- (340, 2, '04657021', 81.59, 0.00, 'CLUTCH KIT WITH BEARING HY', 'AJ06SYO', NULL, '2024-02-26 00:00:00', '2024-03-20 13:41:02'),
-- (341, 1, 'IV255055', 33.00, 0.00, 'SHOCK ABS REAR', 'KB07RDO', NULL, '2024-02-24 00:00:00', '2024-03-20 13:42:13'),
-- (342, 1, 'IV255076', 6.50, 0.00, 'BGA STABILISER LINK', 'BV09PKD', NULL, '2024-02-24 00:00:00', '2024-03-20 13:43:28'),
-- (343, 1, 'IV255063', 4.00, 0.00, 'OIL FILTER', 'YN15OEA', NULL, '2024-02-24 00:00:00', '2024-03-20 13:45:22'),
-- (344, 1, 'IV255000', 100.00, 0.00, 'BGA STABILISER LINK X2\r\nAPEC STABILISER LINK X2 (L-R)', 'RN04BYP', NULL, '2024-02-24 00:00:00', '2024-03-20 13:47:27'),
-- (345, 1, 'IV254874', 19.00, 0.00, 'OVERRUNNING ALTERNATOR', 'DS61HGU', NULL, '2024-02-23 00:00:00', '2024-03-20 13:49:28'),
-- (346, 1, 'IV254844', 56.00, 0.00, 'FEBI AIR FILTER\r\nCABIN FILTER\r\nOIL FILTER\r\nFAN BELT\r\nDAYCO DRIVE BELT', 'SB55FHK', NULL, '2024-02-23 00:00:00', '2024-03-20 13:51:32'),
-- (347, 1, 'IV254920', 28.00, 0.00, 'DRIVEALIGN IDLER', 'SB55FHK', NULL, '2024-02-23 00:00:00', '2024-03-20 13:52:53'),
-- (348, 1, 'IV254921', 39.00, 0.00, 'TENSIONER', 'SB55FHK', NULL, '2024-02-23 00:00:00', '2024-03-20 13:54:11'),
-- (349, 1, 'IV254505', 7.00, 0.00, 'OIL FILTER', 'GJ68WKW', NULL, '2024-02-23 00:00:00', '2024-03-20 13:55:33'),
-- (350, 2, '04652362', 9.13, 0.00, 'BALL JOINT LOWER LH/RH', 'RV05XXB', NULL, '2024-02-16 00:00:00', '2024-03-20 14:11:01'),
-- (351, 6, 'IN803237', 3.96, 0.00, 'OIL FILTER', 'KX60BPZ', NULL, '2024-02-16 00:00:00', '2024-03-20 14:12:19'),
-- (352, 2, '04652765', 21.24, 0.00, 'REAR PADS CITR BERLINGO', 'AV10UUY', NULL, '2024-02-16 00:00:00', '2024-03-20 14:14:18'),
-- (353, 2, '04663295', 16.99, 0.00, 'COOLANT TEMPERATURE SWITCH', 'T291TWX', NULL, '2024-03-07 00:00:00', '2024-03-20 14:15:26'),
-- (354, 2, '04663233', 25.68, 0.00, 'FUEL FILTER', 'T291TWX', NULL, '2024-03-07 00:00:00', '2024-03-20 14:16:35'),
-- (355, 2, '04662540', 16.30, 0.00, 'V/BELT DEFLECTION PULLEY MERCE', NULL, NULL, '2024-03-06 00:00:00', '2024-03-20 14:18:07'),
-- (356, 2, '04662020', 12.86, 0.00, 'AIR FILTER\r\nOIL FILTER', 'D12WKC', NULL, '2024-03-05 00:00:00', '2024-03-20 14:19:27'),
-- (357, 2, '04661908', 26.58, 0.00, 'SHOCK ABSORBER REAR ABSO IBIZA', 'FJ03ZNC', NULL, '2024-03-05 00:00:00', '2024-03-20 14:20:59'),
-- (358, 3, 'LEA2188133', 9.31, 0.00, 'VOLT BRAKE LIGHT SWITCH', 'FJ03ZNC', NULL, '2024-03-05 00:00:00', '2024-03-20 14:26:53'),
-- (359, 2, '04661756', 20.39, 0.00, 'AIR FILTER\r\nOIL FILTER', 'BT16YSW', NULL, '2024-03-05 00:00:00', '2024-03-20 14:28:27'),
-- (360, 2, '04669863', 18.68, 0.00, 'WHL BRG PEUGEOT 207', 'BP08LYG', NULL, '2024-03-05 00:00:00', '2024-04-03 17:18:59'),
-- (361, 2, '04669839', 13.67, 0.00, 'STABILISER LINK FRONT RH', 'DK57VLL', NULL, '2024-03-20 00:00:00', '2024-04-03 17:20:41'),
-- (362, 2, '04670324', 9.49, 0.00, 'AIR FILTER\r\nOIL FILTER', 'PK15PLX', NULL, '2024-03-21 00:00:00', '2024-04-03 17:21:52'),
-- (363, 1, 'IV258976', 86.00, 0.00, 'BRAKE PADS\r\nBRAKE DISC', 'LA05GOK', NULL, '2024-03-21 00:00:00', '2024-04-03 17:23:06'),
-- (364, 6, 'IN807559', 51.26, 0.00, 'STABILIZER LINK\r\nCOIL SPRING FRONT\r\nSTRUT MOUNTING L/R FRONT', 'YX11TVE', NULL, '2024-03-21 00:00:00', '2024-04-03 17:24:46'),
-- (365, 6, 'IN807582', 37.52, 0.00, 'WHEEL SPEED SENSOR\r\nAPEC ABS RING', 'NK06YGH', NULL, '2024-03-21 00:00:00', '2024-04-03 17:26:17'),
-- (366, 2, '04670768', 83.87, 0.00, 'T/BELT KIT RENAULT SUZUKI NISS\r\nWATER PUMP', 'J44XEY', NULL, '2024-03-21 00:00:00', '2024-04-03 17:28:13'),
-- (367, 1, 'IV259151', 120.00, 0.00, 'TRANSMISSION FILTER\r\nATF O.E.M MULTIVEHICLE JWS3', 'WBANX51030CT645', NULL, '2024-03-22 00:00:00', '2024-04-03 17:30:25'),
-- (368, 3, 'LEA2192253', 88.31, 0.00, 'RADIATOR', '7AANO1', NULL, '2024-03-22 00:00:00', '2024-04-03 17:31:56'),
-- (369, 6, 'IN807714', 46.98, 0.00, 'STABILIZER LINK L/R\r\nSHOCK ABS LH FRONT', 'FV54LWD', NULL, '2024-03-22 00:00:00', '2024-04-03 17:33:38'),
-- (370, 2, '04671429', 50.32, 0.00, 'EXHAUST SILENCER GASKET\r\nCENTRE BOX MICRA', 'FV54LWD', NULL, '2024-03-22 00:00:00', '2024-04-03 17:35:21'),
-- (371, 2, '+04672128', 27.88, 0.00, 'REAR AXEL BUSH FRONT LH\r\nREAR AXEL BUSH FRONT RH', 'YS59WUV', NULL, '2024-03-25 00:00:00', '2024-04-03 17:37:32'),
-- (372, 1, 'IV259448', 13.00, 0.00, 'STABILIZER LINK L/R', 'YC54DCF', NULL, '2024-03-25 00:00:00', '2024-04-03 17:39:00'),
-- (373, 1, 'IV259606', 26.00, 0.00, 'OIL FILTER\r\nAIR FILTER\r\nPOLLEN FILTER\r\nSTABILIZER LINK', 'FY10FAK', NULL, '2024-03-25 00:00:00', '2024-04-03 17:43:10'),
-- (374, 1, 'IV259314', 33.50, 0.00, 'BGA STABILIZER LINK\r\nNAPA FR BRAKE PADS', 'GY07LKP', NULL, '2024-03-23 00:00:00', '2024-04-03 17:44:52'),
-- (375, 1, 'IV259449', 54.00, 0.00, 'NAPA FR BRAKE PADS\r\nNAPA RR BRAKE PADS \r\nSTRETCH BOOTKIT', 'DA15ROU', NULL, '2024-03-25 00:00:00', '2024-04-03 17:46:57'),
-- (376, 1, 'IV259522', 66.00, 0.00, 'NAPA FRBRAKE PADS \r\nNAPA RR BRAKE PADS\r\nOIL FILTER\r\nAIR FILTER\r\nFEBI POLLEN FILTER', 'DS11MXB', NULL, '2024-03-25 00:00:00', '2024-04-03 17:48:45'),
-- (377, 6, 'IN808111', 41.50, 0.00, 'APEC BRAKE CALIPER SURCHARG', 'BF06ZDT', NULL, '2024-03-26 00:00:00', '2024-04-03 17:50:06'),
-- (378, 6, 'IN808108', 38.24, 0.00, 'AUTO TRANS UNIVERSAL D 11\r\n3W COB LED MINI HAND TORCH', NULL, NULL, '2024-03-26 00:00:00', '2024-04-03 17:51:55'),
-- (379, 2, '04672988', 7.94, 0.00, 'STABILISER LINK LH/RH', 'HDO60XG', NULL, '2024-03-26 00:00:00', '2024-04-03 17:53:41'),
-- (380, 2, '04673746', 118.79, 0.00, 'T/BELT \r\nWATER PUMP', 'YD61KJZ', NULL, '2024-03-27 00:00:00', '2024-04-04 10:47:49'),
-- (381, 2, '04673696', 4.93, 0.00, 'OIL FILTER', 'MV12EOY', NULL, '2024-03-27 00:00:00', '2024-04-04 10:49:40'),
-- (382, 2, '04673381', 7.82, 0.00, 'AIR FILTER\r\nOIL FILTER', 'HJ61VWA', NULL, '2024-03-27 00:00:00', '2024-04-04 10:50:49'),
-- (383, 2, '04673349', 12.48, 0.00, 'AIR FILTER\r\nOIL FILTER', 'NX62WXB', NULL, '2024-03-27 00:00:00', '2024-04-04 10:51:50'),
-- (384, 6, 'IN808528', 12.30, 0.00, 'WHEEL BEARNING KIT', 'LM60EWL', NULL, '2024-03-28 00:00:00', '2024-04-04 10:52:56'),
-- (385, 2, '04674175', 3.52, 0.00, 'OIL FILTER', 'GH67VOH', NULL, '2024-03-28 00:00:00', '2024-04-04 10:53:59'),
-- (386, 1, 'IV260100', 23.00, 0.00, 'AIR FILTER\r\nPOLLEN FILTER\r\nOIL FILTER\r\nFUEL FILTER', 'FY06VTK', NULL, '2024-03-28 00:00:00', '2024-04-04 10:55:18'),
-- (387, 3, 'LEA2193557', 16.80, 0.00, 'PREASSURE PACK INSTANT GASKET SEALANT BLACK', 'MPMPP200B', NULL, '2024-03-27 00:00:00', '2024-04-04 10:57:37'),
-- (388, 1, 'IV260248', 17.00, 0.00, 'BGA TIE ROD X2', 'AN08LYJ', NULL, '2024-03-28 00:00:00', '2024-04-04 10:59:13'),
-- (389, 2, '04674689', 11.98, 0.00, 'AIR FILTER\r\nOIL FILTER', 'FD16OXS', NULL, '2024-03-29 00:00:00', '2024-04-04 11:01:08'),
-- (390, 3, 'LEA2194062', 14.45, 0.00, 'WASHER PUMP', 'HF66NUY', NULL, '2024-03-29 00:00:00', '2024-04-04 11:02:23'),
-- (391, 1, 'IV260379', 28.00, 0.00, 'APEC BRAKE PAD', 'WA70TXZ', NULL, '2024-03-29 00:00:00', '2024-04-04 11:03:37'),
-- (392, 2, 'IV260279', 45.00, 0.00, 'THERMOSTAT HOUSING', 'YD61KJZ', NULL, '2024-03-29 00:00:00', '2024-04-04 11:04:54'),
-- (393, 2, '04674967', 8.95, 0.00, 'CRANKSHAFT REAR SEAL HYUNDAI A', 'FP06HKF', NULL, '2024-03-30 00:00:00', '2024-04-04 11:06:13'),
-- (394, 2, '04674977', 43.90, 0.00, 'SUMPPAN ATOZ 98', 'FP06HKF', NULL, '2024-03-30 00:00:00', '2024-04-04 11:07:27'),
-- (395, 2, 'IV260421', 14.50, 0.00, 'DRIVE BELT', 'AUO4JVZ', NULL, '2024-03-30 00:00:00', '2024-04-04 11:08:50'),
-- (396, 2, 'IV260388', 28.54, 0.00, 'OIL FILTER\r\nAIR FILTER\r\nCABIN FILTER\r\nSPARK PLUG X3', 'NYO4GGZ', NULL, '2024-03-29 00:00:00', '2024-04-04 11:12:10'),
-- (397, 2, 'IV260412', 135.00, 0.00, 'WHEEL BEARING LIT', 'HF66NUY', NULL, '2024-03-30 00:00:00', '2024-04-04 11:13:27'),
-- (398, 2, 'IV260415', 53.50, 0.00, 'BREAK W/SENS\r\nBRAKEPADS', 'WA70TXZ', NULL, '2024-03-30 00:00:00', '2024-04-04 11:15:04'),
-- (399, 1, 'IV261831', 55.00, 0.00, 'SHOCK ABSORBER FRONT\r\nTOP STRUT MOUNT KIT', 'ML60ABV', NULL, '2024-04-09 00:00:00', '2024-04-11 13:17:00'),
-- (400, 2, '04679290', 50.89, 0.00, 'TIE ROD END RH\r\nFRONT BRAKE PADS\r\nFRONT DISC FORD', 'YD07JFF', NULL, '2024-04-09 00:00:00', '2024-04-11 13:19:59'),
-- (401, 1, 'IV261776', 39.00, 0.00, 'BGA TRACK CONTROL ARM', 'OV12HSU', NULL, '2024-04-08 00:00:00', '2024-04-11 13:21:03'),
-- (402, 1, 'IV261781', 3.00, 0.00, 'OIL FILTER', 'FJ12VMP', NULL, '2024-04-09 00:00:00', '2024-04-11 13:22:08'),
-- (403, 6, 'IN809746', 15.79, 0.00, 'STABILIZER LINK L/R', 'AJ04TGVV', NULL, '2024-04-08 00:00:00', '2024-04-11 13:24:47'),
-- (404, 6, 'IN809774', 99.38, 0.00, 'REPSET', 'AJ06SYO', NULL, '2024-04-09 00:00:00', '2024-04-11 13:25:54'),
-- (405, 6, 'IN809727', 54.31, 0.00, 'SUSPENSION ARM\r\nWHEEL BEARING KIT\r\nAIR FILTER\r\nOIL FILTER', 'AJ04GVV', NULL, '2024-04-08 00:00:00', '2024-04-11 13:27:37'),
-- (406, 6, 'IV261720', 112.50, 0.00, 'SPARK PLUG\r\nTIE ROD END RH\r\nTIE ROD END LH\r\nBRAKE PADS', 'LF11CVW', NULL, '2024-04-08 00:00:00', '2024-04-11 13:29:01'),
-- (407, 6, 'IN809705', 13.85, 0.00, 'WHEEL CYLINDER', 'YP55YTN', NULL, '2024-04-08 00:00:00', '2024-04-11 13:30:13'),
-- (408, 6, 'IN809631', 21.46, 0.00, 'CAR BRAKE PADS', 'NL15NPA', NULL, '2024-04-08 00:00:00', '2024-04-11 13:35:53'),
-- (409, 2, '04678573', 15.47, 0.00, 'AIR FILTER\r\nOIL FILTER', 'FX16XAU', NULL, '2024-04-08 00:00:00', '2024-04-11 13:37:15');
-- INSERT INTO `purchase_invoices` (`id`, `supplier_id`, `part_invoice_number`, `amount`, `quantity`, `details`, `car_registration_number`, `deleted_at`, `created_at`, `updated_at`) VALUES
-- (410, 1, 'IV261630', 49.00, 0.00, 'EXHAUST REAR BOX', 'BF58FLP', NULL, '2024-04-08 00:00:00', '2024-04-11 13:38:39'),
-- (411, 1, 'IV261621', 35.50, 0.00, 'INNER TIE ROD\r\nTIE ROD ASSEMBLY RH', 'AW19UMO', NULL, '2024-04-08 00:00:00', '2024-04-11 13:41:25'),
-- (412, 2, '04678511', 21.53, 0.00, 'GEARBOX MOUNTING REAR', 'RV59BZS', NULL, '2024-04-08 00:00:00', '2024-04-11 13:42:31'),
-- (413, 6, 'IN809592', 38.54, 0.00, 'BRAKE PADS X2', 'NL15NPA', NULL, '2024-04-08 00:00:00', '2024-04-11 13:43:50'),
-- (414, 6, 'IN809448', 70.97, 0.00, 'STABILIZER LINK\r\nWISHBONE L/R', 'GX14ZHE', NULL, '2024-04-06 00:00:00', '2024-04-11 13:45:23'),
-- (415, 2, '04677563', 6.84, 0.00, 'AIR FILTER\r\nOIL FILTER', 'FE08YCG', NULL, '2024-04-05 00:00:00', '2024-04-11 13:47:50'),
-- (416, 1, 'IV261293', 48.00, 0.00, 'SUSPENSION ARM L/R', 'N44RRU', NULL, '2024-04-05 00:00:00', '2024-04-11 13:49:03'),
-- (417, 2, '04677379', 24.00, 0.00, 'STABILIZER LINK FRONT L/R', 'BU63DXJ', NULL, '2024-04-05 00:00:00', '2024-04-11 13:50:23'),
-- (418, 6, 'IN809419', 67.03, 0.00, 'BRAKE PADS BRAKE DISC', 'BO52DXN', NULL, '2024-04-05 00:00:00', '2024-04-11 13:54:16'),
-- (419, 2, '04677739', 129.44, 0.00, 'REAR SHOES TOY AYGO\r\nREAR TOYOTA AYGO\r\nFRONT DISC CIT & PLUG', 'BD57VTU', NULL, '2024-04-05 00:00:00', '2024-04-11 13:56:12'),
-- (420, 1, 'IV261270', 48.00, 0.00, 'TRACK CONTROL ARM LH/RH', 'N44RRU', NULL, '2024-04-05 00:00:00', '2024-04-11 13:57:39'),
-- (421, 2, '04677475', 20.99, 0.00, 'FRONT BRAKE PADS', 'KM60XTK', NULL, '2024-04-05 00:00:00', '2024-04-11 13:59:11'),
-- (422, 6, 'IN809425', 11.88, 0.00, 'HALOGEN HE', NULL, NULL, '2024-04-05 00:00:00', '2024-04-11 14:00:09'),
-- (423, 2, '04676628', 17.86, 0.00, 'SIMONIZ MATT BLACK\r\nLUCAS OFFSET', NULL, NULL, '2024-04-03 00:00:00', '2024-04-11 14:02:08'),
-- (424, 2, '04676825', 9.96, 0.00, 'CROSLAND AIR FILETR\r\nMANN OIL FILTER', 'YB09PBX', NULL, '2024-04-04 00:00:00', '2024-04-11 14:03:32'),
-- (425, 2, '04676817', 517.03, 0.00, 'FLYWHEEL BOLT MONDEO & TRANSIT\r\nCLUTCH KIT\r\nDUAL MASS FLYWHEEL', 'WN66WOY', NULL, '2024-04-04 00:00:00', '2024-04-11 14:05:37'),
-- (426, 1, 'IV261147', 25.00, 0.00, 'HEAD GASKIT', 'VA14HTC', NULL, '2024-04-04 00:00:00', '2024-04-11 14:06:39'),
-- (427, 2, '04677189', 105.78, 0.00, 'T/BELT KIT VAUXHALL SAAB', 'FD14KWF', NULL, '2024-04-04 00:00:00', '2024-04-11 14:07:47'),
-- (428, 2, '04675625', 2.02, 0.00, 'SUMP PLUG CITROEN', 'NL13LVK', NULL, '2024-04-02 00:00:00', '2024-04-11 14:09:06'),
-- (429, 2, '04675539', 78.95, 0.00, 'REAR FORD MONDEO\r\nREAR PADS FORD', 'YS59WUV', NULL, '2024-04-02 00:00:00', '2024-04-11 14:12:29'),
-- (430, 2, '04675262', 40.96, 0.00, 'CENTRE PIPE TOYOTA AURIS', 'SE07UFW', NULL, '2024-04-01 00:00:00', '2024-04-11 14:15:34'),
-- (431, 1, 'IV260750', 9.50, 0.00, 'FAN BELT', 'DE07UKY', NULL, '2024-04-02 00:00:00', '2024-04-11 14:16:30'),
-- (432, 2, '04675826', 35.86, 0.00, 'FRONT PADS', 'VE54BOU', NULL, '2024-04-02 00:00:00', '2024-04-11 14:17:37'),
-- (433, 2, '04675714', 19.18, 0.00, 'BRAKE PIPE', NULL, NULL, '2024-04-02 00:00:00', '2024-04-11 14:19:58'),
-- (434, 2, '04676491', 20.76, 0.00, 'IGNITION COIL POLO FOX AWY BMD', 'DA55UVH', NULL, '2024-04-03 00:00:00', '2024-04-11 14:21:33'),
-- (435, 2, '04676367', 16.36, 0.00, 'AIR FILTER\r\nOIL FILETR', 'KH05ALD', NULL, '2024-04-03 00:00:00', '2024-04-11 14:23:04'),
-- (436, 2, '04676216', 69.13, 0.00, '12V 2.1KW 19 TEETH 2*HOLES 0*T', 'SC03OHX', NULL, '2024-04-03 00:00:00', '2024-04-11 14:24:45'),
-- (437, 2, '04676213', 8.30, 0.00, 'AIR FILTER', 'ML60ABV', NULL, '2024-04-03 00:00:00', '2024-04-11 14:26:01'),
-- (438, 2, 'IN809040', 17.17, 0.00, 'BRAKE FLUID', NULL, NULL, '2024-04-03 00:00:00', '2024-04-11 14:27:05'),
-- (439, 2, '04699386', 42.05, 0.00, 'V/BELT DEFLECTION PULLEY MERCE X2', 'DF67DZJ', NULL, '2024-05-18 00:00:00', '2024-05-23 11:56:06'),
-- (440, 2, '04699364', 48.62, 0.00, 'BELT PULEY SPRINTER\r\nDRIVE BELT', 'DF67DZJ', NULL, '2024-05-18 00:00:00', '2024-05-23 11:57:35'),
-- (441, 1, 'IV267816', 20.50, 0.00, 'OIL FILTER\r\nFAHREN AIR FILTER', 'HG05LEY', NULL, '2024-05-18 00:00:00', '2024-05-23 11:59:11'),
-- (442, 6, 'IN814751', 105.04, 0.00, 'BRAKE DISC\r\nBRAKE PADS X2', 'FL66ZGZ', NULL, '2024-05-18 00:00:00', '2024-05-23 12:01:16'),
-- (443, 8, '7101084349', 5.94, 0.00, 'OIL FILTER', 'DA15ROU', NULL, '2024-05-15 00:00:00', '2024-05-23 12:02:31'),
-- (444, 2, '04696926', 14.41, 0.00, 'MANN ALI FILTER\r\nMANN OIL FILTER', 'FV09SXC', NULL, '2024-05-14 00:00:00', '2024-05-23 12:04:02'),
-- (445, 6, 'IN814110', 19.67, 0.00, 'FUEL FILTER', 'CX54YPP', NULL, '2024-05-14 00:00:00', '2024-05-23 12:05:29'),
-- (446, 1, 'IV265548', 8.00, 0.00, 'BGA STABILIZSER LINK', 'CV12WGO', NULL, '2024-05-03 00:00:00', '2024-05-31 13:41:45'),
-- (447, 2, '04692554', 55.56, 0.00, 'FRONT PADS\r\nFRONT DISCS', 'YB09PBX', NULL, '2024-05-06 00:00:00', '2024-05-31 13:43:01'),
-- (448, 2, '04692612', 89.72, 0.00, 'REAR RH CLIPPER\r\nSURCHARGE INC', 'WL61FTD', NULL, '2024-05-06 00:00:00', '2024-05-31 13:44:39'),
-- (449, 2, '04692608', 65.65, 0.00, 'FRONT CONTROL ARM', 'S2TOF', NULL, '2024-05-06 00:00:00', '2024-05-31 13:45:47'),
-- (450, 2, '04692590', 19.13, 0.00, 'FRONT BRAKE PADS', 'KR07KTA', NULL, '2024-05-06 00:00:00', '2024-05-31 13:46:59'),
-- (451, 2, '04692693', 12.64, 0.00, 'DRIVE BELT', 'KY61KGX', NULL, '2024-05-06 00:00:00', '2024-05-31 13:47:54'),
-- (452, 2, '04692697', 10.09, 0.00, 'AIR FILTER\r\nOIL FILTER', 'KY61KGX', NULL, '2024-05-06 00:00:00', '2024-05-31 13:48:58'),
-- (453, 2, '04692742', 10.80, 0.00, 'CRANKSHAFT OIL SEAL', 'NV13OGO', NULL, '2024-05-06 00:00:00', '2024-05-31 13:50:22'),
-- (454, 2, '04692745', 11.41, 0.00, 'FUEL FILTER', 'KY61KGX', NULL, '2024-05-06 00:00:00', '2024-05-31 13:51:28'),
-- (455, 2, '04692996', 4.87, 0.00, 'POLLEN FILTER', 'SA12ZPU', NULL, '2024-05-07 00:00:00', '2024-05-31 13:52:24'),
-- (456, 3, 'LEA2201909', 75.07, 0.00, 'CAMBER TRACK CONTROL ARM', 'SJ61SSV', NULL, '2024-05-07 00:00:00', '2024-05-31 13:54:12'),
-- (457, 8, '7101083345', 4.08, 0.00, 'CRANKSHAFT SEAL', 'NV13OGO', NULL, '2024-05-07 00:00:00', '2024-05-31 13:55:43'),
-- (458, 2, '04693284', 20.58, 0.00, 'DRIVE BELT', 'X309WCA', NULL, '2024-05-07 00:00:00', '2024-05-31 13:56:57'),
-- (459, 2, '04693315', 13.99, 0.00, 'MULTI-RIB ELASTI BELT', 'LL62YCA', NULL, '2024-05-07 00:00:00', '2024-05-31 13:58:20'),
-- (460, 8, '7101083484', 75.00, 0.00, 'DRIVESHAFT-LH', NULL, NULL, '2024-05-08 00:00:00', '2024-05-31 14:00:15'),
-- (461, 2, '04694098', 5.87, 0.00, 'FRONT STABILISER LINK', 'BJ08JZC', NULL, '2024-05-08 00:00:00', '2024-05-31 14:02:23'),
-- (462, 1, 'IV266609', 38.00, 0.00, 'RR ENGINE MOUNT', 'FJ65JBZ', NULL, '2024-05-10 00:00:00', '2024-05-31 14:03:37'),
-- (463, 3, 'LEA2202918', 29.81, 0.00, 'LINK STABILIZER', 'FJ65JBZ', NULL, '2024-05-10 00:00:00', '2024-05-31 14:07:41'),
-- (464, 2, '04694639', 53.36, 0.00, '3PC CLUTCH KIT', 'WJ60JBE', NULL, '2024-05-09 00:00:00', '2024-05-31 14:11:07'),
-- (465, 1, 'IV266330', 20.50, 0.00, 'BRAKE PADS', 'DU58PNF', NULL, '2024-05-09 00:00:00', '2024-05-31 14:13:21'),
-- (466, 1, 'IV266369', 57.00, 0.00, 'FR LH BRAKE CLIPER', 'DU58PNF', NULL, '2024-05-09 00:00:00', '2024-05-31 14:26:16'),
-- (467, 2, '04694260', 55.85, 0.00, 'FRONT LANDROVER DISCOVERY', 'DU58PNF', NULL, '2024-05-09 00:00:00', '2024-05-31 14:32:02'),
-- (468, 2, '04694480', 25.86, 0.00, 'PAD KIT- FRONT MERCEDES/AUDI', 'YT62BFX', NULL, '2024-05-09 00:00:00', '2024-05-31 14:33:17'),
-- (469, 1, 'IV266482', 63.00, 0.00, 'TOP MOUNT', 'FJ65JBZ', NULL, '2024-05-10 00:00:00', '2024-05-31 14:34:41'),
-- (470, 1, 'FJ65JBZ', 8.50, 0.00, 'OIL FILTER', 'FJ65JBZ', NULL, '2024-05-10 00:00:00', '2024-05-31 14:35:50'),
-- (471, 2, '04696422', 12.61, 0.00, 'OIL PREASURE SWITCH', 'AK56OLT', NULL, '2024-05-13 00:00:00', '2024-05-31 14:37:04'),
-- (472, 2, '04696087', 14.23, 0.00, 'CROSLAND AIR FILTER\r\nOIL FILTER', 'SC10RCU', NULL, '2024-05-13 00:00:00', '2024-05-31 14:38:39'),
-- (473, 2, '04696128', 7.26, 0.00, 'OIL FILTER', 'KN09HSJ', NULL, '2024-05-13 00:00:00', '2024-05-31 14:39:49'),
-- (474, 2, '04695457', 288.00, 0.00, '3PC SAC CLUTCH KIT\r\nDUAL MASS FLYWHEEL', 'SO14MUU', NULL, '2024-05-11 00:00:00', '2024-05-31 14:41:43'),
-- (475, 2, '04699000', 23.52, 0.00, 'FRONT STABLIZER LINK LH/RH', 'NG12UYB', NULL, '2024-05-17 00:00:00', '2024-05-31 14:43:10'),
-- (476, 6, 'IN814681', 42.73, 0.00, 'BRAKE DISC\r\nBRAKE PADS', 'PF53UPX', NULL, '2024-05-17 00:00:00', '2024-05-31 14:44:21'),
-- (477, 8, '7101084392', 34.02, 0.00, 'IDLER PULLEY', 'P848WRU', NULL, '2024-05-16 00:00:00', '2024-05-31 14:45:58'),
-- (478, 6, 'IN814464', 70.13, 0.00, 'NAPA SHOCK ABS GAS FRONT\r\nCAPTUR HATCHBACK', 'NV13OGO', NULL, '2024-05-16 00:00:00', '2024-05-31 14:47:38'),
-- (479, 2, '04698182', 7.20, 0.00, 'FRONT STABILISER LINK LH/RH CL', 'NV13OGO', NULL, '2024-05-16 00:00:00', '2024-05-31 14:49:00'),
-- (480, 2, '04698467', 85.43, 0.00, 'STARLINE EFB BATTERY', 'DY10AZA', NULL, '2024-05-16 00:00:00', '2024-05-31 14:51:27'),
-- (481, 2, '04698557', 10.49, 0.00, 'TIE ROD END LH', 'WU60XRB', NULL, '2024-05-17 00:00:00', '2024-05-31 14:54:09'),
-- (482, 1, 'IV267564', 109.00, 0.00, 'BRAKE PAD X2\r\nBRAKE DISC\r\nBRAKE CALIPPER', 'KP08BHF', NULL, '2024-05-17 00:00:00', '2024-05-31 14:55:21'),
-- (483, 2, '04697881', 131.38, 0.00, 'CROSS DO ALTERNATOR', 'P848WRU', NULL, '2024-05-16 00:00:00', '2024-05-31 14:56:26'),
-- (484, 1, 'IV267578', 56.00, 0.00, 'BRAKE CALLIPER', 'KP08BHF', NULL, '2024-05-17 00:00:00', '2024-05-31 14:57:35'),
-- (485, 2, '04698782', 9.86, 0.00, 'AIR FILTER\r\nOIL FILTER', 'NG12UYB', NULL, '2024-05-17 00:00:00', '2024-05-31 14:59:13'),
-- (486, 2, '04706873', 342.00, 0.00, '4PC SAC MODULE KIT + BOLT VAG', 'RV09XBD', NULL, '2024-06-03 00:00:00', '2024-06-05 10:10:01'),
-- (487, 1, 'IV269757', 22.50, 0.00, 'OIL FILTER\r\nAIR FILTER\r\nCABIN FILTER\r\nSPARK PLUG', 'NV08VVM', NULL, '2024-06-01 00:00:00', '2024-06-05 10:14:55'),
-- (488, 1, 'IV269891', 99.00, 0.00, 'TIMING CHAIN KIT\r\nBGA WATER PUMP', 'X24KCX', NULL, '2024-06-03 00:00:00', '2024-06-05 10:17:47'),
-- (489, 1, 'IV269897', 4.00, 0.00, 'OIL FILTER', 'VK04DDJ', NULL, '2024-06-03 00:00:00', '2024-06-05 10:18:46'),
-- (490, 1, 'IV269892', 14.25, 0.00, 'AIR FILTER\r\nCABIN FILTER\r\nOIL FILTER', 'YF09BYD', NULL, '2024-06-03 00:00:00', '2024-06-05 10:20:04'),
-- (491, 1, 'IV269421', 10.00, 0.00, 'RACK END', 'KX60BPZ', NULL, '2024-05-30 00:00:00', '2024-06-05 10:21:31'),
-- (492, 1, 'IV269486', 57.00, 0.00, 'EXHAUST PIPE WITH TAIL PIPE', 'KP05XBX', NULL, '2024-05-30 00:00:00', '2024-06-05 10:22:51'),
-- (493, 1, 'IV269587', 8.00, 0.00, 'STABILISER LINK', 'FN08KFV', NULL, '2024-05-31 00:00:00', '2024-06-05 10:24:18'),
-- (494, 1, 'IV269586', 43.00, 0.00, 'OIL FILTER\r\nAIR FILTER\r\nPOLLEN FILTER\r\nAPEC BRAKE PAD', 'LD16EJL', NULL, '2024-05-31 00:00:00', '2024-06-05 10:25:51'),
-- (495, 1, 'IV269516', 116.00, 0.00, 'CLUTCH KIT + CSC', 'BG59UZD', NULL, '2024-05-31 00:00:00', '2024-06-05 10:27:50'),
-- (496, 1, 'IV270159', 43.00, 0.00, 'BRAKE PAD\r\nBRAKE PAD', 'FL59HJF', NULL, '2024-06-04 00:00:00', '2024-06-05 10:28:59'),
-- (497, 1, 'IV270137', 71.00, 0.00, 'GBGA CV JOINT KIT\r\nBGA STABILISER LINK\r\nRR MOUNT', 'GF14SZP', NULL, '2024-06-04 00:00:00', '2024-06-05 10:30:38'),
-- (498, 1, 'IV272246', 12.50, 0.00, 'DRIVE BELT', 'YE63PXA', NULL, '2024-06-18 00:00:00', '2024-06-18 14:52:46'),
-- (499, 1, 'IV272250', 23.00, 0.00, 'BRAKE PADS', 'YT07NHE', NULL, '2024-06-18 00:00:00', '2024-06-18 14:53:39'),
-- (500, 1, 'IV272251', 28.00, 0.00, 'BGA TRACK CONTROL ARM', 'SL59WNR', NULL, '2024-06-18 00:00:00', '2024-06-18 14:54:39'),
-- (501, 1, 'IV272292', 10.00, 0.00, 'BRAKE WEAR SENSOR', 'YT07NHE', NULL, '2024-06-18 00:00:00', '2024-06-18 14:55:34'),
-- (502, 1, 'IV268342', 7.00, 0.00, 'DRIVE BELT', 'WN66WOY', NULL, '2024-05-22 00:00:00', '2024-06-18 15:00:39'),
-- (503, 2, '04714786', 157.78, 0.00, 'ENGINE MOUNT\r\nDRIVE BELT\r\nCROSS DO ENGINE MOUNT', 'YE63PXA', NULL, '2024-06-18 00:00:00', '2024-06-18 15:02:03'),
-- (504, 2, '04714818', 58.80, 0.00, 'SUSPENSION ARM LH-RH', 'VO62NDC', NULL, '2024-06-18 00:00:00', '2024-06-18 15:05:22'),
-- (505, 1, 'IV272734', 110.00, 0.00, 'ALTERNATOR', 'NL62ZHN', NULL, '2024-06-21 00:00:00', '2024-06-21 15:00:57'),
-- (506, 2, '04715630', 21.23, 0.00, 'DRIVE BELT', 'NL62ZHN', NULL, '2024-06-19 00:00:00', '2024-06-21 15:02:09'),
-- (507, 1, 'IV272507', 28.00, 0.00, 'DRIVE BELT', 'NL62ZHN', NULL, '2024-06-19 00:00:00', '2024-06-21 15:03:38'),
-- (508, 1, 'IV272568', 18.00, 0.00, 'COIOL SPRING', 'DU58ZTR', NULL, '2024-06-20 00:00:00', '2024-06-21 15:04:37'),
-- (509, 1, 'IV272695', 28.00, 0.00, 'AIR FILTER\r\nOIL FILTER\r\nMANNOL FULLY SYN 5W30', 'NJ55TZR', NULL, '2024-06-20 00:00:00', '2024-06-21 15:06:26'),
-- (510, 1, 'IV271814', 97.50, 0.00, 'BRAKE DISC\r\nBRAKE PADS\r\nBRAKE SHOES', 'FY06VTU', NULL, '2024-06-14 00:00:00', '2024-06-25 08:26:30'),
-- (511, 1, 'IV272891', 32.50, 0.00, 'WHEEL BEARING KIT X2', 'FN05XUS', NULL, '2024-06-21 00:00:00', '2024-06-25 08:27:58'),
-- (512, 2, '04717479', 48.61, 0.00, 'FRONT BRAKE PADS\r\nSHOCK ABSOB FRONT', 'X309WCA', NULL, '2024-06-24 00:00:00', '2024-06-25 08:30:44'),
-- (513, 16, 'LS126225', 40.00, 0.00, 'ENGINE MOUNT', 'FN05XUS', NULL, '2024-06-21 00:00:00', '2024-06-25 08:38:18'),
-- (514, 16, 'LS126279', 60.00, 0.00, 'SUMP PAN KIT', 'PK08WLA', NULL, '2024-06-24 00:00:00', '2024-06-25 08:39:56'),
-- (515, 16, 'LS126282', 45.00, 0.00, 'SHOCK ABS GAS FRONT', 'X309WCA', NULL, '2024-06-24 00:00:00', '2024-06-25 08:41:38'),
-- (516, 16, 'LS125589', 155.00, 0.00, 'THERMOSTAT', 'BL18MHJ', NULL, '2024-06-03 00:00:00', '2024-06-25 08:43:17'),
-- (517, 16, 'LS125643', 27.00, 0.00, 'AIR FILTER\r\nOIL FILTER\r\nCABIN FILTER', 'BK58GAO', NULL, '2024-06-04 00:00:00', '2024-06-25 08:44:28'),
-- (518, 16, 'LS125599', 69.00, 0.00, 'WATER PUMP\r\nDRIVE BELT\r\nOIL SEAL', 'X24KCX', NULL, '2024-06-03 00:00:00', '2024-06-25 08:46:11'),
-- (519, 2, '04757778', 72.00, 0.00, 'T/CHAIN KIT TOYOTA YARIS 1.3 V', 'WF06UER', NULL, '2024-09-10 00:00:00', '2024-10-29 11:41:06'),
-- (520, 1, 'IV285161', 48.00, 0.00, 'EXHAUST BACK BOX', 'J7YXV', NULL, '2024-09-10 00:00:00', '2024-10-29 11:42:22'),
-- (521, 6, 'IN829761', 50.77, 0.00, 'SPARK PLUG 4X\r\nOIL FILTER\r\nCABIN FILTER\r\nAIR FILTER', 'ST59XJV', NULL, '2024-09-10 00:00:00', '2024-10-29 11:43:55'),
-- (522, 2, '04758304', 19.92, 0.00, 'TOP STRUT MOUNT BEARING FORD G', 'SY110JW', NULL, '2024-09-11 00:00:00', '2024-10-29 11:45:35'),
-- (523, 6, 'IN829916', 27.23, 0.00, 'COIL SPRING FRONT', 'SY110JW', NULL, '2024-09-11 00:00:00', '2024-10-29 11:46:54'),
-- (524, 1, 'IV285215', 4.00, 0.00, 'POLLEN FILTER', 'CU59MXP', NULL, '2024-09-10 00:00:00', '2024-10-29 11:48:11'),
-- (525, 6, 'IN830208', 82.61, 0.00, 'BRAKE DISC 2X\r\nBRAKE PADS', 'LS13TYW', NULL, '2024-09-12 00:00:00', '2024-10-29 11:50:09'),
-- (526, 1, 'IV285583', 20.50, 0.00, 'DRIVE BELT\r\nAUXILIARY BELT', 'BG11XYY', NULL, '2024-09-12 00:00:00', '2024-10-29 11:51:25'),
-- (527, 6, 'IN830158', 18.52, 0.00, 'OIL FILTER\r\nAIR FILTER\r\nCABIN FILTER\r\nSPARK PLUG', 'WU57YND', NULL, '2024-09-12 00:00:00', '2024-10-29 11:53:28'),
-- (528, 2, '04759452', 8.54, 0.00, 'STARLINE WIPER BLADE\r\nSTARLINE WIPER BLADE X4', NULL, NULL, '2024-09-13 00:00:00', '2024-10-29 11:55:40'),
-- (529, 2, '04759780', 87.54, 0.00, 'CROSS STARTER PEUGEOT 1.1KW\r\nSURCHARGE EXTRA', 'Y972WOA', NULL, '2024-09-13 00:00:00', '2024-10-29 11:57:52'),
-- (530, 2, '04759764', 60.38, 0.00, 'CLUTCH MASTER CYLINDER TRANSIT', 'HF66NUY', NULL, '2024-09-13 00:00:00', '2024-10-29 12:12:54'),
-- (531, 1, 'IV293303', 4.00, 0.00, 'OIL FILTER', 'ND09RXN', NULL, '2024-10-29 00:00:00', '2024-10-30 11:57:46'),
-- (532, 2, '04783789', 2.09, 0.00, 'LITH CELL BATTERY', NULL, NULL, '2024-10-29 00:00:00', '2024-10-30 11:58:48'),
-- (533, 2, '04783820', 51.60, 0.00, 'F BRAKE PADS AURIS\r\nF BRAKE DISC AURIS', 'DY64SNU', NULL, '2024-10-29 00:00:00', '2024-10-30 12:00:56'),
-- (534, 1, 'IV292970', 14.00, 0.00, 'OIL FILTER\r\nSPARK PLUG', 'NA11NNJ', NULL, '2024-10-28 00:00:00', '2024-10-30 12:01:51'),
-- (535, 1, 'IV292314', 21.00, 0.00, 'APEC WHEEL BEARING KIT', 'SK09UYH', NULL, '2024-10-23 00:00:00', '2024-10-30 12:02:51'),
-- (536, 1, 'IV292968', 45.00, 0.00, 'BRAKE PADS X2\r\nFAN BELT\r\nDRIVE BELT', 'NA11NNJ', NULL, '2024-10-28 00:00:00', '2024-10-30 12:04:22'),
-- (537, 1, 'IV292900', 50.50, 0.00, 'BRAKE PADS X2\r\nBRAKE SENSOR', 'NU66GNX', NULL, '2024-10-26 00:00:00', '2024-10-30 12:05:52'),
-- (538, 2, '04782658', 16.49, 0.00, 'AIR FILTER\r\nOIL FILTER', 'F106SPZ', NULL, '2024-10-26 00:00:00', '2024-10-30 12:07:02'),
-- (539, 2, '04782461', 8.34, 0.00, 'OIL FILTER', 'LV09XAZ', NULL, '2024-10-25 00:00:00', '2024-10-30 12:08:01'),
-- (540, 2, '04782360', 9.00, 0.00, 'AIR FILTER', 'BF16YFM', NULL, '2024-10-25 00:00:00', '2024-10-30 12:09:13'),
-- (541, 1, 'IV292698', 89.00, 0.00, 'EX FRONT FLEX PIPE\r\nEX REAR SENSOR', 'DN09KXH', NULL, '2024-10-25 00:00:00', '2024-10-30 12:10:20'),
-- (542, 3, 'LEA2239580', 82.96, 0.00, 'BRAKE CALIPER\r\nOIL UNIT CHARGE', 'MK58YCG', NULL, '2024-10-25 00:00:00', '2024-10-30 12:11:53'),
-- (543, 2, '04782054', 5.38, 0.00, 'OIL FILTER', 'FG60NZM', NULL, '2024-10-25 00:00:00', '2024-10-30 12:12:47'),
-- (544, 2, '04783519', 96.00, 0.00, '3 PC CLUTCH KIT', 'CY65KOJ', NULL, '2024-10-28 00:00:00', '2024-10-30 12:14:34'),
-- (545, 2, '04783500', 240.00, 0.00, 'DUAL MASS FLY WHEEL', 'CY65KOJ', NULL, '2024-10-28 00:00:00', '2024-10-30 12:15:30'),
-- (546, 2, '04762769', 10.01, 0.00, 'OIL FILTER\r\nBOSCH OIL FILTER', 'M870PCX', NULL, '2024-09-19 00:00:00', '2024-10-30 12:16:40'),
-- (547, 2, '04781729', 8.99, 0.00, 'AIR FILTER', 'GF16YFM', NULL, '2024-10-24 00:00:00', '2024-10-30 12:17:33'),
-- (548, 1, 'IV292552', 70.00, 0.00, 'BRAKE CALIPER FR NS\r\nBRAKE CALIPER FR OS', 'GP55UOO', NULL, '2024-10-24 00:00:00', '2024-10-30 12:19:00'),
-- (549, 2, '04781675', 92.50, 0.00, 'CRANKSHAFT PULLEY KIT', 'K17LUN', NULL, '2024-10-24 00:00:00', '2024-10-30 12:20:15'),
-- (550, 2, '04781617', 29.92, 0.00, 'BOX OF 100 ASSTD BRAKE U', NULL, NULL, '2024-10-24 00:00:00', '2024-10-30 12:21:50'),
-- (551, 2, '04781615', 19.80, 0.00, 'AIR FILTER\r\nOIL FILTER', 'DK57VLL', NULL, '2024-10-24 00:00:00', '2024-10-30 12:22:52'),
-- (552, 2, '04781567', 14.40, 0.00, 'AIR FILTER\r\nOIL FILTER', 'BG14ZXX', NULL, '2024-10-24 00:00:00', '2024-10-30 12:23:49'),
-- (553, 2, '04781568', 11.82, 0.00, 'AIR FILTER\r\nOIL FILTER', 'SM56DXV', NULL, '2024-10-24 00:00:00', '2024-10-30 12:25:05'),
-- (554, 2, '04781490', 54.00, 0.00, 'REAR BRAKE PADS\r\nREAR DISC ASTRA', 'BG14ZXX', NULL, '2024-10-24 00:00:00', '2024-10-30 12:26:13'),
-- (555, 2, '04781462', 24.96, 0.00, 'DRIVE BELT TENSIONER', 'DK57VLL', NULL, '2024-10-24 00:00:00', '2024-10-30 12:27:14'),
-- (556, 2, '04781431', 16.80, 0.00, 'DRIVE BELT', 'GK550WU', NULL, '2024-10-24 00:00:00', '2024-10-30 12:28:36'),
-- (557, 2, '04781430', 50.40, 0.00, 'FRONT BRAKE PAD SET\r\nBRAKE DISC', 'GP55UOO', NULL, '2024-10-24 00:00:00', '2024-10-30 12:29:50'),
-- (558, 2, '04781389', 42.00, 0.00, 'REAR BRAKE PADS\r\nREAR DISC', 'SH09BJO', NULL, '2024-10-24 00:00:00', '2024-10-30 12:31:01'),
-- (559, 2, '04781409', 20.00, 0.00, 'DRIVE BELT AUDI', 'DK57VLL', NULL, '2024-10-24 00:00:00', '2024-10-30 12:32:31'),
-- (560, 2, '04781111', 20.64, 0.00, 'AIR FILTER\r\nOIL FILTER', 'RJ62MSU', NULL, '2024-10-23 00:00:00', '2024-10-30 12:33:37'),
-- (561, 1, 'IV292380', 9.50, 0.00, 'OIL FILTER\r\nAIR FILTER', 'DN09KXH', NULL, '2024-10-23 00:00:00', '2024-10-30 12:34:33'),
-- (562, 2, '04780964', 4.09, 0.00, 'ALARM BATTERY', NULL, NULL, '2024-10-23 00:00:00', '2024-10-30 12:35:39'),
-- (563, 1, 'IV292283', 19.50, 0.00, 'APEC BLU BRAKE PADS', 'FB57YFC', NULL, '2024-10-23 00:00:00', '2024-10-30 12:36:45'),
-- (564, 3, 'LEA2238941', 53.52, 0.00, 'GLOW PLUG', 'DO19AKG', NULL, '2024-10-23 00:00:00', '2024-10-30 12:39:04'),
-- (565, 1, 'IV292045', 39.00, 0.00, 'BRAKE DISC\r\nBRAKE PADS', 'SH09BJO', NULL, '2024-10-22 00:00:00', '2024-10-30 12:40:05'),
-- (566, 14, '34532', 366.00, 0.00, 'SUPPLY MERC ML REAR', 'MER ML', NULL, '2024-10-21 00:00:00', '2024-10-30 12:42:14'),
-- (567, 1, 'IV292133', 25.50, 0.00, 'COIL SPRING\r\nSTAB LINK', 'HN65ACU', NULL, '2024-10-22 00:00:00', '2024-10-30 12:43:20'),
-- (568, 2, '04780337', 18.00, 0.00, 'CROSS DO DRIVESHAFT OIL SEAL', 'SH09BJO', NULL, '2024-10-22 00:00:00', '2024-10-30 12:44:35'),
-- (569, 1, 'IV292179', 14.00, 0.00, 'TOP STRUT MOUNT KIT', 'HN65ACU', NULL, '2024-10-22 00:00:00', '2024-10-30 12:45:56'),
-- (570, 1, 'IV291723', 10.00, 0.00, 'APEC STABILIZER LINK', 'LE08KFL', NULL, '2024-10-19 00:00:00', '2024-10-30 12:47:15'),
-- (571, 2, '04779486', 19.54, 0.00, '1L MPM ATF MB7', 'WJ57MUU', NULL, '2024-10-21 00:00:00', '2024-10-30 12:48:20'),
-- (572, 2, '04778888', 89.12, 0.00, 'REAR BRAKE PADS\r\nREAR BRAKE DISC', 'D019AKG', NULL, '2024-10-18 00:00:00', '2024-10-30 12:49:51'),
-- (573, 1, 'IV291515', 7.50, 0.00, 'FAHREN AIR FILTER', 'CP53YAM', NULL, '2024-10-18 00:00:00', '2024-10-30 12:51:16'),
-- (574, 2, '04778505', 54.00, 0.00, 'CLUTCH MASTER CYLINDER VAG VAR', '1J1721388C', NULL, '2024-10-18 00:00:00', '2024-10-30 12:53:40'),
-- (575, 2, '04778488', 7.80, 0.00, 'OIL FILTER PAPER ELEM', 'CP53YAM', NULL, '2024-10-18 00:00:00', '2024-10-30 12:56:26'),
-- (576, 2, '04778366', 59.89, 0.00, 'BOSCH OIL FILTER\r\nDO CLUTCH MASTER A3\r\nDO CLUTCH MASTER CYLINDER', NULL, NULL, '2024-10-18 00:00:00', '2024-10-30 13:03:11'),
-- (577, 1, 'IV291240', 11.00, 0.00, 'GBA STAB LINK', 'DA63NVP', NULL, '2024-10-17 00:00:00', '2024-10-30 13:05:42'),
-- (578, 2, '0478088', 50.94, 0.00, 'CROSS DO BOTTOM GUARD BLACK UNDERBODY PR', 'NA', NULL, '2024-10-17 00:00:00', '2024-10-30 13:25:39'),
-- (579, 2, '04778009', 64.20, 0.00, 'FRONT PADS VW GOLF\r\nFRONT DISC VW GOLF MK', 'DA63NVP', NULL, '2024-10-17 00:00:00', '2024-10-30 13:27:09'),
-- (580, 8, '7101100598', 99.96, 0.00, 'ANTIROLL BAR LINK\r\nSHOCK ABSORBER', 'DA63NVP', NULL, '2024-10-17 00:00:00', '2024-10-30 13:35:18'),
-- (581, 2, '04776995', 8.00, 0.00, 'CROSS DO COOLANT TEMPREATURE SENSOR - M', 'OY61LMX', NULL, '2024-10-16 00:00:00', '2024-10-30 13:36:31'),
-- (582, 2, '04777002', 12.14, 0.00, 'CROSS DO TEMP SWITCH 202 210 140', 'OY61LMX', NULL, '2024-10-16 00:00:00', '2024-10-30 13:37:47'),
-- (583, 1, 'IV291100', 26.50, 0.00, 'BRAKE PADS\r\nBRAKE SENSOR', 'WDB9067131S2270', NULL, '2024-10-16 00:00:00', '2024-10-30 13:39:32'),
-- (584, 1, 'IV291089', 26.50, 0.00, 'OIL FILTER\r\nAIR FILTER\r\nCABIN FILTER', 'W4LJJ', NULL, '2024-10-16 00:00:00', '2024-10-30 13:40:44'),
-- (585, 1, 'IV291120', 111.00, 0.00, 'BRAKE DISC\r\nBRAKE CALIPER SPRINTE', 'WDB906131S2270', NULL, '2024-10-16 00:00:00', '2024-10-30 13:42:06'),
-- (586, 2, '04777323', 40.00, 0.00, 'THERMOSTAT & HSG VARIOUS MERCE', 'OY61LMX', NULL, '2024-10-16 00:00:00', '2024-10-30 13:43:18'),
-- (587, 2, '04777446', 18.00, 0.00, 'FRONT PADS TOYOTA YARIS', 'SD56TSX', NULL, '2024-10-16 00:00:00', '2024-11-13 12:20:06'),
-- (588, 1, 'IV291176', 44.50, 0.00, 'BRAKE DISC X2\r\nBGA STAB LINK', 'SD56TSX', NULL, '2024-10-16 00:00:00', '2024-11-13 12:21:30'),
-- (589, 2, '04776469', 24.49, 0.00, 'SPARK PLUG\r\nAIR FILTER\r\nOIL FILTER', 'FE59EVJ', NULL, '2024-10-15 00:00:00', '2024-11-13 12:22:57'),
-- (590, 2, '04776388', 28.74, 0.00, 'EXPANSION TANK', 'KP08BHF', NULL, '2024-10-15 00:00:00', '2024-11-13 12:24:18'),
-- (591, 1, 'IV290763', 30.00, 0.00, 'SPARK PLUG', 'FJ61UEN', NULL, '2024-10-14 00:00:00', '2024-11-13 12:25:37'),
-- (592, 2, '04775759', 9.77, 0.00, 'OIL DIPSTICK\r\nOIL FILTER', 'AJ54HHM', NULL, '2024-10-14 00:00:00', '2024-11-13 12:26:45'),
-- (593, 1, 'IV290603', 10.00, 0.00, 'OIL FILTER\r\nAIR FILTER', 'WN11EPE', NULL, '2024-10-12 00:00:00', '2024-11-13 12:28:07'),
-- (594, 2, '04775134', 25.20, 0.00, 'DENSO HYBRIS BLADE 16 INCH\r\n26 INCH', 'GM15VCM', NULL, '2024-10-12 00:00:00', '2024-11-13 12:30:04'),
-- (595, 2, '04775133', 9.61, 0.00, 'FRONT STABILISER LINK LH/RH', 'PN58SWZ', NULL, '2024-10-12 00:00:00', '2024-11-13 12:31:46'),
-- (596, 1, 'IV290492', 6.50, 0.00, 'TIMING BELT', 'LV66VKM', NULL, '2024-10-12 00:00:00', '2024-11-13 12:32:58'),
-- (597, 1, 'IV290450', 76.50, 0.00, 'BRAKE PADS\r\nBRAKE DISC', 'FD66NBG', NULL, '2024-10-11 00:00:00', '2024-11-13 12:34:18'),
-- (598, 1, 'IV290535', 11.75, 0.00, 'AIR FILTER\r\nOIL FILTER', 'EF13UWM', NULL, '2024-10-12 00:00:00', '2024-11-13 12:35:48'),
-- (599, 1, 'IV290551', 29.50, 0.00, 'OIL FILTER\r\nAIR FILTER\r\nSPARK PLUG', 'MF08UZT', NULL, '2024-10-12 00:00:00', '2024-11-13 12:37:01'),
-- (600, 1, 'IV290471', 87.50, 0.00, 'BRAKE PAD\r\nBRAKE DISC\r\nARM BUSH RHD\r\nARM BUSH LHS', 'AY56JPF', NULL, '2024-10-11 00:00:00', '2024-11-13 12:39:18'),
-- (601, 1, 'IV290470', 76.00, 0.00, 'WATER PUMP', 'LV66VKM', NULL, '2024-10-11 00:00:00', '2024-11-13 12:40:23'),
-- (602, 15, '72IN021972', 17.40, 0.00, 'TIE ROD END', 'FD66NBG', NULL, '2024-10-11 00:00:00', '2024-11-13 12:41:41'),
-- (603, 1, 'IV290309', 9.00, 0.00, 'DRIVE BELT', 'EA07GLV', NULL, '2024-10-11 00:00:00', '2024-11-13 12:43:14'),
-- (604, 1, 'IV290373', 31.50, 0.00, 'OIL FILTER\r\nAIR FILTER\r\nFILTER\r\nFUEL FILTER', 'KT07XSK', NULL, '2024-10-11 00:00:00', '2024-11-13 12:44:47'),
-- (605, 2, '04774587', 82.80, 0.00, 'FRONT PADS\r\nF BRAKE DISC', 'GY63KLZ', NULL, '2024-10-11 00:00:00', '2024-11-13 12:46:20'),
-- (606, 2, '04774233', 9.59, 0.00, 'BRAKE PIPE 3/16INCH 25F', NULL, NULL, '2024-10-10 00:00:00', '2024-11-13 12:47:34'),
-- (607, 1, 'IV289390', 13.50, 0.00, 'WHEEL BEARING KIT', 'K786MTS', NULL, '2024-10-05 00:00:00', '2024-11-13 12:49:03'),
-- (608, 1, 'IV290095', 30.00, 0.00, 'SPARK PLUG', 'FA54XDU', NULL, '2024-10-10 00:00:00', '2024-11-13 12:50:03'),
-- (609, 1, 'IV289975', 101.00, 0.00, 'SHOCK ABSORBER FRONT\r\nBGA TIE ROD END', 'WDB9026711R7213', NULL, '2024-10-09 00:00:00', '2024-11-13 12:52:03'),
-- (610, 1, 'IV289925', 71.00, 0.00, 'BRAKE DISC\r\nBRAKE PADS\r\nWINTER KIT', 'KS16LNM', NULL, '2024-10-09 00:00:00', '2024-11-13 12:53:14'),
-- (611, 1, 'IV289661', 18.00, 0.00, 'STABLIZER LINK\r\nBGA STAB LINK', 'ACR50-0034175', NULL, '2024-10-08 00:00:00', '2024-11-13 12:54:35'),
-- (612, 1, 'IV289659', 148.50, 0.00, 'SENSOR\r\nAPEC W/SENSOR\r\nRR BRAKE DISC\r\nRR BRAKE PADS', 'WDB9026711R7213', NULL, '2024-10-08 00:00:00', '2024-11-13 12:56:23'),
-- (613, 1, 'IV289675', 44.50, 0.00, 'OIL FILTER\r\nAIR FILTER\r\nSPARK PLUG', 'FA54XDU', NULL, '2024-10-08 00:00:00', '2024-11-13 12:58:06'),
-- (614, 17, '65960', 67.90, 0.00, 'ALPHARD 08\r\nTOP SHOCK MOUNT', NULL, NULL, '2024-10-08 00:00:00', '2024-11-13 13:04:16'),
-- (615, 17, '65952', 151.50, 0.00, 'FRONT SHOCK\r\nFRONT SHOCK', NULL, NULL, '2024-10-08 00:00:00', '2024-11-13 13:06:10'),
-- (616, 2, '04772812', 9.60, 0.00, 'AIR FILTER', 'FA54XDU', NULL, '2024-10-08 00:00:00', '2024-11-13 13:07:30'),
-- (617, 1, 'IV289710', 34.00, 0.00, 'SPARK PLUG', 'FA54XDU', NULL, '2024-10-08 00:00:00', '2024-11-13 13:08:58'),
-- (618, 1, 'IV289806', 21.50, 0.00, 'APEC COIL SPRING', 'NX58VXA', NULL, '2024-10-08 00:00:00', '2024-11-13 13:10:40'),
-- (619, 3, 'LEA2235303', 52.90, 0.00, 'SHOCK ABSORBER', 'FE60FZG', NULL, '2024-10-07 00:00:00', '2024-11-13 13:13:19'),
-- (620, 2, '04771994', 15.00, 0.00, 'AIT FILTER\r\nOIL FILTER', 'NL13DLX', NULL, '2024-10-07 00:00:00', '2024-11-13 13:29:35'),
-- (621, 6, 'IN833400', 57.11, 0.00, 'SHOCK ABS GAS FRONT \r\nSTABLIZER LINK \r\nOIL FILTER\r\nAIR FILTER\r\nSPARK PLUGS', 'FE60FZG', NULL, '2024-10-07 00:00:00', '2024-11-13 13:31:31'),
-- (622, 2, '04770800', 17.94, 0.00, 'SIMONIZ MATT BLACK', NULL, NULL, '2024-10-04 00:00:00', '2024-11-13 13:33:14'),
-- (623, 1, 'IV289050', 35.00, 0.00, 'SUSP ARM LH', 'NV63UHR', NULL, '2024-10-04 00:00:00', '2024-11-13 13:34:20'),
-- (624, 1, 'IV289049', 6.50, 0.00, 'BGA STABLIZER LINK', 'LT60NSE', NULL, '2024-10-04 00:00:00', '2024-11-13 13:35:32'),
-- (625, 1, 'IV288914', 32.00, 0.00, 'WHEEL BEARING', 'YH56EYD', NULL, '2024-10-03 00:00:00', '2024-11-13 13:36:40'),
-- (626, 2, '04770281', 300.00, 0.00, 'GBX155 BOOST X 12V 4250A LITHI', NULL, NULL, '2024-10-03 00:00:00', '2024-11-13 13:39:56'),
-- (627, 2, '04770308', 32.40, 0.00, 'FUEL FILTER\r\nAIR FILTER\r\nOIL FILTER', 'FV13FRN', NULL, '2024-10-03 00:00:00', '2024-11-13 13:41:04'),
-- (628, 2, '04767336', 14.14, 0.00, 'AIR FILTER\r\nOIL FILTER', NULL, NULL, '2024-09-28 00:00:00', '2024-11-13 13:42:34'),
-- (629, 2, '04767337', 15.90, 0.00, 'AIR FILTER\r\nOIL FILTER', NULL, NULL, '2024-09-28 00:00:00', '2024-11-13 13:43:43'),
-- (630, 3, 'LEA2244210', 42.88, 0.00, 'SENSOR WHEEL SPEED', 'NL61YOF', NULL, '2024-11-15 00:00:00', '2024-11-20 11:11:02'),
-- (631, 2, '04793381', 77.40, 0.00, 'SUS ARM LH/RH\r\nFRONT NISSAN', 'NL61YOF', NULL, '2024-11-15 00:00:00', '2024-11-20 11:12:38'),
-- (632, 18, '28847278', 75.41, 0.00, 'BATTERY', 'D12WKC', NULL, '2024-11-14 00:00:00', '2024-11-20 11:16:12'),
-- (633, 1, 'IV295825', 48.50, 0.00, 'STAB LINK \r\nSUS ARM', 'YP64PFN', NULL, '2024-11-13 00:00:00', '2024-11-20 11:17:41'),
-- (634, 2, '04792131', 120.32, 0.00, 'FRONT BRAKE PADS\r\nREAR PADS\r\nSPARK PLUG\r\nAIR FILTER\r\nOIL FILTER', 'SGO7YPR', NULL, '2024-11-13 00:00:00', '2024-11-20 11:29:39'),
-- (635, 2, '04792140', 30.00, 0.00, 'COIL SPRING FRONT NISSAN', 'YP64PFN', NULL, '2024-11-13 00:00:00', '2024-11-20 11:31:14'),
-- (636, 2, '04792128', 10.91, 0.00, 'AIR FILTER\r\nOIL FILTER', 'LG58BYM', NULL, '2024-11-13 00:00:00', '2024-11-20 11:32:15'),
-- (637, 2, '04792312', 28.80, 0.00, 'CROSS DO ENGINE MOUNT ASTRA GH', 'BP14AEX', NULL, '2024-11-13 00:00:00', '2024-11-20 11:33:25'),
-- (638, 2, '04791799', 2.87, 0.00, 'OIL FILTER', 'BK13WNC', NULL, '2024-11-12 00:00:00', '2024-11-20 11:34:45'),
-- (639, 2, '04791714', 9.35, 0.00, 'STAB LINK/ FRONT', 'NA', NULL, '2024-11-12 00:00:00', '2024-11-20 11:37:03'),
-- (640, 2, '04791552', 59.69, 0.00, 'COIL SPRING\r\nS/ABSOB REAR CIT C3', 'FG11KUU', NULL, '2024-11-12 00:00:00', '2024-11-20 11:38:15'),
-- (641, 1, 'IV295625', 84.00, 0.00, 'BRAKE DISC\r\nBRAKE PAD\r\nRH RH BRAKE CALIPER HONDA', 'SJ04XHT', NULL, '2024-11-12 00:00:00', '2024-11-20 11:39:57'),
-- (642, 1, 'IV295586', 29.50, 0.00, 'AIR FILTER\r\nFUEL FILTER\r\nOIL FILTER', 'BJ61XDC', NULL, '2024-11-12 00:00:00', '2024-11-20 11:42:10'),
-- (643, 1, 'IV295593', 3.00, 0.00, 'SUMP PLUG', 'BJ61XDC', NULL, '2024-11-12 00:00:00', '2024-11-20 11:43:03'),
-- (644, 2, '04791253', 24.00, 0.00, 'CROSS DO V/BELT PULLEY', 'WUO6GJK', NULL, '2024-11-12 00:00:00', '2024-11-20 11:44:14'),
-- (645, 2, '04791031', 14.30, 0.00, 'DRIVE BELT', 'NA', NULL, '2024-11-11 00:00:00', '2024-11-20 11:45:40'),
-- (646, 18, '28722394', 68.40, 0.00, 'ANTI FREEZ', 'STOCK', NULL, '2024-11-04 00:00:00', '2024-11-20 11:48:17'),
-- (647, 2, '04790796', 63.60, 0.00, 'EXIDE EXCELL BATTERY 027', 'NJO6LHA', NULL, '2024-11-11 00:00:00', '2024-11-20 11:57:58'),
-- (648, 2, '04790817', 46.79, 0.00, 'COIL SPRING REAR', 'VK64HMA', NULL, '2024-11-11 00:00:00', '2024-11-20 11:59:07'),
-- (649, 1, 'IV295392', 89.50, 0.00, 'BRAKE DISC\r\nBRAKE PAD\r\nBRAKE CALIPER', 'KM58KXP', NULL, '2024-11-11 00:00:00', '2024-11-20 12:07:16'),
-- (650, 1, 'IV295054', 16.00, 0.00, 'TIE ROD', 'DE07LJN', NULL, '2024-11-08 00:00:00', '2024-11-20 12:08:23'),
-- (651, 2, '04790634', 34.76, 0.00, 'WATER PUMP', 'AK62ZVH', NULL, '2024-11-11 00:00:00', '2024-11-20 12:09:19'),
-- (652, 18, '28802752', 11.40, 0.00, 'ELBOW', 'AK62ZVH', NULL, '2024-11-11 00:00:00', '2024-11-20 12:10:18'),
-- (653, 18, '28802727', 39.14, 0.00, 'BATTERY', 'FM56YVV', NULL, '2024-11-11 00:00:00', '2024-11-20 12:11:39'),
-- (654, 1, 'IV295474', 23.50, 0.00, 'BGA TENSION PULLEY', 'WU60GJK', NULL, '2024-11-11 00:00:00', '2024-11-20 12:12:37'),
-- (655, 2, '04767354', 10.82, 0.00, 'POLLEN FILTER', 'PJ65EUF', NULL, '2024-09-28 00:00:00', '2024-11-20 12:13:57'),
-- (656, 2, '04767356', 12.76, 0.00, 'STAB LINK LH/RH', 'RO11DWX', NULL, '2024-09-28 00:00:00', '2024-11-20 12:16:20'),
-- (657, 2, '04769741', 92.50, 0.00, 'CRANKSHAFT PULLEY KIT', 'NA59ZNW', NULL, '2024-10-02 00:00:00', '2024-11-20 12:17:37'),
-- (658, 2, '04769675', 9.40, 0.00, 'BRAKE LIGHT SWITCH', 'KS08TTU', NULL, '2024-10-02 00:00:00', '2024-11-20 12:18:43'),
-- (659, 18, '28358146', 19.00, 0.00, 'BRAKE AND CLUTCH CLEANE', 'STOCK', NULL, '2024-10-02 00:00:00', '2024-11-20 12:20:13'),
-- (660, 2, '04769392', 59.33, 0.00, 'B/PAD SET X2\r\nREAR DISC', 'SK09UYH', NULL, '2024-10-02 00:00:00', '2024-11-20 12:21:31'),
-- (661, 2, '04769238', 54.00, 0.00, 'CLUTCH MASTER', 'SF17ETN', NULL, '2024-10-02 00:00:00', '2024-11-20 12:30:41'),
-- (662, 2, '04771015', 30.00, 0.00, 'FRONT PADS', 'NV63UHR', NULL, '2024-10-04 00:00:00', '2024-11-20 12:33:14'),
-- (663, 1, 'IV289144', 23.00, 0.00, 'WHEEL BEARING KIT', 'AP07WYS', NULL, '2024-10-04 00:00:00', '2024-11-20 12:34:17'),
-- (664, 2, '04770872', 52.80, 0.00, 'FRONT BRAKE DISC', 'NV63UHR', NULL, '2024-10-04 00:00:00', '2024-11-20 12:35:22'),
-- (665, 2, '04768479', 59.99, 0.00, 'REAR BOX VW POLO', 'WU06GJK', NULL, '2024-09-30 00:00:00', '2024-11-20 12:38:20'),
-- (666, 1, 'IV288483', 22.50, 0.00, 'BRAKE PAD', 'FP63FJA', NULL, '2024-10-01 00:00:00', '2024-11-20 12:39:58'),
-- (667, 2, '04796204', 5.60, 0.00, 'OIL FILTER', 'LV66VKM', NULL, '2024-11-20 00:00:00', '2024-11-20 14:29:18'),
-- (668, 2, '439346', 17.18, 0.00, 'CROSLAND AIR FILTER \r\nCROSLAND FUEL FILTER\r\nCROSLAND  OIL FILTER', 'WDF63970313278359', NULL, '2024-12-12 00:00:00', '2024-12-13 14:30:32'),
-- (669, 2, '439987', 33.60, 0.00, 'FRONT AUDI A6', 'sw10lub', NULL, '2024-12-12 00:00:00', '2024-12-13 14:36:45'),
-- (670, 1, 'IV300684', 16.00, 0.00, 'BGA STAB LINK', 'LO08HKZ', NULL, '2024-12-11 00:00:00', '2024-12-13 14:37:05'),
-- (671, 1, 'IV300683', 10.00, 0.00, 'NAPA WHEEL CYLINDER', 'YS53VDR', NULL, '2024-12-11 00:00:00', '2024-12-13 14:38:47'),
-- (672, 2, '439682', 92.60, 0.00, 'GUIDE BUSH \r\n3PCS CLUTCH KIT WITH BEARINGS PS', 'CY08COJ', NULL, '2024-12-12 00:00:00', '2024-12-13 14:41:27'),
-- (673, 18, '29114923', 43.61, 0.00, 'BATTERY', 'FJ12VUY', NULL, '2024-12-13 00:00:00', '2024-12-13 14:44:39'),
-- (674, 2, '435415', 120.60, 0.00, 'FRONT BRAKE DISC', 'DY57VFR', NULL, '2024-12-09 00:00:00', '2024-12-13 14:47:11'),
-- (675, 2, '435253', 3.49, 0.00, 'OIL FILTER', 'DY57VFR', NULL, '2024-12-09 00:00:00', '2024-12-13 14:51:25'),
-- (676, 2, '435942', 6.38, 0.00, 'SPARK PLUG', 'WN07YKA', NULL, '2024-12-10 00:00:00', '2024-12-13 14:56:22'),
-- (677, 1, 'IV300292', 37.50, 0.00, 'STAB LINK', 'AM13RYN', NULL, '2024-12-10 00:00:00', '2024-12-13 14:59:44'),
-- (678, 2, '04800049', 2.09, 0.00, 'LITH CELL BATTERY', 'NA', NULL, '2024-11-27 00:00:00', '2024-12-16 10:22:43'),
-- (679, 1, 'IV298283', 320.00, 0.00, 'PROPSHAFT', 'NA', NULL, '2024-11-27 00:00:00', '2024-12-16 10:24:11'),
-- (680, 1, 'IV298215', 24.00, 0.00, 'AIR FILTER\r\nCABIN FILTER\r\nOIL FILTER', 'BK09HVR', NULL, '2024-11-27 00:00:00', '2024-12-16 10:25:38'),
-- (681, 2, '04799633', 6.71, 0.00, 'CAR DE HUMIFIER', 'NA', NULL, '2024-11-26 00:00:00', '2024-12-16 10:26:41'),
-- (682, 2, '04801547', 25.54, 0.00, 'STAB LINK FRONT LH/RH', 'DE61VRG', NULL, '2024-11-29 00:00:00', '2025-01-06 13:36:52'),
-- (683, 2, '04801567', 11.28, 0.00, 'AIR FILTER\r\nOIL FILTER', 'NJ16XSL', NULL, '2024-11-29 00:00:00', '2025-01-06 13:37:59'),
-- (684, 2, '04801177', 10.20, 0.00, 'BALL JOINT LOWER LH/RH', 'YS66NJJ', NULL, '2024-11-29 00:00:00', '2025-01-06 13:39:01'),
-- (685, 2, '04800638', 18.40, 0.00, 'POLLEN FILTER\r\nFUEL FILTER\r\nAIR FILTER\r\nOIL FILTER', 'S8NTKVW', NULL, '2024-11-28 00:00:00', '2025-01-06 13:40:25'),
-- (686, 6, 'IN840363', 23.40, 0.00, 'LED TWIST 5W COB', 'LED601G', NULL, '2024-11-28 00:00:00', '2025-01-06 13:41:58'),
-- (687, 2, '04800819', 19.19, 0.00, 'AIR FILTER\r\nOIL FILTER', 'LF11CVW', NULL, '2024-11-28 00:00:00', '2025-01-06 13:43:18'),
-- (688, 15, '72IN025793', 54.00, 0.00, 'BRAKE PAD SET\r\nBRAKE DISC', 'YS66NJJ', NULL, '2024-11-29 00:00:00', '2025-01-06 13:44:52'),
-- (689, 2, '04801284', 34.75, 0.00, 'POLLEN FILTER\r\nSPARK PLUG\r\nAIR FILTER\r\nOIL FILTER', 'YT56USB', NULL, '2024-11-29 00:00:00', '2025-01-06 13:46:13'),
-- (690, 2, '04802434', 42.00, 0.00, 'REAR BRAKE PADS\r\nBRAKE DISC REAR', 'NL08ZWC', NULL, '2024-12-02 00:00:00', '2025-01-06 13:47:31'),
-- (691, 3, 'LEA2247738', 49.44, 0.00, 'CV JOINT KIT\r\nOLD UNIT CHARGE', 'DV10KLU', NULL, '2024-12-02 00:00:00', '2025-01-06 13:50:24'),
-- (692, 2, '04802629', 5.88, 0.00, 'OIL FILTER\r\nOIL FILTER', 'SP09UGC', NULL, '2024-12-02 00:00:00', '2025-01-06 13:51:27'),
-- (693, 2, '04802811', 12.00, 0.00, 'TIE ROD END RHS', 'DV10KLU', NULL, '2024-12-02 00:00:00', '2025-01-06 13:52:45'),
-- (694, 2, '04802852', 29.77, 0.00, 'STARLINE BATTERY', 'MT09ZCF', NULL, '2024-12-02 00:00:00', '2025-01-06 13:54:37'),
-- (695, 3, 'LEA2247989', 51.86, 0.00, 'COIL SPRING', 'BN10XBY', NULL, '2024-12-03 00:00:00', '2025-01-06 13:55:41'),
-- (696, 2, '04803532', 3.60, 0.00, 'SCREW KIT', 'BN10XBY', NULL, '2024-12-03 00:00:00', '2025-01-06 13:56:34'),
-- (697, 2, '04803021', 58.80, 0.00, 'FRONT BRAKE PADS\r\nFRONT DISC', 'NL10ZVU', NULL, '2024-12-03 00:00:00', '2025-01-06 13:58:11'),
-- (698, 2, 'GF63HFM', 48.00, 0.00, 'FRONT CONTROL ARM RH\r\nFRONT CONTROL ARM LH', 'GF63HFM', NULL, '2024-12-04 00:00:00', '2025-01-06 13:59:39'),
-- (699, 2, '04803777', 72.00, 0.00, '3PC CLUTCH KIT', 'BN56EPP', NULL, '2024-12-04 00:00:00', '2025-01-06 14:00:37'),
-- (700, 2, '04803931', 7.90, 0.00, 'AIR FILTER\r\nOIL FILTER', 'YC17RWJ', NULL, '2024-12-04 00:00:00', '2025-01-06 14:01:35'),
-- (701, 2, '04803918', 9.36, 0.00, 'UNIVERSAL CV BOOT', 'NA/ SUNNY', NULL, '2024-12-04 00:00:00', '2025-01-06 14:02:40'),
-- (702, 1, 'IV299537', 60.00, 0.00, 'BRAKE DISC\r\nBRAKE PAD', 'BF66WKZ', NULL, '2024-12-05 00:00:00', '2025-01-06 14:03:49'),
-- (703, 2, '04804533', 14.40, 0.00, 'AIR FILTER\r\nOIL FILTER', 'BF66WKZ', NULL, '2024-12-05 00:00:00', '2025-01-06 14:04:49'),
-- (704, 2, '04804499', 2.62, 0.00, 'OIL FILTER', 'SUNNY / NA', NULL, '2024-12-05 00:00:00', '2025-01-06 14:09:28'),
-- (705, 2, '04805218', 42.00, 0.00, 'REAR LOWER WISHBONE', 'SWO7BNX', NULL, '2024-12-06 00:00:00', '2025-01-06 14:12:29'),
-- (706, 18, '29096867', 18.37, 0.00, 'BOLT\r\nCAM', 'SW07BNX', NULL, '2024-12-06 00:00:00', '2025-01-06 14:13:53'),
-- (707, 1, 'IV299770', 21.00, 0.00, 'COIL SPRING', 'SW07BNX', NULL, '2024-12-06 00:00:00', '2025-01-06 14:15:10'),
-- (708, 2, '04805424', 71.99, 0.00, 'CROSS DO RED LITH-ION CHEMI', 'SUNNY/ NA', NULL, '2024-12-06 00:00:00', '2025-01-06 14:16:51'),
-- (709, 2, 'DE60HFH', 28.80, 0.00, 'WISHBONE MOUNT LH/RH', 'DE60HFH', NULL, '2024-12-07 00:00:00', '2025-01-06 14:18:08'),
-- (710, 2, '04805707', 9.10, 0.00, 'AIR FILTER\r\nOIL FILTER', 'FV09SXC', NULL, '2024-12-07 00:00:00', '2025-01-06 14:19:10'),
-- (711, 1, '04805764', 12.00, 0.00, 'REAR MANDO HYUND', 'FV09SXC', NULL, '2024-12-07 00:00:00', '2025-01-06 14:20:09'),
-- (712, 2, '04805759', 31.99, 0.00, 'HANDBRAKE SHOES HYUNDAI', 'FV09SXC', NULL, '2024-12-07 00:00:00', '2025-01-06 14:21:11'),
-- (713, 2, '04807748', 23.21, 0.00, 'FUEL FILTER\r\nAIR FILTER\r\nOIL FILTER', 'DF08BFL', NULL, '2024-12-11 00:00:00', '2025-01-06 14:23:38'),
-- (714, 2, '04807749', 7.60, 0.00, 'CV BOOT KIT INNER VAG', 'L60DHY', NULL, '2024-12-11 00:00:00', '2025-01-06 14:25:09'),
-- (715, 2, '04807673', 20.86, 0.00, 'COPPER BRAKE PIPE', 'SUNNY/ NA', NULL, '2024-12-11 00:00:00', '2025-01-06 14:26:13'),
-- (716, 2, '04807525', 24.00, 0.00, 'LOWER CONTROL ARM RH NISSAN QA', 'PF11JBU', NULL, '2024-12-11 00:00:00', '2025-01-06 14:27:12'),
-- (717, 1, 'IV300455', 12.00, 0.00, 'WHEEL BEARING KIT', 'Y972WOA', NULL, '2024-12-10 00:00:00', '2025-01-06 14:28:10'),
-- (718, 2, '04807444', 10.00, 0.00, 'AIR FILTER\r\nOIL FILTER', 'FN13ACF', NULL, '2024-12-11 00:00:00', '2025-01-06 14:29:33'),
-- (719, 3, 'LEA2249656', 40.21, 0.00, 'BRAKE DRUM', 'Y972WOA', NULL, '2024-12-11 00:00:00', '2025-01-06 14:30:29'),
-- (720, 2, '04807034', 29.93, 0.00, 'STARLINE BATTERY', 'MT09ZCF', NULL, '2024-12-10 00:00:00', '2025-01-06 14:31:41'),
-- (721, 2, '04807036', 55.07, 0.00, 'STAB LINK X2 LH/RH\r\nTIE ROD LH/RH', 'AO58HLM', NULL, '2024-12-10 00:00:00', '2025-01-06 14:33:23'),
-- (722, 2, '04806865', 29.53, 0.00, 'POLLEN FILTER\r\nFUEL FILTER PAPER\r\nAIR FILTER\r\nOIL FILTER', 'KW14ZVC', NULL, '2024-12-10 00:00:00', '2025-01-06 14:35:02'),
-- (723, 2, '04808807', 78.00, 0.00, 'B/PAD SET\r\nVERSO AURIS 295MM', 'FY06VTK', NULL, '2024-12-13 00:00:00', '2025-01-06 14:36:20'),
-- (724, 2, '04808752', 75.60, 0.00, 'COIL SPRING FRONT FORD FOCUS\r\nFRONT PADS \r\nFRONT DISC', 'FN13UJY', NULL, '2024-12-13 00:00:00', '2025-01-06 14:38:05'),
-- (725, 2, '04809033', 14.62, 0.00, 'ROLL OF 100 SIAP PLASTIC', 'SUNNY/ NA', NULL, '2024-12-13 00:00:00', '2025-01-06 14:39:21'),
-- (726, 2, '04808229', 17.18, 0.00, 'FUEL FILTER\r\nAIR FILTER\r\nOIL FILTER', 'NA', NULL, '2024-12-12 00:00:00', '2025-01-06 14:40:54'),
-- (727, 2, '04808490', 33.60, 0.00, 'FRONT AUDI A6 EX 2.7TDI', 'SW10LUB', NULL, '2024-12-12 00:00:00', '2025-01-06 14:46:22'),
-- (728, 2, '04808366', 92.60, 0.00, 'GUIDE BUSH TUBE DW8\r\n3PC CLUTCH KIT WITH BEARING', 'CY08COJ', NULL, '2024-12-12 00:00:00', '2025-01-06 14:49:09'),
-- (729, 2, 'DY57VFR', 120.60, 0.00, 'FRONT CONTROL ARM RH LOWER OUT\r\nFRONT BRAKE PADS DISPATCH', 'DF57VFR', NULL, '2024-12-09 00:00:00', '2025-01-06 14:54:31'),
-- (730, 2, '04806482', 3.49, 0.00, 'OIL FILTER', 'DY57VFR', NULL, '2024-12-09 00:00:00', '2025-01-06 14:56:05'),
-- (731, 2, '04806768', 6.38, 0.00, 'DENSO NICKEL SPARK PLUG', 'WN07YKA', NULL, '2024-12-10 00:00:00', '2025-01-06 14:57:13'),
-- (732, 1, 'IV301180', 16.00, 0.00, 'STAB LINK', 'SN58HTX', NULL, '2024-12-14 00:00:00', '2025-01-06 14:59:30'),
-- (733, 2, '04794442', 66.00, 0.00, '3PC CLUTCH KIT WITH BEARING', 'WR55OVW', NULL, '2024-11-18 00:00:00', '2025-01-06 15:01:10'),
-- (734, 1, 'IV296466', 54.00, 0.00, 'BLUE BRAKE DISC\r\nBLUE BRAKE PAD', 'WL14EOZ', NULL, '2024-11-16 00:00:00', '2025-01-06 15:02:24'),
-- (735, 10, '240032775', 28.60, 0.00, 'FILTERELEM\r\nLL-03 5L CUBE', 'YS16AEU', NULL, '2024-11-18 00:00:00', '2025-01-06 15:05:34'),
-- (736, 2, '04794620', 45.60, 0.00, 'REAR BRAKE PADS\r\nREAR BRAKE DISC', 'NL10ZVU', NULL, '2024-12-18 00:00:00', '2025-01-06 15:06:57'),
-- (737, 2, '04794743', 57.60, 0.00, 'CROSS DO ENGINE MOUNT', 'GK55OWU', NULL, '2024-12-18 00:00:00', '2025-01-06 15:08:26'),
-- (738, 2, '04796068', 108.00, 0.00, 'SUSPENSION ARM LOWER LH/RH', 'YF55VNZ', NULL, '2024-11-20 00:00:00', '2025-01-06 15:25:46'),
-- (739, 2, '04795524', 2.70, 0.00, 'PERSTONE DE-ICER TRIGGER- 40C', 'SUNNY/ NA', NULL, '2024-11-19 00:00:00', '2025-01-06 15:27:00'),
-- (740, 2, '04795709', 26.47, 0.00, 'BOSH OIL FILTER\r\nTHERMOSTAT & HOUDING VARIOUS', 'AJ53LFH', NULL, '2024-11-20 00:00:00', '2025-01-06 15:28:32'),
-- (741, 1, 'IV296905', 45.00, 0.00, 'POWERGRIP TIMIN\r\nWATER PUMP', 'AJ53LFA', NULL, '2024-11-20 00:00:00', '2025-01-06 15:29:54'),
-- (742, 1, 'IV297140', 17.00, 0.00, 'BRAKE PAD', 'BU13MDY', NULL, '2024-11-21 00:00:00', '2025-01-06 15:31:04'),
-- (743, 2, '04796607', 28.80, 0.00, '1LTR CASTROL TRANSMAX MANUAL F', 'NJ65NDO', NULL, '2024-11-21 00:00:00', '2025-01-06 15:39:18'),
-- (744, 1, 'IV297308', 43.00, 0.00, 'WISHBONE', 'LC07WBK', NULL, '2024-11-22 00:00:00', '2025-01-06 15:40:20'),
-- (745, 1, 'IV297302', 20.00, 0.00, 'THE ROD END OUTER RH\r\nTIE ROD END OUTER LH', 'LC07WBK', NULL, '2024-11-22 00:00:00', '2025-01-06 15:41:44'),
-- (746, 1, 'IV297349', 31.50, 0.00, 'OIL FILTER\r\nAIR FILTER\r\nCABIN FILTER\r\nFUEL FILTER', 'PJ15LHE', NULL, '2024-11-22 00:00:00', '2025-01-06 15:43:06'),
-- (747, 1, 'IV297344', 375.00, 0.00, 'ENERGY PREMIUM 5W30 C3 208', 'NA', NULL, '2024-11-22 00:00:00', '2025-01-06 15:44:27'),
-- (748, 2, '04797413', 55.06, 0.00, 'BRAKE PADS RAER/ FRONT\r\nFRONT WEAR SENSOR\r\nOIL FILTER', 'S29ANW', NULL, '2024-11-22 00:00:00', '2025-01-06 15:46:11'),
-- (749, 2, '04797418', 13.00, 0.00, 'AIR FILTER\r\nOIL FILTER', 'NH570XN', NULL, '2024-11-22 00:00:00', '2025-01-06 15:47:24'),
-- (750, 2, '04797518', 72.00, 0.00, 'BRAKE PADS F/R\r\nREAR BRAKE DISC', 'LK14JLO', NULL, '2024-11-22 00:00:00', '2025-01-06 15:48:42'),
-- (751, 6, 'IN832093', 170.28, 0.00, 'CLUTCH KIT\r\nSLAVE CYLINDER', 'FP63FJA', NULL, '2024-09-24 00:00:00', '2025-01-06 15:50:31'),
-- (752, 2, '04797667', 56.12, 0.00, 'EXHAUST MOUNTING\r\nLINK PIPE', 'RV56YDA', NULL, '2024-11-22 00:00:00', '2025-01-06 15:52:00'),
-- (753, 2, '04797726', 13.16, 0.00, 'CROSS DO STABILISER LINK FRONT LH', 'LC07WBK', NULL, '2024-11-22 00:00:00', '2025-01-06 15:53:50'),
-- (754, 2, '04796401', 48.60, 0.00, 'CON DO FAN   & COWL PUNTO', 'AJ53LFH', NULL, '2024-11-21 00:00:00', '2025-01-06 16:07:53'),
-- (755, 2, '04797239', 6.05, 0.00, 'AIR FILTER\r\nOIL FILTER', 'FP66VCL', NULL, '2024-11-22 00:00:00', '2025-01-06 16:09:14'),
-- (756, 2, '04797857', 470.66, 0.00, 'DUAL MASS\r\nFLYWHEEL BOLTS\r\nSAC CLUTCH KIT + BEARING b', 'YK11VLC', NULL, '2024-11-23 00:00:00', '2025-01-06 16:15:58'),
-- (757, 1, 'IV297585', 33.75, 0.00, 'APEC SHOCK ABSORBER REAR\r\nOIL FILTER\r\nAIR FILTER', 'HN09UMX', NULL, '2024-11-23 00:00:00', '2025-01-06 16:17:42'),
-- (758, 1, 'IV297584', 14.00, 0.00, '8202 DCT/DSG GETRIEBEOEL FL', 'PB05ZAB', NULL, '2024-11-23 00:00:00', '2025-01-06 16:19:05'),
-- (759, 1, 'IV297643', 13.00, 0.00, 'AIR FILTER\r\nOIL FILTER', 'FX16XAU', NULL, '2024-11-23 00:00:00', '2025-01-06 16:21:15'),
-- (760, 2, '04798381', 66.58, 0.00, 'POLLEN FILTER\r\nFUEL FILTER\r\nAIR FILTER\r\nOIL FILTER', 'KY60UGF', NULL, '2024-11-25 00:00:00', '2025-01-06 16:22:30'),
-- (761, 2, '04798388', 12.89, 0.00, 'AIR FILTER\r\nOIL FILTER', 'YF120GB', NULL, '2024-11-25 00:00:00', '2025-01-06 16:23:40'),
-- (762, 2, '04798585', 26.52, 0.00, 'MANN FUEL FILTER', 'KY60FFK', NULL, '2024-11-25 00:00:00', '2025-01-06 16:24:50'),
-- (763, 1, 'IV297722', 65.00, 0.00, 'BGA DRIVE SHAFT', 'YY03DFZ', NULL, '2024-11-25 00:00:00', '2025-01-06 16:26:17'),
-- (764, 15, '721N025492', 90.00, 0.00, 'BRAKE CALIPER', 'RO61WOU', NULL, '2024-11-25 00:00:00', '2025-01-06 16:27:28'),
-- (765, 6, 'IN839968', 22.62, 0.00, 'BREAK HOSE', 'RO61WOU', NULL, '2024-11-26 00:00:00', '2025-01-06 16:29:27'),
-- (766, 2, '04830565', 6.17, 0.00, 'POLLEN FILTER', 'PJ57ZVU', NULL, '2025-01-27 00:00:00', '2025-02-07 09:27:22'),
-- (767, 6, 'IN848128', 69.65, 0.00, 'BRAKE DISC\r\nBRAKE PADS', 'CK62UXB', NULL, '2025-01-30 00:00:00', '2025-02-07 09:29:19'),
-- (768, 18, '3127123', 43.61, 0.00, 'BATTERY\r\n(SUNNY)', 'NA', NULL, '2024-12-30 00:00:00', '2025-02-07 09:32:03'),
-- (769, 18, '29599195', 8.74, 0.00, 'PLUG-EXPANSION', 'OE57YNJ', NULL, '2025-01-30 00:00:00', '2025-02-07 09:34:14'),
-- (770, 1, 'IV308864', 8.00, 0.00, 'VISION-PRO WASHER PUMPS', 'FM06BVY', NULL, '2025-01-30 00:00:00', '2025-02-07 09:35:44'),
-- (771, 5, '19471021', 0.00, 0.00, 'N/STK FILL LEVELS \r\nNOTIF MA091', 'MY13RHM', NULL, '2024-12-16 00:00:00', '2025-02-07 09:40:01'),
-- (772, 1, 'IV301367', 140.00, 0.00, 'BGA TRACK CONTROL ARM X2', 'MY13RHM', NULL, '2024-12-16 00:00:00', '2025-02-07 09:41:29'),
-- (773, 1, 'IV301343', 130.00, 0.00, 'CLUTCH KIT', 'YG57FHZ', NULL, '2024-12-16 00:00:00', '2025-02-07 09:42:37'),
-- (774, 5, '19471048', 76.68, 0.00, 'OIL FILTER', 'WD13FNK', NULL, '2024-12-16 00:00:00', '2025-02-07 09:44:11'),
-- (775, 1, 'IV301268', 31.50, 0.00, 'OIL FILTER\r\nSPARK PLUG\r\nAIR FILTER\r\nCABIN FILTER', 'DV10KLU', NULL, '2024-12-16 00:00:00', '2025-02-07 09:46:36'),
-- (776, 5, '19471113', 14.44, 0.00, 'RADIATOR CAP', 'WD13FNK', NULL, '2024-12-17 00:00:00', '2025-02-07 09:47:39'),
-- (777, 1, 'IV301535', 12.00, 0.00, 'BGA STAB LINK', 'YS08DHU', NULL, '2024-12-17 00:00:00', '2025-02-07 09:48:53'),
-- (778, 2, '04810409', 16.34, 0.00, 'POLLEN FILTER\r\nAIR FILTER\r\nOIL FILTER', 'NA65VUH', NULL, '2024-12-17 00:00:00', '2025-02-07 09:50:18'),
-- (779, 19, 'INV-2944', 174.34, 0.00, '255/55R17 101H GRENLANDER COLO H01 XL', 'NA', NULL, '2024-12-18 00:00:00', '2025-02-07 09:56:19'),
-- (780, 2, '04811910', 2.62, 0.00, 'WIPER BLADE UNIVERSAL\r\nSUNNY*', 'NA', NULL, '2024-12-19 00:00:00', '2025-02-07 09:57:44'),
-- (781, 2, '04812148', 104.40, 0.00, 'R BRAKE PADS\r\nF BRAKE PADS\r\nF BRAKE DISC', 'N44RRU', NULL, '2024-12-19 00:00:00', '2025-02-07 09:59:44'),
-- (782, 6, 'IN843259', 49.25, 0.00, 'NAPA 85V 35W D2R P32D-3 HID\r\nSPARK PLUG', 'KS14FDL', NULL, '2024-12-19 00:00:00', '2025-02-07 10:02:09'),
-- (783, 1, 'IV302065', 55.00, 0.00, 'OIL FILTER\r\nAIR FILTER\r\nBRAKE PADS\r\nSTAB LINK LHS\r\nSTAB LINK RHS', 'FH59MVA', NULL, '2024-12-19 00:00:00', '2025-02-07 10:03:44'),
-- (784, 1, 'IV301668', 48.00, 0.00, 'NAPA WISHBONE LH', 'DV13GXF', NULL, '2024-12-17 00:00:00', '2025-02-07 10:14:52'),
-- (785, 2, '04811295', 36.00, 0.00, 'FRONT HUB OCTAVIA', 'FJ60VJX', NULL, '2024-12-18 00:00:00', '2025-02-07 10:16:27'),
-- (786, 2, '04811221', 11.62, 0.00, 'AIR FILTER\r\nOIL FILTER', 'BT07FLK', NULL, '2024-12-18 00:00:00', '2025-02-07 10:17:37'),
-- (787, 2, '04811003', 43.56, 0.00, 'CROSS DO STARLINE X5', 'NA', NULL, '2024-12-18 00:00:00', '2025-02-07 10:20:11'),
-- (788, 2, '04811784', 23.54, 0.00, 'STARLINK WIPER BLADE UNI X4', 'SUNNY', NULL, '2024-12-19 00:00:00', '2025-02-07 10:21:20'),
-- (789, 2, '04812527', 12.00, 0.00, 'STAB LINK SUBARU', 'YE64XBZ', NULL, '2024-12-20 00:00:00', '2025-02-07 10:23:05'),
-- (790, 1, 'IV301746', 65.00, 0.00, 'EXIDE BATTERY', 'WN07YKA', NULL, '2024-12-18 00:00:00', '2025-02-07 10:24:29'),
-- (791, 1, 'IV301314', 66.00, 0.00, 'REAR SHOCK', 'PK13TAV', NULL, '2024-12-16 00:00:00', '2025-02-07 10:25:35'),
-- (792, 2, '04812521', 227.94, 0.00, '53MM DIA B+\r\nDRIVE BELT X2', 'VU61JVX', NULL, '2024-12-20 00:00:00', '2025-02-07 10:27:01'),
-- (793, 1, 'IV302125', 18.50, 0.00, 'BRAKE PADS APEC BLUE', 'FM63LVR', NULL, '2024-12-20 00:00:00', '2025-02-07 10:29:02'),
-- (794, 2, '04812419', 12.00, 0.00, 'BALL JOINT LH/RH LWR', 'YE64XBZ', NULL, '2024-12-20 00:00:00', '2025-02-07 10:30:26'),
-- (795, 2, '04812345', 42.00, 0.00, 'CRODD OD PHILIPS VISION BULB', 'SUNNY', NULL, '2024-12-20 00:00:00', '2025-02-07 10:31:44'),
-- (796, 2, '04812279', 12.00, 0.00, 'FRONT PADS', 'FM63LVR', NULL, '2024-12-19 00:00:00', '2025-02-07 10:33:13'),
-- (797, 2, '04813007', 4.18, 0.00, 'F/R WEAR SENSOR MERCEDE', 'DV63CDZ', NULL, '2024-12-21 00:00:00', '2025-02-07 10:36:36'),
-- (798, 2, '04812934', 16.94, 0.00, 'AIR FILTER\r\nOIL FILTER', 'GM15VCM', NULL, '2024-12-21 00:00:00', '2025-02-07 10:38:07'),
-- (799, 1, 'IV303597', 42.00, 0.00, 'SHOCK ABSORBER', 'NG10AGO', NULL, '2025-01-02 00:00:00', '2025-02-07 10:39:18'),
-- (800, 1, 'IV303544', 26.00, 0.00, 'BRAKE PAD', 'BF62SBY', NULL, '2025-01-02 00:00:00', '2025-02-07 10:40:30'),
-- (801, 2, '04815699', 22.33, 0.00, 'SHOCK ABSORB', 'NA', NULL, '2025-01-02 00:00:00', '2025-02-07 10:42:14'),
-- (802, 2, '04815693', 12.55, 0.00, 'POLLEN FILTER\r\nAIR FILTER\r\nOIL FILTER', 'FR10GNZ', NULL, '2025-01-02 00:00:00', '2025-02-07 10:43:43'),
-- (803, 1, 'IV303863', 40.00, 0.00, 'SPARK PLUG', 'WD13FNK', NULL, '2025-01-03 00:00:00', '2025-02-07 10:44:47'),
-- (804, 1, 'IV303864', 19.50, 0.00, 'OIL FILTER\r\nAIR FILTER\r\nFUEL FILTER', 'MM63WPE', NULL, '2025-01-03 00:00:00', '2025-02-07 10:45:57'),
-- (805, 3, '04816437', 32.06, 0.00, 'NGK SPARK PLUG', 'WD13FNK', NULL, '2025-01-03 00:00:00', '2025-02-07 10:46:59'),
-- (806, 1, 'IV303745', 29.00, 0.00, 'BRAKE PAD\r\nBGA TIE ROD END', 'LF66TTV', NULL, '2025-01-03 00:00:00', '2025-02-07 10:48:15'),
-- (807, 1, 'IV303744', 46.00, 0.00, 'BRAKE PAD X2', 'FD16NTN', NULL, '2025-01-03 00:00:00', '2025-02-07 10:49:22'),
-- (808, 1, 'IV304104', 32.00, 0.00, 'PAT FLUID ADDITIVE FOR PART', 'NA', NULL, '2025-01-06 00:00:00', '2025-02-07 10:50:39'),
-- (809, 1, 'IV312129', 19.00, 0.00, 'OIL FILTER\r\nCABIN FILTER\r\nAIR FILTER', 'WL19FBX', NULL, '2025-02-19 00:00:00', '2025-02-25 08:58:31');
-- INSERT INTO `purchase_invoices` (`id`, `supplier_id`, `part_invoice_number`, `amount`, `quantity`, `details`, `car_registration_number`, `deleted_at`, `created_at`, `updated_at`) VALUES
-- (810, 3, 'LEA2262811', 23.81, 0.00, 'EBT ROLLER BEARING', '4TXR', NULL, '2025-02-17 00:00:00', '2025-02-25 09:00:48'),
-- (811, 2, '04842411', 28.99, 0.00, 'WHEEL BEARING BMW', '4TXR', NULL, '2025-02-17 00:00:00', '2025-02-25 09:02:25'),
-- (812, 1, 'IV311734', 45.00, 0.00, 'APEC STRETCH BOOT KIT', 'EA63YOD', NULL, '2025-02-17 00:00:00', '2025-02-25 09:11:01'),
-- (813, 1, 'IV312861', 55.50, 0.00, 'BGA TIE ROD END X2\r\nSTAB LINK\r\nBALL JOINT', 'TAZ533', NULL, '2025-02-22 00:00:00', '2025-02-25 09:13:54'),
-- (814, 1, 'IV312836', 20.00, 0.00, 'BGA STAB LINK\r\nSTRETCH BOOT KIT', 'MH04LPP', NULL, '2025-02-22 00:00:00', '2025-02-25 09:16:22'),
-- (815, 1, 'IV312799', 14.50, 0.00, 'OIL FILTER\r\nAIR FILTER\r\nCABIN FILTER', 'CV10OZX', NULL, '2025-02-22 00:00:00', '2025-02-25 09:18:09'),
-- (816, 1, 'IV312800', 4.00, 0.00, 'OIL FILTER', 'YN15OEA', NULL, '2025-02-22 00:00:00', '2025-02-25 09:19:18'),
-- (817, 1, 'IV310995', 24.50, 0.00, 'OIL FILTER\r\nCABIN FILTER\r\nAIR FILTER', 'W4SXU', NULL, '2025-02-12 00:00:00', '2025-02-25 09:20:41'),
-- (818, 1, 'IV312737', 23.25, 0.00, 'OIL FILTER\r\nAIR FILTER\r\nCABIN FILTER', 'EA63YOD', NULL, '2025-02-22 00:00:00', '2025-02-25 09:22:03'),
-- (819, 1, 'IV311807', 7.25, 0.00, 'OIL FILTER\r\nAIR FILTER', 'HS53ECE', NULL, '2025-02-17 00:00:00', '2025-02-25 09:23:22'),
-- (820, 1, 'IV311605', 41.50, 0.00, 'SUS ARM RH\r\nSTAB LINK', 'VU15EXL', NULL, '2025-02-15 00:00:00', '2025-02-25 09:25:16'),
-- (821, 1, 'IV312687', 11.00, 0.00, 'BGA STAB LINK', 'EA63YOD', NULL, '2025-02-21 00:00:00', '2025-02-25 09:26:27'),
-- (822, 1, 'IV312664', 26.00, 0.00, 'WHEEL BEARING KIT', 'KB57KLD', NULL, '2025-02-21 00:00:00', '2025-02-25 09:27:31'),
-- (823, 1, 'IV312665', 42.25, 0.00, 'REAR BOX\r\nGASKET', 'AJ04GVV', NULL, '2025-02-21 00:00:00', '2025-02-25 09:28:42'),
-- (824, 2, '04844372', 15.47, 0.00, 'CV BOOT KIT MINI MITSIBU', 'AO03DOA', NULL, '2025-02-20 00:00:00', '2025-02-25 09:30:25'),
-- (825, 1, 'IV312369', 23.00, 0.00, 'APEC FR COIL SPRING', 'OE15TYC', NULL, '2025-02-20 00:00:00', '2025-02-25 09:31:39'),
-- (826, 1, 'IV312355', 16.75, 0.00, 'OIL FILTER\r\nAIR FILTER\r\nCABIN FILTER', 'OE15TYC', NULL, '2025-02-20 00:00:00', '2025-02-25 09:33:07'),
-- (827, 2, '04844563', 50.45, 0.00, 'COIL SPRING F\r\nCOIL SPRING TP R\r\nFRONT PADS', 'NV08VVM', NULL, '2025-02-20 00:00:00', '2025-02-25 09:34:56'),
-- (828, 2, '04844597', 36.95, 0.00, 'DRIVE \r\nDRIVE BELT', 'HF66NUX', NULL, '2025-02-20 00:00:00', '2025-02-25 09:36:11'),
-- (829, 15, '72IN032232', 72.00, 0.00, 'SUSP ARM, F LOWE X2', 'YY06TSU', NULL, '2025-02-21 00:00:00', '2025-02-25 09:38:39'),
-- (830, 1, 'IV312620', 29.00, 0.00, 'SUSP ARM RH', 'WU55YSF', NULL, '2025-02-21 00:00:00', '2025-02-25 09:39:39'),
-- (831, 2, '04845223', 26.47, 0.00, 'RADIATOR CAP\r\nEXPANSION TANK', 'EY59UNX', NULL, '2025-02-21 00:00:00', '2025-02-25 10:01:36'),
-- (832, 1, 'IV312574', 8.50, 0.00, 'BGA STAB LINK', 'VO62WJK', NULL, '2025-02-21 00:00:00', '2025-02-25 10:02:49'),
-- (833, 1, 'IV312558', 17.00, 0.00, 'WHEEL BEARING KIT', 'FD03ELV', NULL, '2025-02-21 00:00:00', '2025-02-25 10:03:47'),
-- (834, 15, '72IN032322', 10.80, 0.00, 'BREAK WEAR INDICATOR', 'YH61FYK', NULL, '2025-02-22 00:00:00', '2025-02-25 10:12:01'),
-- (835, 2, '04842744', 40.03, 0.00, 'SHOCK ABSOB FRONT', 'LT58NCJ', NULL, '2025-02-17 00:00:00', '2025-02-25 10:14:17'),
-- (836, 2, '04842763', 17.64, 0.00, 'CV BOOT KIT FORD', 'HS53ECE', NULL, '2025-02-17 00:00:00', '2025-02-25 10:15:42');

-- --------------------------------------------------------

--
-- Table structure for table `sale_invoices`
--

CREATE TABLE `sale_invoices` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `car_id` bigint(20) UNSIGNED NOT NULL,
  `details` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`details`)),
  `amount` float(20,2) NOT NULL,
  `payment_type` tinyint(4) NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sale_invoices`
--

INSERT INTO `sale_invoices` (`id`, `car_id`, `details`, `amount`, `payment_type`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 1, '[{\"work\":\"Some Work\",\"part_invoice_number\":\"1\",\"part_supplier\":\"Jas Autos\",\"amount\":\"30\"},{\"work\":\"Some More Work\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"40\"},{\"work\":\"Some More More Work\",\"part_invoice_number\":\"1\",\"part_supplier\":\"Jas Autos\",\"amount\":\"100.5\"},{\"work\":\"labour\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"3.5\"},{\"work\":\"Parts\",\"part_invoice_number\":\"5\",\"part_supplier\":\"GSF\",\"amount\":\"60\"},{\"work\":\"Electric\",\"part_invoice_number\":\"6\",\"part_supplier\":\"parkers\",\"amount\":\"80\"},{\"work\":\"Pump\",\"part_invoice_number\":\"6\",\"part_supplier\":\"parkers\",\"amount\":\"30\"},{\"work\":\"Pumping\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"60\"}]', 403.00, 0, NULL, '2023-05-11 00:00:00', '2023-05-11 11:42:19'),
(2, 4, '[{\"work\":\"Thermostat housing\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"150\"}]', 150.00, 0, NULL, '2023-04-07 00:00:00', '2023-04-07 09:03:33'),
(3, 11, '[{\"work\":\"MOT\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"40\"}]', 40.00, 1, NULL, '2023-04-07 00:00:00', '2023-04-07 15:51:43'),
(4, 12, '[{\"work\":\"front brake pads\\r\\nrear disc and pads\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"335\"},{\"work\":\"mot\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"40\"}]', 375.00, 0, NULL, '2023-04-10 00:00:00', '2023-04-10 12:26:05'),
(5, 13, '[{\"work\":\"MOT\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"30\"}]', 30.00, 0, NULL, '2023-04-10 00:00:00', '2023-04-10 16:21:43'),
(6, 14, '[{\"work\":\"MOT\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"30\"}]', 30.00, 0, NULL, '2023-04-10 00:00:00', '2023-04-10 16:25:33'),
(7, 16, '[{\"work\":\"OIL FILTER\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"15\"},{\"work\":\"LABOUR\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"25\"}]', 40.00, 0, NULL, '2023-04-11 00:00:00', '2023-04-11 09:22:00'),
(8, 19, '[{\"work\":\"timing belt and service and work\\r\\nmil 176170\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"300\"}]', 300.00, 0, NULL, '2023-04-18 00:00:00', '2023-04-18 16:37:49'),
(9, 20, '[{\"work\":\"CLUTCH AND LABOUR\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"370\"}]', 370.00, 1, NULL, '2023-07-19 00:00:00', '2023-07-19 12:46:56'),
(10, 23, '[{\"work\":\"NEAR SIDE SHOCKER USED\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"70\"},{\"work\":\"FRONT BOTH SIDE LINK\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"34\"},{\"work\":\"OFF SIDE FRONT TRACK ROD END\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"20\"},{\"work\":\"LABOUR\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"75\"}]', 199.00, 0, NULL, '2023-05-09 00:00:00', '2023-05-09 16:18:52'),
(11, 26, '[{\"work\":\"ENGINE OIL 5W30\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"55\"},{\"work\":\"OIL FILTER\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"15\"},{\"work\":\"CABIN FILTER\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"21\"},{\"work\":\"LABOUR\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"55\"}]', 146.00, 0, NULL, '2023-05-15 00:00:00', '2023-05-15 12:56:12'),
(12, 30, '[{\"work\":\"3 PC CLUTCH\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"253.02\"},{\"work\":\"LABOUR\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"250\"}]', 503.00, 0, NULL, '2023-05-27 00:00:00', '2023-05-27 09:13:19'),
(13, 34, '[{\"work\":\"battery external\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"150\"},{\"work\":\"labour\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"70\"}]', 220.00, 0, NULL, '2023-06-20 00:00:00', '2023-06-20 21:06:27'),
(14, 82, '[{\"work\":\"FRONT DISC PADS\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"73\"},{\"work\":\"OFF SIDE FRONT CV BOOT\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"15\"},{\"work\":\"MOT\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"45\"},{\"work\":\"LABOUR\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"80\"}]', 213.00, 0, NULL, '2023-07-13 00:00:00', '2023-07-13 10:58:10'),
(15, 84, '[{\"work\":\"CLUTCH AND FLYWHEEL INC LABOUR\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"1000\"}]', 1000.00, 0, NULL, '2023-07-19 00:00:00', '2023-07-19 12:46:45'),
(16, 85, '[{\"work\":\"SERVICE LAB ONLY\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"25\"}]', 25.00, 0, NULL, '2023-07-19 00:00:00', '2023-07-19 16:04:16'),
(17, 86, '[{\"work\":\"NEAR SIDE FRONT COIL SPRINT LAB\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"75\"},{\"work\":\"MOT\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"35\"}]', 110.00, 0, NULL, '2023-07-19 00:00:00', '2023-07-19 16:06:25'),
(18, 87, '[{\"work\":\"OIL FILTER AND OIL AND MOT\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"70\"}]', 70.00, 0, NULL, '2023-07-31 00:00:00', '2023-07-31 17:24:24'),
(19, 37, '[{\"work\":\"REAR DISC PADS AND LABOUR\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"110\"}]', 110.00, 0, NULL, '2023-07-31 00:00:00', '2023-07-31 17:27:31'),
(20, 88, '[{\"work\":\"TIMING CHAIN KT + ROCKER COVER GASKET+ WATER LEAK FIX+LABOUR\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"540\"}]', 540.00, 0, NULL, '2023-08-03 00:00:00', '2023-08-03 10:39:29'),
(21, 89, '[{\"work\":\"MOT\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"45\"},{\"work\":\"FULL ENGINE SERVICE\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"180\"}]', 225.00, 0, NULL, '2023-08-04 00:00:00', '2023-08-04 13:47:02'),
(22, 3, '[{\"work\":\"REAR BRAKE PADS\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"30\"},{\"work\":\"LABOUR\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"50\"},{\"work\":\"NUMBER PLATE BULB\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"10\"}]', 90.00, 0, NULL, '2023-08-09 00:00:00', '2023-08-09 11:27:30'),
(23, 90, '[{\"work\":\"MOT\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"40\"}]', 40.00, 0, NULL, '2023-08-10 00:00:00', '2023-08-10 09:45:48'),
(24, 61, '[{\"work\":\"MOT\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"35\"}]', 35.00, 0, NULL, '2023-08-11 00:00:00', '2023-08-11 11:12:39'),
(25, 91, '[{\"work\":\"CLUTCH SUPPLY AND FIT\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"480\"},{\"work\":\"GEAR OIL\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"20\"}]', 500.00, 0, NULL, '2023-08-16 00:00:00', '2023-08-16 15:15:34'),
(26, 97, '[{\"work\":\"MOT & SERVICE\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"120\"}]', 120.00, 1, NULL, '2023-09-16 00:00:00', '2023-09-16 12:55:59'),
(27, 97, '[{\"work\":\"MOT & SERVICE \\r\\nMILAGE 45800\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"120\"}]', 120.00, 0, NULL, '2023-09-20 00:00:00', '2023-09-20 11:12:56'),
(28, 113, '[{\"work\":\"3PC CLUTCH PARTS AND LABOUR\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"450\"}]', 450.00, 0, NULL, '2023-12-07 00:00:00', '2023-12-07 17:21:09'),
(29, 4, '[{\"work\":\"afcac\",\"part_invoice_number\":\"3\",\"part_supplier\":\"euro car parts\",\"amount\":\"50\"}]', 50.00, 0, NULL, '2024-01-25 00:00:00', '2024-01-24 21:57:05'),
(30, 122, '[{\"work\":\"MOT\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"35\"}]', 35.00, 0, NULL, '2024-01-29 00:00:00', '2024-01-29 17:10:30'),
(31, 123, '[{\"work\":\"ENGINE OIL OIL FILTER AND AIR FILTER\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"100\"}]', 100.00, 0, NULL, '2024-01-30 00:00:00', '2024-01-30 11:59:58'),
(32, 124, '[{\"work\":\"MOT\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"35\"}]', 35.00, 0, NULL, '2024-01-30 00:00:00', '2024-01-30 17:15:41'),
(33, 4, '[{\"work\":\"asdc\",\"part_invoice_number\":\"2\",\"part_supplier\":\"euro car parts\",\"amount\":\"12\"}]', 12.00, 0, NULL, '2024-02-12 00:00:00', '2024-02-04 12:04:02'),
(34, 48, '[{\"work\":\"mot\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"45\"}]', 45.00, 0, NULL, '2024-02-06 00:00:00', '2024-02-06 15:43:47'),
(35, 127, '[{\"work\":\"MOT\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"35\"}]', 35.00, 0, NULL, '2024-02-13 00:00:00', '2024-02-13 11:44:19'),
(36, 131, '[{\"work\":\"CLUTCH SUPPLY AND FIT\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"550\"},{\"work\":\"ENGINE OIL OIL FILTER\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"100\"}]', 650.00, 0, NULL, '2024-02-15 00:00:00', '2024-02-15 18:16:37'),
(37, 52, '[{\"work\":\"batter\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"60\"}]', 60.00, 0, NULL, '2024-02-28 00:00:00', '2024-02-28 13:59:11'),
(38, 134, '[{\"work\":\"LOWER ENGINE MOUNTING\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"70\"},{\"work\":\"GUIDE FREE PULLEY\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"45\"},{\"work\":\"LABOUR\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"120\"}]', 235.00, 0, NULL, '2024-02-28 00:00:00', '2024-02-28 14:02:57'),
(39, 135, '[{\"work\":\"MOT\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"40\"},{\"work\":\"FULL SERVICE \\r\\nENGINE FLUSH\\r\\nENGINE OIL \\r\\nOIL FILTER AIR FILTER \\r\\nSPARK PLUGS, CABIN FILTER,\\r\\nSCREEN WASH FIX\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"160\"}]', 200.00, 0, NULL, '2024-02-28 00:00:00', '2024-02-28 14:38:58'),
(40, 136, '[{\"work\":\"MOT\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"35\"}]', 35.00, 0, NULL, '2024-03-01 00:00:00', '2024-03-01 09:47:50'),
(41, 137, '[{\"work\":\"both side front cv boot\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"30\"},{\"work\":\"labour\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"90\"}]', 120.00, 0, NULL, '2024-03-01 00:00:00', '2024-03-01 17:17:38'),
(42, 138, '[{\"work\":\"Shocker top mounting front both side and both side front link\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"105\"},{\"work\":\"Labour\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"150\"}]', 255.00, 0, NULL, '2024-03-04 00:00:00', '2024-03-04 13:26:14'),
(43, 137, '[{\"work\":\"fan belt\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"75\"}]', 75.00, 0, NULL, '2024-03-07 00:00:00', '2024-03-07 15:59:34'),
(44, 139, '[{\"work\":\"MOT\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"35\"}]', 35.00, 0, NULL, '2024-03-08 00:00:00', '2024-03-08 11:54:53'),
(45, 140, '[{\"work\":\"MOT\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"35\"}]', 35.00, 0, NULL, '2024-03-08 00:00:00', '2024-03-08 11:57:09'),
(46, 142, '[{\"work\":\"WATER PUMP+ THERMOSTAT\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"350\"}]', 350.00, 0, NULL, '2024-03-08 00:00:00', '2024-03-08 16:01:55'),
(47, 143, '[{\"work\":\"Timing belt kit &  water pump\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"350\"}]', 350.00, 0, NULL, '2024-03-09 00:00:00', '2024-03-09 15:07:38'),
(48, 144, '[{\"work\":\"ENGINE OIL\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"30\"},{\"work\":\"LINK + OIL FILTER\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"20\"},{\"work\":\"OFF SIDE REAR SPRING\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"70\"},{\"work\":\"BULB H11\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"35\"},{\"work\":\"LABOUR\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"70\"}]', 225.00, 0, NULL, '2024-03-11 00:00:00', '2024-03-11 12:46:11'),
(49, 145, '[{\"work\":\"FRONT BRAKE PADS SUPPLY AND FIT\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"95\"}]', 95.00, 0, NULL, '2024-02-22 00:00:00', '2024-03-11 15:34:25'),
(50, 49, '[{\"work\":\"CLUTCH MASTER CYLINDER & WORK\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"245\"},{\"work\":\"FULL SERVICE LAB\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"60\"}]', 305.00, 0, NULL, '2024-04-03 00:00:00', '2024-04-03 14:11:08'),
(51, 49, '[{\"work\":\"CLUTCH & FLYWHEEL\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"950\"}]', 950.00, 0, NULL, '2024-04-04 00:00:00', '2024-04-04 14:56:34'),
(52, 147, '[{\"work\":\"Front brake pads lab only\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"60\"}]', 60.00, 0, NULL, '2024-04-13 00:00:00', '2024-04-13 12:27:06'),
(53, 134, '[{\"work\":\"front disc and pads plus full service lab\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"150\"}]', 150.00, 0, NULL, '2024-04-15 00:00:00', '2024-04-15 14:36:36'),
(54, 147, '[{\"work\":\"full service lab\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"70\"},{\"work\":\"air filter\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"15\"},{\"work\":\"rear brake pads lab only\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"60\"}]', 145.00, 0, NULL, '2024-04-24 00:00:00', '2024-04-24 12:42:55'),
(55, 148, '[{\"work\":\"FRONT WHEEL BEARING\\r\\nFRONT BRAKE DISC\\r\\nBRAKE PAD\\r\\nLABOUR\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"186\"}]', 186.00, 0, NULL, '2024-05-23 00:00:00', '2024-05-23 13:15:45'),
(56, 3, '[{\"work\":\"Some work\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"120\"}]', 120.00, 0, NULL, '2024-11-29 00:00:00', '2024-11-29 13:27:44'),
(57, 151, '[{\"work\":\"mot only\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"40\"}]', 40.00, 0, NULL, '2025-01-03 00:00:00', '2025-01-03 18:23:49'),
(58, 152, '[{\"work\":\"ful service\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"160\"}]', 160.00, 0, NULL, '2025-01-03 00:00:00', '2025-01-03 18:27:51'),
(59, 153, '[{\"work\":\"MOT\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"40\"}]', 40.00, 0, NULL, '2025-01-03 00:00:00', '2025-01-03 18:31:01'),
(60, 153, '[{\"work\":\"SPARK PLUG\",\"part_invoice_number\":null,\"part_supplier\":null,\"amount\":\"60\"}]', 60.00, 0, NULL, '2025-01-03 00:00:00', '2025-01-03 18:31:31');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `weekly_sms` tinyint(1) DEFAULT NULL,
  `monthly_sms` tinyint(4) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `weekly_sms`, `monthly_sms`, `created_at`, `updated_at`) VALUES
(1, 0, 1, '2023-07-06 05:15:55', '2024-10-29 11:59:04');

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE `suppliers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`id`, `name`, `phone`, `email`, `address`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 'Jas Autos', '+0116 222 9021', 'contact@jasautos.com', NULL, NULL, '2023-03-27 01:29:28', '2023-03-27 01:29:28'),
(2, 'euro car parts', '0116-2045785', NULL, 'leicester branch', NULL, '2023-04-07 15:38:28', '2023-04-07 15:38:28'),
(3, 'parkers', '0116-2428200', NULL, 'belgrave branch', NULL, '2023-04-07 15:39:21', '2023-04-07 15:39:21'),
(4, 'FORD', '01164649006', NULL, NULL, NULL, '2023-04-07 15:39:59', '2023-04-07 15:39:59'),
(5, 'MERCEDES', '01162511444', NULL, NULL, NULL, '2023-04-07 15:40:21', '2023-04-07 15:40:21'),
(6, 'LAP', '01162461000', NULL, NULL, NULL, '2023-04-07 15:40:48', '2023-04-07 15:40:48'),
(7, 'AVP', '2533000', NULL, NULL, NULL, '2023-04-07 15:41:23', '2023-04-07 15:41:23'),
(8, 'GSF', '0116-2340200', NULL, NULL, NULL, '2023-04-07 15:42:09', '2023-04-07 15:42:09'),
(9, 'MERCEDES', '01162511444', NULL, 'MERCEDES LEICESTER', NULL, '2023-06-20 17:46:41', '2023-06-20 17:46:41'),
(10, 'TPS', '0116', NULL, 'LEICESTER', NULL, '2023-06-20 17:59:31', '2023-06-20 17:59:31'),
(11, 'THURMASTON REWINDS', '01162600732', NULL, 'OFF MELTON ROAD', NULL, '2023-07-14 15:34:50', '2023-07-14 15:34:50'),
(12, 'OIL RECOVERIES', '08455206444', NULL, NULL, NULL, '2023-07-18 17:09:49', '2023-07-18 17:09:49'),
(13, 'PEUGEOT', '01332344222', NULL, '1A GLENCAR CLOSE, DERBY COMERCIAL PARK,, DERBY DE217HZ', NULL, '2023-08-08 16:25:57', '2023-08-08 16:25:57'),
(14, 'MJC', '01162765600', NULL, '81 Cannock St, Leicester LE4 9HR', NULL, '2023-08-09 12:47:50', '2023-08-09 12:47:50'),
(15, 'spartan', 'raj', NULL, 'le4 6by', NULL, '2024-01-22 17:05:52', '2024-01-22 17:05:52'),
(16, 'Nami Car Parts', '01163730908', 'namicarparts@gmail.com', '97 Melton Road, Leicester LE4 6PN', NULL, '2024-06-25 08:35:29', '2024-06-25 08:36:27'),
(17, 'AUTO JAP SPARES', '07394068684', 'SALES@AUTOJAPSPARES.CO.UK', '110, EASTCOTES TILE HILL, COVENTY CV4 9AS', NULL, '2024-11-13 13:02:08', '2024-11-13 13:02:08'),
(18, 'LEICESTER PARTS PLUS', '0116 4649006', 'LEICESTER@PARTSPLUSUK.COM', 'UNIT 4, 15 CHISWICK ROAD FREEMANS COMMON LEICESTER, LE2 7SX', NULL, '2024-11-20 11:15:00', '2024-11-20 11:15:00'),
(19, 'TYRE HUB(LEIC) LTD', '07498763555', 'TYREHUBLTD@OUTLOOK.COM', 'UNIT 29 TEMPLE BUILDING, TEMPLE ROAD LEICESTER, LE5 4JG', NULL, '2025-02-07 09:53:22', '2025-02-07 09:53:22');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'AJ Autos', 'admin@gmail.com', NULL, '$2y$10$ruC26vdzkVJXsSTidWbW7uKIZwtTK86brzDu7ZjI1LiNNEo60F69O', 'FHFoTNX7VhK5sBBefeEAUlFJzGkpF7k24a1kHTiOgRKPtxxI5hgOdRPVNCvr', '2023-03-27 01:26:41', '2023-03-27 01:26:41');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cars`
--
ALTER TABLE `cars`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `cars_registration_number_unique` (`registration_number`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `purchase_invoices`
--
ALTER TABLE `purchase_invoices`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `purchase_invoices_part_invoice_number_unique` (`part_invoice_number`);

--
-- Indexes for table `sale_invoices`
--
ALTER TABLE `sale_invoices`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cars`
--
ALTER TABLE `cars`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=154;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=111;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `purchase_invoices`
--
ALTER TABLE `purchase_invoices`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=837;

--
-- AUTO_INCREMENT for table `sale_invoices`
--
ALTER TABLE `sale_invoices`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT for table `suppliers`
--
ALTER TABLE `suppliers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
